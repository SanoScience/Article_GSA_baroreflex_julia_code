using  JLD, GlobalSensitivity,CairoMakie

UnReg_SM = load("GSA_100k.jld")["data"]

Reg_S1= load("150k_4Cham.jld")["data"].S1
Reg_ST= load("150k_4Cham.jld")["data"].ST
Reg_SH =Reg_ST - Reg_S1

UnReg_S1 = UnReg_SM.S1[:,[10, 9, 11, 13, 12, 14, 15, 16, 18, 17, 2, 1, 6, 5, 4, 3, 8, 7]]
UnReg_ST = UnReg_SM.ST[:,[10, 9, 11, 13, 12, 14, 15, 16, 18, 17, 2, 1, 6, 5, 4, 3, 8, 7]]

R_M = [L"\text{Max}(P_{LV})", L"\text{Min}(P_{LV})", L"\text{Max}(P_{A})", L"\text{Min}(P_{A})", L"\text{Max}(P_{V})", L"\text{Min}(P_{V})", L"\text{Max}(V_{LV})", L"\text{Min}(V_{LV})", L"\text{Max}(P_{RV})", L"\text{Min}(P_{RV})", L"\text{Max}(P_{pulA})", L"\text{Min}(P_{pulA})", L"\text{Max}(P_{pulV})", L"\text{Min}(P_{pulV})", L"\tau_{HR}", L"\text{CO}"]
HR_M = [L"\text{Max}(P_{LV})", L"\text{Min}(P_{LV})", L"\text{Max}(P_{A})", L"\text{Min}(P_{A})", L"\text{Max}(P_{V})", L"\text{Min}(P_{V})", L"\text{Max}(V_{LV})", L"\text{Min}(V_{LV})", L"\text{Max}(P_{RV})", L"\text{Min}(P_{RV})", L"\text{Max}(P_{pulA})", L"\text{Min}(P_{pulA})", L"\text{Max}(P_{pulV})", L"\text{Min}(P_{pulV})", L"\text{CO}"]

HR_P = [L"R_{sys}", L"C_{art}", L"C_{ven}", L"R_{pul}", L"C_{pulA}", L"C_{pulV}", L"r_{av}", L"r_{mv}", L"r_{tv}", L"r_{pv}", L"E_{LVmax}", L"E_{LVmin}", L"E_{RVmax}", L"E_{RVmin}", L"E_{LAmax}", L"E_{LAmin}", L"E_{RAmax}", L"E_{RAmin}"]
R_P =   [L"R_{sys}", L"C_{art}", L"C_{ven}", L"R_{pul}", L"C_{pulA}", L"C_{pulV}", L"r_{av}", L"r_{mv}", L"r_{tv}", L"r_{pv}", L"\tau_{HR,0}", L"E_{LVmax}", L"E_{LVmin}", L"E_{RVmax}", L"E_{RVmin}", L"E_{LAmax}", L"E_{LAmin}", L"E_{RAmax}", L"E_{RAmin}", L"P_{n}",L"k_{a}",L"f_{min}",L"f_{max}", L"\tau_{z}",L"\tau_{p}",L"f_{es,\infty}",L"f_{es,0}", L"f_{es,min}",L"k_{es}",L"f_{ev,0}", L"f_{ev,\infty}",L"f_{cs,0}",L"k_{ev}", L"G_{Emax,LV}",L"\tau_{Emax,LV}",L"D_{Emax,LV}", L"G_{Emax,RV}",L"\tau_{Emax,RV}",L"D_{Emax,RV}", L"G_{Rsys}",L"\tau_{Rsys}",L"D_{Rsys}", L"G_{\tau,s}",L"\tau_{\tau,s}",L"D_{\tau,s}",L"G_{\tau,v}",L"\tau_{\tau,v}",L"D_{\tau,v}", L"G_{VunV}",L"\tau_{VunV}",L"D_{VunV}"]

a = begin
    f = Figure(size = (1100,1100), backgroundcolor = RGBf(0.98, 0.98, 0.98))

    joint_limits = (0.0,1.0)
    ax1 = Axis(f[1,1], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:16, R_M), yticks = (1:51, R_P))
    Label(f[1, 1, TopLeft()], "A",fontsize = 18,font = :bold,halign = :right)
    Label(f[1, 1, Top()], "First Order",fontsize = 18,font = :bold,halign = :center)
    Label(f[1, 1, Left()], "Regulated Model",fontsize = 18,font = :bold,halign = :right, rotation = π/2, padding = (0,45,0,0))

    hm1 = CairoMakie.heatmap!(ax1,Reg_S1, colorrange = joint_limits, colormap=:gnuplot2)

    ax2 = Axis(f[2,1], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:15, HR_M), yticks = (1:18, HR_P))
    Label(f[2, 1, Left()], "Unregulated Model",fontsize = 18,font = :bold,halign = :right, rotation = π/2, padding = (0,40,0,0))
    Label(f[2, 1, TopLeft()], "D",fontsize = 18,font = :bold,halign = :right)
    hm2 = CairoMakie.heatmap!(ax2, UnReg_S1, colorrange = joint_limits, colormap=:gnuplot2)

    ax3 = Axis(f[1,2], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:16, R_M), yticks = (1:51, R_P))
    Label(f[1, 2, TopLeft()], "B",fontsize = 18,font = :bold,halign = :right)
    Label(f[1, 2, Top()], "Total Order",fontsize = 18,font = :bold,halign = :center)
    hm3 = CairoMakie.heatmap!(ax3, Reg_ST, colorrange = joint_limits, colormap=:gnuplot2)

    ax4 = Axis(f[2,2], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:15, HR_M), yticks = (1:18, HR_P))
    Label(f[2, 2, TopLeft()], "E",fontsize = 18,font = :bold,halign = :right)
    hm4 = CairoMakie.heatmap!(ax4,UnReg_ST, colorrange = joint_limits, colormap=:gnuplot2)
   
    ax5 = Axis(f[1,3], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:16, R_M), yticks = (1:51, R_P))
    Label(f[1, 3, TopLeft()], "C",fontsize = 18,font = :bold,halign = :right)
    Label(f[1, 3, Top()], "Higher Order",fontsize = 18,font = :bold,halign = :center)
    hm5 = CairoMakie.heatmap!(ax5,Reg_SH, colorrange = joint_limits, colormap=:gnuplot2)

    ax6 = Axis(f[2,3], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:15, HR_M), yticks = (1:18, HR_P))
    Label(f[2, 3, TopLeft()], "F",fontsize = 18,font = :bold,halign = :right)
    hm6 = CairoMakie.heatmap!(ax6,(UnReg_ST - UnReg_S1), colorrange = joint_limits, colormap=:gnuplot2)

    Colorbar(f[:, end+1], hm1, colorrange = joint_limits, ticks = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])    

    f
end 
save("MAP.pdf",a)
