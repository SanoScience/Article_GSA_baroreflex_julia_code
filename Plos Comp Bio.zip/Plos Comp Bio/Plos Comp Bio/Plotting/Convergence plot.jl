using JLD, GlobalSensitivity, CairoMakie

## Load reg data ##
begin
    R_0_1k = load("0.1k.jld")["data"]
    R_0_2k = load("0.2k.jld")["data"]
    R_0_3k = load("0.3k.jld")["data"]
    R_0_4k = load("0.4k.jld")["data"]
    R_0_5k = load("0.5k.jld")["data"]
    R_0_6k = load("0.6k.jld")["data"]
    R_0_7k = load("0.7k.jld")["data"]
    R_0_8k = load("0.8k.jld")["data"]
    R_0_9k = load("0.9k.jld")["data"]
    R_1_0k = load("1k.jld")["data"]
    R_1_2k = load("1.2k.jld")["data"]
    R_1_4k = load("1.4k.jld")["data"]
    R_1_6k = load("1.6k.jld")["data"]
    R_1_8k = load("1.8k.jld")["data"]
    R_2_0k = load("2k.jld")["data"]
    R_2_3k = load("2.3k.jld")["data"]
    R_2_6k = load("2.6k.jld")["data"]
    R_2_9k = load("2.9k.jld")["data"]
    R_3_0k = load("3k.jld")["data"]
    R_3_5k = load("/3.5k.jld")["data"]
    R_4_0k = load("4k.jld")["data"]
    R_4_5k = load("4.5k.jld")["data"]
    R_5_0k = load("5k.jld")["data"]
    R_6_0k = load("6k.jld")["data"]
    R_7_0k = load("7k.jld")["data"]
    R_8_0k = load("8k.jld")["data"]
    R_9_0k = load("9k.jld")["data"]
    R_10_0k = load("10k.jld")["data"]
    R_12_5k = load("12.5k.jld")["data"]
    R_15_0k = load("15k.jld")["data"]
    R_17_5k = load("17.5k.jld")["data"]
    R_20_0k = load("20k.jld")["data"]
    R_25_0k = load("25k.jld")["data"]
    R_30_0k = load("30k.jld")["data"]
    R_35_0k = load("35k.jld")["data"]
    R_40_0k = load("40k.jld")["data"]
    R_45_0k = load("45k.jld")["data"]
    R_50_0k = load("50k.jld")["data"]
    R_55_0k = load("55k.jld")["data"]
    R_60_0k = load("60k.jld")["data"]
    R_65_0k = load("65k.jld")["data"]
    R_70_0k = load("70k.jld")["data"]
    R_75_0k = load("75k.jld")["data"]
    R_80_0k = load("80k.jld")["data"]
    R_85_0k = load("85k.jld")["data"]
    R_90_0k = load("90k.jld")["data"]
    R_95_0k = load("95k.jld")["data"]
    R_100_0k = load("100k.jld")["data"]
    R_105_0k = load("105k.jld")["data"]
    R_110_0k = load("110k.jld")["data"]
    R_115_0k = load("115k.jld")["data"]
    R_120_0k = load("120k.jld")["data"]
    R_125_0k = load("125k.jld")["data"]
    R_130_0k = load("130k.jld")["data"]
    R_135_0k = load("135k.jld")["data"]
    R_140_0k = load("140k.jld")["data"]
    R_145_0k = load("145k.jld")["data"]
    R_150_0k = load("150k.jld")["data"]
end

## Load no HR data ##
begin
    HR_0_1k = load("0.1k.jld")["data"]
    HR_0_2k = load("0.2k.jld")["data"]
    HR_0_3k = load("0.3k.jld")["data"]
    HR_0_4k = load("0.4k.jld")["data"]
    HR_0_5k = load("0.5k.jld")["data"]
    HR_0_6k = load("0.6k.jld")["data"]
    HR_0_7k = load("0.7k.jld")["data"]
    HR_0_8k = load("0.8k.jld")["data"]
    HR_0_9k = load("0.9k.jld")["data"]
    HR_1_0k = load("1k.jld")["data"]
    HR_1_2k = load("1.2k.jld")["data"]
    HR_1_4k = load("1.4k.jld")["data"]
    HR_1_6k = load("1.6k.jld")["data"]
    HR_1_8k = load("1.8k.jld")["data"]
    HR_2_0k = load("2k.jld")["data"]
    HR_2_3k = load("2.3k.jld")["data"]
    HR_2_6k = load("2.6k.jld")["data"]
    HR_2_9k = load("2.9k.jld")["data"]
    HR_3_0k = load("3k.jld")["data"]
    HR_3_5k = load("3.5k.jld")["data"]
    HR_4_0k = load("4k.jld")["data"]
    HR_4_5k = load("4.5k.jld")["data"]
    HR_5_0k = load("5k.jld")["data"]
    HR_6_0k = load("6k.jld")["data"]
    HR_7_0k = load("7k.jld")["data"]
    HR_8_0k = load("8k.jld")["data"]
    HR_9_0k = load("9k.jld")["data"]
    HR_10_0k = load("10k.jld")["data"]
    HR_12_5k = load("12.5k.jld")["data"]
    HR_15_0k = load("15k.jld")["data"]
    HR_17_5k = load("17.5k.jld")["data"]
    HR_20_0k = load("20k.jld")["data"]
    HR_25_0k = load("25k.jld")["data"]
    HR_30_0k = load("30k.jld")["data"]
    HR_35_0k = load("35k.jld")["data"]
    HR_40_0k = load("40k.jld")["data"]
    HR_45_0k = load("45k.jld")["data"]
    HR_50_0k = load("50k.jld")["data"]
    HR_55_0k = load("55k.jld")["data"]
    HR_60_0k = load("60k.jld")["data"]
    HR_65_0k = load("65k.jld")["data"]
    HR_70_0k = load("70k.jld")["data"]
    HR_75_0k = load("75k.jld")["data"]
    HR_80_0k = load("80k.jld")["data"]
    HR_85_0k = load("85k.jld")["data"]
    HR_90_0k = load("90k.jld")["data"]
    HR_95_0k = load("95k.jld")["data"]
    HR_100_0k = load("100k.jld")["data"]
    HR_105_0k = load("105k.jld")["data"]
    HR_110_0k = load("110k.jld")["data"]
    HR_115_0k = load("115k.jld")["data"]
    HR_120_0k = load("120k.jld")["data"]
    HR_125_0k = load("125k.jld")["data"]
    HR_130_0k = load("130k.jld")["data"]
    HR_135_0k = load("135k.jld")["data"]
    HR_140_0k = load("140k.jld")["data"]
    HR_145_0k = load("145k.jld")["data"]
    HR_150_0k = load("150k_FHR.jld")["data"]
end

CairoMakie.activate!(type = "svg")

begin
    f = Figure(size = (1100, 1000))

    gabcdef = f[1:6,1]
    ga = gabcdef[1, 1] = GridLayout()
    gb = gabcdef[2, 1] = GridLayout()
    gc = gabcdef[3, 1] = GridLayout()
    gd = gabcdef[4, 1] = GridLayout()
    ge = gabcdef[5, 1] = GridLayout()
    gf = gabcdef[6, 1] = GridLayout()

    gghijkl = f[1:6, 2] = GridLayout()
    gg = gghijkl[1, 1] = GridLayout()
    gh = gghijkl[2, 1] = GridLayout()
    gi = gghijkl[3, 1] = GridLayout()
    gj = gghijkl[4, 1] = GridLayout()
    gk = gghijkl[5, 1] = GridLayout()
    gl = gghijkl[6, 1] = GridLayout()

    gmnop = f[1:4, 3] = GridLayout()
    gm = gmnop[1, 1] = GridLayout()
    gn = gmnop[2, 1] = GridLayout()
    go = gmnop[3, 1] = GridLayout()
    gp = gmnop[4, 1] = GridLayout()

    gqrst = f[1:4, 4] = GridLayout()
    gq = gqrst[1, 1] = GridLayout()
    gr = gqrst[2, 1] = GridLayout()
    gs = gqrst[3, 1] = GridLayout()
    gt = gqrst[4, 1] = GridLayout()


    axa = Axis(ga[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    Label(ga[1, 1, Top()], L"S_{1}~\text{Regulated}~\text{Model}", valign = :center, font = :bold, padding = (0, 0, 0, 0))
    Label(ga[1, 1, Left()], L"R_{s}", valign = :center, font = :bold, padding = (0, 35, 0, 0))
    x = LinRange(100, 150000, 58)
    #Rs S1 reg data
    begin
        ## load Reg data for CO PSV PLV S1 ##
        begin
            CO_R_S1 = [R_0_1k.S1[10,1], R_0_2k.S1[10,1],R_0_3k.S1[10,1] ,R_0_4k.S1[10,1] ,R_0_5k.S1[10,1] ,R_0_6k.S1[10,1] ,  R_0_7k.S1[10,1] ,R_0_8k.S1[10,1] ,R_0_9k.S1[10,1] ,R_1_0k.S1[10,1] ,R_1_2k.S1[10,1] ,R_1_4k.S1[10,1] ,R_1_6k.S1[10,1] ,  R_1_8k.S1[10,1] ,R_2_0k.S1[10,1] ,R_2_3k.S1[10,1] ,R_2_6k.S1[10,1] ,R_2_9k.S1[10,1] ,R_3_0k.S1[10,1] ,R_3_5k.S1[10,1] ,  R_4_0k.S1[10,1] ,R_4_5k.S1[10,1] ,R_5_0k.S1[10,1] ,R_6_0k.S1[10,1] ,R_7_0k.S1[10,1] ,R_8_0k.S1[10,1] ,R_9_0k.S1[10,1] ,  R_10_0k.S1[10,1],R_12_5k.S1[10,1],R_15_0k.S1[10,1],R_17_5k.S1[10,1],R_20_0k.S1[10,1],R_25_0k.S1[10,1],R_30_0k.S1[10,1],  R_35_0k.S1[10,1],R_40_0k.S1[10,1],R_45_0k.S1[10,1],  R_50_0k.S1[10,1],  R_50_0k.S1[10,1],  R_60_0k.S1[10,1],  R_65_0k.S1[10,1],  R_70_0k.S1[10,1],  R_75_0k.S1[10,1],  R_80_0k.S1[10,1],  R_85_0k.S1[10,1],  R_90_0k.S1[10,1],  R_95_0k.S1[10,1],  R_100_0k.S1[10,1],  R_105_0k.S1[10,1],  R_110_0k.S1[10,1],  R_115_0k.S1[10,1],  R_120_0k.S1[10,1],  R_125_0k.S1[10,1],  R_130_0k.S1[10,1],  R_135_0k.S1[10,1],  R_140_0k.S1[10,1],  R_145_0k.S1[10,1],  R_150_0k.S1[10,1]]
        
            PLV_R_S1 = [R_0_1k.S1[1,1], R_0_2k.S1[1,1],R_0_3k.S1[1,1] ,R_0_4k.S1[1,1] ,R_0_5k.S1[1,1] ,R_0_6k.S1[1,1] , R_0_7k.S1[1,1] ,R_0_8k.S1[1,1] ,R_0_9k.S1[1,1] ,R_1_0k.S1[1,1] ,R_1_2k.S1[1,1] ,R_1_4k.S1[1,1] ,R_1_6k.S1[1,1] , R_1_8k.S1[1,1] ,R_2_0k.S1[1,1] ,R_2_3k.S1[1,1] ,R_2_6k.S1[1,1] ,R_2_9k.S1[1,1] ,R_3_0k.S1[1,1] ,R_3_5k.S1[1,1] , R_4_0k.S1[1,1] ,R_4_5k.S1[1,1] ,R_5_0k.S1[1,1] ,R_6_0k.S1[1,1] ,R_7_0k.S1[1,1] ,R_8_0k.S1[1,1] ,R_9_0k.S1[1,1] , R_10_0k.S1[1,1],R_12_5k.S1[1,1],R_15_0k.S1[1,1],R_17_5k.S1[1,1],R_20_0k.S1[1,1],R_25_0k.S1[1,1],R_30_0k.S1[1,1], R_35_0k.S1[1,1],R_40_0k.S1[1,1],R_45_0k.S1[1,1],  R_50_0k.S1[1,1],  R_50_0k.S1[1,1],  R_60_0k.S1[1,1],  R_65_0k.S1[1,1],  R_70_0k.S1[1,1],  R_75_0k.S1[1,1],  R_80_0k.S1[1,1],  R_85_0k.S1[1,1],  R_90_0k.S1[1,1],  R_95_0k.S1[1,1],  R_100_0k.S1[1,1],  R_105_0k.S1[1,1],  R_110_0k.S1[1,1],  R_115_0k.S1[1,1],  R_120_0k.S1[1,1],  R_125_0k.S1[1,1],  R_130_0k.S1[1,1],  R_135_0k.S1[1,1],  R_140_0k.S1[1,1],  R_145_0k.S1[1,1],  R_150_0k.S1[1,1]]
        
            PSV_R_S1 = [R_0_1k.S1[3,1], R_0_2k.S1[3,1],R_0_3k.S1[3,1] ,R_0_4k.S1[3,1] ,R_0_5k.S1[3,1] ,R_0_6k.S1[3,1] , R_0_7k.S1[3,1] ,R_0_8k.S1[3,1] ,R_0_9k.S1[3,1] ,R_1_0k.S1[3,1] ,R_1_2k.S1[3,1] ,R_1_4k.S1[3,1] ,R_1_6k.S1[3,1] , R_1_8k.S1[3,1] ,R_2_0k.S1[3,1] ,R_2_3k.S1[3,1] ,R_2_6k.S1[3,1] ,R_2_9k.S1[3,1] ,R_3_0k.S1[3,1] ,R_3_5k.S1[3,1] , R_4_0k.S1[3,1] ,R_4_5k.S1[3,1] ,R_5_0k.S1[3,1] ,R_6_0k.S1[3,1] ,R_7_0k.S1[3,1] ,R_8_0k.S1[3,1] ,R_9_0k.S1[3,1] , R_10_0k.S1[3,1],R_12_5k.S1[3,1],R_15_0k.S1[3,1],R_17_5k.S1[3,1],R_20_0k.S1[3,1],R_25_0k.S1[3,1],R_30_0k.S1[3,1], R_35_0k.S1[3,1],R_40_0k.S1[3,1],R_45_0k.S1[3,1],  R_50_0k.S1[3,1],  R_50_0k.S1[3,1],  R_60_0k.S1[3,1],  R_65_0k.S1[3,1],  R_70_0k.S1[3,1],  R_75_0k.S1[3,1],  R_80_0k.S1[3,1],  R_85_0k.S1[3,1],  R_90_0k.S1[3,1],  R_95_0k.S1[3,1],  R_100_0k.S1[3,1],  R_105_0k.S1[3,1],  R_110_0k.S1[3,1],  R_115_0k.S1[3,1],  R_120_0k.S1[3,1],  R_125_0k.S1[3,1],  R_130_0k.S1[3,1],  R_135_0k.S1[3,1],  R_140_0k.S1[3,1],  R_145_0k.S1[3,1],  R_150_0k.S1[3,1]]
        end

        ## R errors for CO PSV PLV S1 ##
        begin
            CO_R_S1_E = [R_0_1k.S1_Conf_Int[10,1], R_0_2k.S1_Conf_Int[10,1],R_0_3k.S1_Conf_Int[10,1] ,R_0_4k.S1_Conf_Int[10,1] ,R_0_5k.S1_Conf_Int[10,1] ,R_0_6k.S1_Conf_Int[10,1] ,  R_0_7k.S1_Conf_Int[10,1] ,R_0_8k.S1_Conf_Int[10,1] ,R_0_9k.S1_Conf_Int[10,1] ,R_1_0k.S1_Conf_Int[10,1] ,R_1_2k.S1_Conf_Int[10,1] ,R_1_4k.S1_Conf_Int[10,1] ,R_1_6k.S1_Conf_Int[10,1] ,  R_1_8k.S1_Conf_Int[10,1] ,R_2_0k.S1_Conf_Int[10,1] ,R_2_3k.S1_Conf_Int[10,1] ,R_2_6k.S1_Conf_Int[10,1] ,R_2_9k.S1_Conf_Int[10,1] ,R_3_0k.S1_Conf_Int[10,1] ,R_3_5k.S1_Conf_Int[10,1] ,  R_4_0k.S1_Conf_Int[10,1] ,R_4_5k.S1_Conf_Int[10,1] ,R_5_0k.S1_Conf_Int[10,1] ,R_6_0k.S1_Conf_Int[10,1] ,R_7_0k.S1_Conf_Int[10,1] ,R_8_0k.S1_Conf_Int[10,1] ,R_9_0k.S1_Conf_Int[10,1] ,  R_10_0k.S1_Conf_Int[10,1],R_12_5k.S1_Conf_Int[10,1],R_15_0k.S1_Conf_Int[10,1],R_17_5k.S1_Conf_Int[10,1],R_20_0k.S1_Conf_Int[10,1],R_25_0k.S1_Conf_Int[10,1],R_30_0k.S1_Conf_Int[10,1],  R_35_0k.S1_Conf_Int[10,1],R_40_0k.S1_Conf_Int[10,1],R_45_0k.S1_Conf_Int[10,1],  R_50_0k.S1_Conf_Int[10,1],  R_50_0k.S1_Conf_Int[10,1],  R_60_0k.S1_Conf_Int[10,1],  R_65_0k.S1_Conf_Int[10,1],  R_70_0k.S1_Conf_Int[10,1],  R_75_0k.S1_Conf_Int[10,1],  R_80_0k.S1_Conf_Int[10,1],  R_85_0k.S1_Conf_Int[10,1],  R_90_0k.S1_Conf_Int[10,1],  R_95_0k.S1_Conf_Int[10,1],  R_100_0k.S1_Conf_Int[10,1],  R_105_0k.S1_Conf_Int[10,1],  R_110_0k.S1_Conf_Int[10,1],  R_115_0k.S1_Conf_Int[10,1],  R_120_0k.S1_Conf_Int[10,1],  R_125_0k.S1_Conf_Int[10,1],  R_130_0k.S1_Conf_Int[10,1],  R_135_0k.S1_Conf_Int[10,1],  R_140_0k.S1_Conf_Int[10,1],  R_145_0k.S1_Conf_Int[10,1],  R_150_0k.S1_Conf_Int[10,1]]
        
            PLV_R_S1_E = [R_0_1k.S1_Conf_Int[1,1], R_0_2k.S1_Conf_Int[1,1],R_0_3k.S1_Conf_Int[1,1] ,R_0_4k.S1_Conf_Int[1,1] ,R_0_5k.S1_Conf_Int[1,1] ,R_0_6k.S1_Conf_Int[1,1] , R_0_7k.S1_Conf_Int[1,1] ,R_0_8k.S1_Conf_Int[1,1] ,R_0_9k.S1_Conf_Int[1,1] ,R_1_0k.S1_Conf_Int[1,1] ,R_1_2k.S1_Conf_Int[1,1] ,R_1_4k.S1_Conf_Int[1,1] ,R_1_6k.S1_Conf_Int[1,1] , R_1_8k.S1_Conf_Int[1,1] ,R_2_0k.S1_Conf_Int[1,1] ,R_2_3k.S1_Conf_Int[1,1] ,R_2_6k.S1_Conf_Int[1,1] ,R_2_9k.S1_Conf_Int[1,1] ,R_3_0k.S1_Conf_Int[1,1] ,R_3_5k.S1_Conf_Int[1,1] , R_4_0k.S1_Conf_Int[1,1] ,R_4_5k.S1_Conf_Int[1,1] ,R_5_0k.S1_Conf_Int[1,1] ,R_6_0k.S1_Conf_Int[1,1] ,R_7_0k.S1_Conf_Int[1,1] ,R_8_0k.S1_Conf_Int[1,1] ,R_9_0k.S1_Conf_Int[1,1] , R_10_0k.S1_Conf_Int[1,1],R_12_5k.S1_Conf_Int[1,1],R_15_0k.S1_Conf_Int[1,1],R_17_5k.S1_Conf_Int[1,1],R_20_0k.S1_Conf_Int[1,1],R_25_0k.S1_Conf_Int[1,1],R_30_0k.S1_Conf_Int[1,1], R_35_0k.S1_Conf_Int[1,1],R_40_0k.S1_Conf_Int[1,1],R_45_0k.S1_Conf_Int[1,1],  R_50_0k.S1_Conf_Int[1,1],  R_50_0k.S1_Conf_Int[1,1],  R_60_0k.S1_Conf_Int[1,1],  R_65_0k.S1_Conf_Int[1,1],  R_70_0k.S1_Conf_Int[1,1],  R_75_0k.S1_Conf_Int[1,1],  R_80_0k.S1_Conf_Int[1,1],  R_85_0k.S1_Conf_Int[1,1],  R_90_0k.S1_Conf_Int[1,1],  R_95_0k.S1_Conf_Int[1,1],  R_100_0k.S1_Conf_Int[1,1],  R_105_0k.S1_Conf_Int[1,1],  R_110_0k.S1_Conf_Int[1,1],  R_115_0k.S1_Conf_Int[1,1],  R_120_0k.S1_Conf_Int[1,1],  R_125_0k.S1_Conf_Int[1,1],  R_130_0k.S1_Conf_Int[1,1],  R_135_0k.S1_Conf_Int[1,1],  R_140_0k.S1_Conf_Int[1,1],  R_145_0k.S1_Conf_Int[1,1],  R_150_0k.S1_Conf_Int[1,1]]
        
            PSV_R_S1_E = [R_0_1k.S1_Conf_Int[3,1], R_0_2k.S1_Conf_Int[3,1],R_0_3k.S1_Conf_Int[3,1] ,R_0_4k.S1_Conf_Int[3,1] ,R_0_5k.S1_Conf_Int[3,1] ,R_0_6k.S1_Conf_Int[3,1] , R_0_7k.S1_Conf_Int[3,1] ,R_0_8k.S1_Conf_Int[3,1] ,R_0_9k.S1_Conf_Int[3,1] ,R_1_0k.S1_Conf_Int[3,1] ,R_1_2k.S1_Conf_Int[3,1] ,R_1_4k.S1_Conf_Int[3,1] ,R_1_6k.S1_Conf_Int[3,1] , R_1_8k.S1_Conf_Int[3,1] ,R_2_0k.S1_Conf_Int[3,1] ,R_2_3k.S1_Conf_Int[3,1] ,R_2_6k.S1_Conf_Int[3,1] ,R_2_9k.S1_Conf_Int[3,1] ,R_3_0k.S1_Conf_Int[3,1] ,R_3_5k.S1_Conf_Int[3,1] , R_4_0k.S1_Conf_Int[3,1] ,R_4_5k.S1_Conf_Int[3,1] ,R_5_0k.S1_Conf_Int[3,1] ,R_6_0k.S1_Conf_Int[3,1] ,R_7_0k.S1_Conf_Int[3,1] ,R_8_0k.S1_Conf_Int[3,1] ,R_9_0k.S1_Conf_Int[3,1] , R_10_0k.S1_Conf_Int[3,1],R_12_5k.S1_Conf_Int[3,1],R_15_0k.S1_Conf_Int[3,1],R_17_5k.S1_Conf_Int[3,1],R_20_0k.S1_Conf_Int[3,1],R_25_0k.S1_Conf_Int[3,1],R_30_0k.S1_Conf_Int[3,1], R_35_0k.S1_Conf_Int[3,1],R_40_0k.S1_Conf_Int[3,1],R_45_0k.S1_Conf_Int[3,1],  R_50_0k.S1_Conf_Int[3,1],  R_50_0k.S1_Conf_Int[3,1],  R_60_0k.S1_Conf_Int[3,1],  R_65_0k.S1_Conf_Int[3,1],  R_70_0k.S1_Conf_Int[3,1],  R_75_0k.S1_Conf_Int[3,1],  R_80_0k.S1_Conf_Int[3,1],  R_85_0k.S1_Conf_Int[3,1],  R_90_0k.S1_Conf_Int[3,1],  R_95_0k.S1_Conf_Int[3,1],  R_100_0k.S1_Conf_Int[3,1],  R_105_0k.S1_Conf_Int[3,1],  R_110_0k.S1_Conf_Int[3,1],  R_115_0k.S1_Conf_Int[3,1],  R_120_0k.S1_Conf_Int[3,1],  R_125_0k.S1_Conf_Int[3,1],  R_130_0k.S1_Conf_Int[3,1],  R_135_0k.S1_Conf_Int[3,1],  R_140_0k.S1_Conf_Int[3,1],  R_145_0k.S1_Conf_Int[3,1],  R_150_0k.S1_Conf_Int[3,1]]
        end

        # High and Low errors reg S1 #
        # Cardiac Output
        LowE_CO_R_S1 = CO_R_S1 .- (1.96 .*CO_R_S1_E)
        HighE_CO_R_S1 = CO_R_S1 .+ (1.96 .*CO_R_S1_E)
        # Max PLV
        LowE_PLV_R_S1 = PLV_R_S1 .- (1.96 .*PLV_R_S1_E)
        HighE_PLV_R_S1 = PLV_R_S1 .+ (1.96 .*PLV_R_S1_E)
        # Max PSV
        LowE_PSV_R_S1 = PSV_R_S1 .- (1.96 .*PSV_R_S1_E)
        HighE_PSV_R_S1 = PSV_R_S1 .+ (1.96 .*PSV_R_S1_E)
    end 
    #CO S1 UR
    band!(x[1:end], min.(LowE_CO_R_S1, HighE_CO_R_S1), max.(LowE_CO_R_S1, HighE_CO_R_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_R_S1, HighE_PLV_R_S1), max.(LowE_PLV_R_S1, HighE_PLV_R_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_R_S1, HighE_PSV_R_S1), max.(LowE_PSV_R_S1, HighE_PSV_R_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_S1, label = "PSV")
    hidexdecorations!(axa, grid = false)


    axb = Axis(gb[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    Label(gb[1, 1, Left()], L"E_{max}", valign = :center, font = :bold, padding = (0, 35, 0, 0))
    #Emax S1 reg data
    begin
        ## load Reg data for CO PSV PLV S1 ##
        begin
            CO_R_S1 = [R_0_1k.S1[10,9], R_0_2k.S1[10,9],R_0_3k.S1[10,9] ,R_0_4k.S1[10,9] ,R_0_5k.S1[10,9] ,R_0_6k.S1[10,9] ,  R_0_7k.S1[10,9] ,R_0_8k.S1[10,9] ,R_0_9k.S1[10,9] ,R_1_0k.S1[10,9] ,R_1_2k.S1[10,9] ,R_1_4k.S1[10,9] ,R_1_6k.S1[10,9] ,  R_1_8k.S1[10,9] ,R_2_0k.S1[10,9] ,R_2_3k.S1[10,9] ,R_2_6k.S1[10,9] ,R_2_9k.S1[10,9] ,R_3_0k.S1[10,9] ,R_3_5k.S1[10,9] ,  R_4_0k.S1[10,9] ,R_4_5k.S1[10,9] ,R_5_0k.S1[10,9] ,R_6_0k.S1[10,9] ,R_7_0k.S1[10,9] ,R_8_0k.S1[10,9] ,R_9_0k.S1[10,9] ,  R_10_0k.S1[10,9],R_12_5k.S1[10,9],R_15_0k.S1[10,9],R_17_5k.S1[10,9],R_20_0k.S1[10,9],R_25_0k.S1[10,9],R_30_0k.S1[10,9],  R_35_0k.S1[10,9],R_40_0k.S1[10,9],R_45_0k.S1[10,9],  R_50_0k.S1[10,9],  R_50_0k.S1[10,9],  R_60_0k.S1[10,9],  R_65_0k.S1[10,9],  R_70_0k.S1[10,9],  R_75_0k.S1[10,9],  R_80_0k.S1[10,9],  R_85_0k.S1[10,9],  R_90_0k.S1[10,9],  R_95_0k.S1[10,9],  R_100_0k.S1[10,9],  R_105_0k.S1[10,9],  R_110_0k.S1[10,9],  R_115_0k.S1[10,9],  R_120_0k.S1[10,9],  R_125_0k.S1[10,9],  R_130_0k.S1[10,9],  R_135_0k.S1[10,9],  R_140_0k.S1[10,9],  R_145_0k.S1[10,9],  R_150_0k.S1[10,9]]
        
            PLV_R_S1 = [R_0_1k.S1[1,9], R_0_2k.S1[1,9],R_0_3k.S1[1,9] ,R_0_4k.S1[1,9] ,R_0_5k.S1[1,9] ,R_0_6k.S1[1,9] , R_0_7k.S1[1,9] ,R_0_8k.S1[1,9] ,R_0_9k.S1[1,9] ,R_1_0k.S1[1,9] ,R_1_2k.S1[1,9] ,R_1_4k.S1[1,9] ,R_1_6k.S1[1,9] , R_1_8k.S1[1,9] ,R_2_0k.S1[1,9] ,R_2_3k.S1[1,9] ,R_2_6k.S1[1,9] ,R_2_9k.S1[1,9] ,R_3_0k.S1[1,9] ,R_3_5k.S1[1,9] , R_4_0k.S1[1,9] ,R_4_5k.S1[1,9] ,R_5_0k.S1[1,9] ,R_6_0k.S1[1,9] ,R_7_0k.S1[1,9] ,R_8_0k.S1[1,9] ,R_9_0k.S1[1,9] , R_10_0k.S1[1,9],R_12_5k.S1[1,9],R_15_0k.S1[1,9],R_17_5k.S1[1,9],R_20_0k.S1[1,9],R_25_0k.S1[1,9],R_30_0k.S1[1,9], R_35_0k.S1[1,9],R_40_0k.S1[1,9],R_45_0k.S1[1,9],  R_50_0k.S1[1,9],  R_50_0k.S1[1,9],  R_60_0k.S1[1,9],  R_65_0k.S1[1,9],  R_70_0k.S1[1,9],  R_75_0k.S1[1,9],  R_80_0k.S1[1,9],  R_85_0k.S1[1,9],  R_90_0k.S1[1,9],  R_95_0k.S1[1,9],  R_100_0k.S1[1,9],  R_105_0k.S1[1,9],  R_110_0k.S1[1,9],  R_115_0k.S1[1,9],  R_120_0k.S1[1,9],  R_125_0k.S1[1,9],  R_130_0k.S1[1,9],  R_135_0k.S1[1,9],  R_140_0k.S1[1,9],  R_145_0k.S1[1,9],  R_150_0k.S1[1,9]]
        
            PSV_R_S1 = [R_0_1k.S1[3,9], R_0_2k.S1[3,9],R_0_3k.S1[3,9] ,R_0_4k.S1[3,9] ,R_0_5k.S1[3,9] ,R_0_6k.S1[3,9] , R_0_7k.S1[3,9] ,R_0_8k.S1[3,9] ,R_0_9k.S1[3,9] ,R_1_0k.S1[3,9] ,R_1_2k.S1[3,9] ,R_1_4k.S1[3,9] ,R_1_6k.S1[3,9] , R_1_8k.S1[3,9] ,R_2_0k.S1[3,9] ,R_2_3k.S1[3,9] ,R_2_6k.S1[3,9] ,R_2_9k.S1[3,9] ,R_3_0k.S1[3,9] ,R_3_5k.S1[3,9] , R_4_0k.S1[3,9] ,R_4_5k.S1[3,9] ,R_5_0k.S1[3,9] ,R_6_0k.S1[3,9] ,R_7_0k.S1[3,9] ,R_8_0k.S1[3,9] ,R_9_0k.S1[3,9] , R_10_0k.S1[3,9],R_12_5k.S1[3,9],R_15_0k.S1[3,9],R_17_5k.S1[3,9],R_20_0k.S1[3,9],R_25_0k.S1[3,9],R_30_0k.S1[3,9], R_35_0k.S1[3,9],R_40_0k.S1[3,9],R_45_0k.S1[3,9],  R_50_0k.S1[3,9],  R_50_0k.S1[3,9],  R_60_0k.S1[3,9],  R_65_0k.S1[3,9],  R_70_0k.S1[3,9],  R_75_0k.S1[3,9],  R_80_0k.S1[3,9],  R_85_0k.S1[3,9],  R_90_0k.S1[3,9],  R_95_0k.S1[3,9],  R_100_0k.S1[3,9],  R_105_0k.S1[3,9],  R_110_0k.S1[3,9],  R_115_0k.S1[3,9],  R_120_0k.S1[3,9],  R_125_0k.S1[3,9],  R_130_0k.S1[3,9],  R_135_0k.S1[3,9],  R_140_0k.S1[3,9],  R_145_0k.S1[3,9],  R_150_0k.S1[3,9]]
        end

        ## R errors for CO PSV PLV S1 ##
        begin
            CO_R_S1_E = [R_0_1k.S1_Conf_Int[10,9], R_0_2k.S1_Conf_Int[10,9],R_0_3k.S1_Conf_Int[10,9] ,R_0_4k.S1_Conf_Int[10,9] ,R_0_5k.S1_Conf_Int[10,9] ,R_0_6k.S1_Conf_Int[10,9] ,  R_0_7k.S1_Conf_Int[10,9] ,R_0_8k.S1_Conf_Int[10,9] ,R_0_9k.S1_Conf_Int[10,9] ,R_1_0k.S1_Conf_Int[10,9] ,R_1_2k.S1_Conf_Int[10,9] ,R_1_4k.S1_Conf_Int[10,9] ,R_1_6k.S1_Conf_Int[10,9] ,  R_1_8k.S1_Conf_Int[10,9] ,R_2_0k.S1_Conf_Int[10,9] ,R_2_3k.S1_Conf_Int[10,9] ,R_2_6k.S1_Conf_Int[10,9] ,R_2_9k.S1_Conf_Int[10,9] ,R_3_0k.S1_Conf_Int[10,9] ,R_3_5k.S1_Conf_Int[10,9] ,  R_4_0k.S1_Conf_Int[10,9] ,R_4_5k.S1_Conf_Int[10,9] ,R_5_0k.S1_Conf_Int[10,9] ,R_6_0k.S1_Conf_Int[10,9] ,R_7_0k.S1_Conf_Int[10,9] ,R_8_0k.S1_Conf_Int[10,9] ,R_9_0k.S1_Conf_Int[10,9] ,  R_10_0k.S1_Conf_Int[10,9],R_12_5k.S1_Conf_Int[10,9],R_15_0k.S1_Conf_Int[10,9],R_17_5k.S1_Conf_Int[10,9],R_20_0k.S1_Conf_Int[10,9],R_25_0k.S1_Conf_Int[10,9],R_30_0k.S1_Conf_Int[10,9],  R_35_0k.S1_Conf_Int[10,9],R_40_0k.S1_Conf_Int[10,9],R_45_0k.S1_Conf_Int[10,9],  R_50_0k.S1_Conf_Int[10,9],  R_50_0k.S1_Conf_Int[10,9],  R_60_0k.S1_Conf_Int[10,9],  R_65_0k.S1_Conf_Int[10,9],  R_70_0k.S1_Conf_Int[10,9],  R_75_0k.S1_Conf_Int[10,9],  R_80_0k.S1_Conf_Int[10,9],  R_85_0k.S1_Conf_Int[10,9],  R_90_0k.S1_Conf_Int[10,9],  R_95_0k.S1_Conf_Int[10,9],  R_100_0k.S1_Conf_Int[10,9],  R_105_0k.S1_Conf_Int[10,9],  R_110_0k.S1_Conf_Int[10,9],  R_115_0k.S1_Conf_Int[10,9],  R_120_0k.S1_Conf_Int[10,9],  R_125_0k.S1_Conf_Int[10,9],  R_130_0k.S1_Conf_Int[10,9],  R_135_0k.S1_Conf_Int[10,9],  R_140_0k.S1_Conf_Int[10,9],  R_145_0k.S1_Conf_Int[10,9],  R_150_0k.S1_Conf_Int[10,9]]
        
            PLV_R_S1_E = [R_0_1k.S1_Conf_Int[1,9], R_0_2k.S1_Conf_Int[1,9],R_0_3k.S1_Conf_Int[1,9] ,R_0_4k.S1_Conf_Int[1,9] ,R_0_5k.S1_Conf_Int[1,9] ,R_0_6k.S1_Conf_Int[1,9] , R_0_7k.S1_Conf_Int[1,9] ,R_0_8k.S1_Conf_Int[1,9] ,R_0_9k.S1_Conf_Int[1,9] ,R_1_0k.S1_Conf_Int[1,9] ,R_1_2k.S1_Conf_Int[1,9] ,R_1_4k.S1_Conf_Int[1,9] ,R_1_6k.S1_Conf_Int[1,9] , R_1_8k.S1_Conf_Int[1,9] ,R_2_0k.S1_Conf_Int[1,9] ,R_2_3k.S1_Conf_Int[1,9] ,R_2_6k.S1_Conf_Int[1,9] ,R_2_9k.S1_Conf_Int[1,9] ,R_3_0k.S1_Conf_Int[1,9] ,R_3_5k.S1_Conf_Int[1,9] , R_4_0k.S1_Conf_Int[1,9] ,R_4_5k.S1_Conf_Int[1,9] ,R_5_0k.S1_Conf_Int[1,9] ,R_6_0k.S1_Conf_Int[1,9] ,R_7_0k.S1_Conf_Int[1,9] ,R_8_0k.S1_Conf_Int[1,9] ,R_9_0k.S1_Conf_Int[1,9] , R_10_0k.S1_Conf_Int[1,9],R_12_5k.S1_Conf_Int[1,9],R_15_0k.S1_Conf_Int[1,9],R_17_5k.S1_Conf_Int[1,9],R_20_0k.S1_Conf_Int[1,9],R_25_0k.S1_Conf_Int[1,9],R_30_0k.S1_Conf_Int[1,9], R_35_0k.S1_Conf_Int[1,9],R_40_0k.S1_Conf_Int[1,9],R_45_0k.S1_Conf_Int[1,9],  R_50_0k.S1_Conf_Int[1,9],  R_50_0k.S1_Conf_Int[1,9],  R_60_0k.S1_Conf_Int[1,9],  R_65_0k.S1_Conf_Int[1,9],  R_70_0k.S1_Conf_Int[1,9],  R_75_0k.S1_Conf_Int[1,9],  R_80_0k.S1_Conf_Int[1,9],  R_85_0k.S1_Conf_Int[1,9],  R_90_0k.S1_Conf_Int[1,9],  R_95_0k.S1_Conf_Int[1,9],  R_100_0k.S1_Conf_Int[1,9],  R_105_0k.S1_Conf_Int[1,9],  R_110_0k.S1_Conf_Int[1,9],  R_115_0k.S1_Conf_Int[1,9],  R_120_0k.S1_Conf_Int[1,9],  R_125_0k.S1_Conf_Int[1,9],  R_130_0k.S1_Conf_Int[1,9],  R_135_0k.S1_Conf_Int[1,9],  R_140_0k.S1_Conf_Int[1,9],  R_145_0k.S1_Conf_Int[1,9],  R_150_0k.S1_Conf_Int[1,9]]
        
            PSV_R_S1_E = [R_0_1k.S1_Conf_Int[3,9], R_0_2k.S1_Conf_Int[3,9],R_0_3k.S1_Conf_Int[3,9] ,R_0_4k.S1_Conf_Int[3,9] ,R_0_5k.S1_Conf_Int[3,9] ,R_0_6k.S1_Conf_Int[3,9] , R_0_7k.S1_Conf_Int[3,9] ,R_0_8k.S1_Conf_Int[3,9] ,R_0_9k.S1_Conf_Int[3,9] ,R_1_0k.S1_Conf_Int[3,9] ,R_1_2k.S1_Conf_Int[3,9] ,R_1_4k.S1_Conf_Int[3,9] ,R_1_6k.S1_Conf_Int[3,9] , R_1_8k.S1_Conf_Int[3,9] ,R_2_0k.S1_Conf_Int[3,9] ,R_2_3k.S1_Conf_Int[3,9] ,R_2_6k.S1_Conf_Int[3,9] ,R_2_9k.S1_Conf_Int[3,9] ,R_3_0k.S1_Conf_Int[3,9] ,R_3_5k.S1_Conf_Int[3,9] , R_4_0k.S1_Conf_Int[3,9] ,R_4_5k.S1_Conf_Int[3,9] ,R_5_0k.S1_Conf_Int[3,9] ,R_6_0k.S1_Conf_Int[3,9] ,R_7_0k.S1_Conf_Int[3,9] ,R_8_0k.S1_Conf_Int[3,9] ,R_9_0k.S1_Conf_Int[3,9] , R_10_0k.S1_Conf_Int[3,9],R_12_5k.S1_Conf_Int[3,9],R_15_0k.S1_Conf_Int[3,9],R_17_5k.S1_Conf_Int[3,9],R_20_0k.S1_Conf_Int[3,9],R_25_0k.S1_Conf_Int[3,9],R_30_0k.S1_Conf_Int[3,9], R_35_0k.S1_Conf_Int[3,9],R_40_0k.S1_Conf_Int[3,9],R_45_0k.S1_Conf_Int[3,9],  R_50_0k.S1_Conf_Int[3,9],  R_50_0k.S1_Conf_Int[3,9],  R_60_0k.S1_Conf_Int[3,9],  R_65_0k.S1_Conf_Int[3,9],  R_70_0k.S1_Conf_Int[3,9],  R_75_0k.S1_Conf_Int[3,9],  R_80_0k.S1_Conf_Int[3,9],  R_85_0k.S1_Conf_Int[3,9],  R_90_0k.S1_Conf_Int[3,9],  R_95_0k.S1_Conf_Int[3,9],  R_100_0k.S1_Conf_Int[3,9],  R_105_0k.S1_Conf_Int[3,9],  R_110_0k.S1_Conf_Int[3,9],  R_115_0k.S1_Conf_Int[3,9],  R_120_0k.S1_Conf_Int[3,9],  R_125_0k.S1_Conf_Int[3,9],  R_130_0k.S1_Conf_Int[3,9],  R_135_0k.S1_Conf_Int[3,9],  R_140_0k.S1_Conf_Int[3,9],  R_145_0k.S1_Conf_Int[3,9],  R_150_0k.S1_Conf_Int[3,9]]
        end

        # High and Low errors reg S1 #
        # Cardiac Output
        LowE_CO_R_S1 = CO_R_S1 .- (1.96 .*CO_R_S1_E)
        HighE_CO_R_S1 = CO_R_S1 .+ (1.96 .*CO_R_S1_E)
        # Max PLV
        LowE_PLV_R_S1 = PLV_R_S1 .- (1.96 .*PLV_R_S1_E)
        HighE_PLV_R_S1 = PLV_R_S1 .+ (1.96 .*PLV_R_S1_E)
        # Max PSV
        LowE_PSV_R_S1 = PSV_R_S1 .- (1.96 .*PSV_R_S1_E)
        HighE_PSV_R_S1 = PSV_R_S1 .+ (1.96 .*PSV_R_S1_E)
    end 
    #CO S1 UR
    band!(x[1:end], min.(LowE_CO_R_S1, HighE_CO_R_S1), max.(LowE_CO_R_S1, HighE_CO_R_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_R_S1, HighE_PLV_R_S1), max.(LowE_PLV_R_S1, HighE_PLV_R_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_R_S1, HighE_PSV_R_S1), max.(LowE_PSV_R_S1, HighE_PSV_R_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_S1, label = "PSV")
    hidexdecorations!(axb, grid = false)

    axc = Axis(gc[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    Label(gc[1, 1, Left()], L"E_{min}", valign = :center, font = :bold, padding = (0, 35, 0, 0))
    #Emin S1 reg data
    begin
        ## load Reg data for CO PSV PLV S1 ##
        begin
            CO_R_S1 = [R_0_1k.S1[10,10], R_0_2k.S1[10,10],R_0_3k.S1[10,10] ,R_0_4k.S1[10,10] ,R_0_5k.S1[10,10] ,R_0_6k.S1[10,10] ,  R_0_7k.S1[10,10] ,R_0_8k.S1[10,10] ,R_0_9k.S1[10,10] ,R_1_0k.S1[10,10] ,R_1_2k.S1[10,10] ,R_1_4k.S1[10,10] ,R_1_6k.S1[10,10] ,  R_1_8k.S1[10,10] ,R_2_0k.S1[10,10] ,R_2_3k.S1[10,10] ,R_2_6k.S1[10,10] ,R_2_9k.S1[10,10] ,R_3_0k.S1[10,10] ,R_3_5k.S1[10,10] ,  R_4_0k.S1[10,10] ,R_4_5k.S1[10,10] ,R_5_0k.S1[10,10] ,R_6_0k.S1[10,10] ,R_7_0k.S1[10,10] ,R_8_0k.S1[10,10] ,R_9_0k.S1[10,10] ,  R_10_0k.S1[10,10],R_12_5k.S1[10,10],R_15_0k.S1[10,10],R_17_5k.S1[10,10],R_20_0k.S1[10,10],R_25_0k.S1[10,10],R_30_0k.S1[10,10],  R_35_0k.S1[10,10],R_40_0k.S1[10,10],R_45_0k.S1[10,10],  R_50_0k.S1[10,10],  R_50_0k.S1[10,10],  R_60_0k.S1[10,10],  R_65_0k.S1[10,10],  R_70_0k.S1[10,10],  R_75_0k.S1[10,10],  R_80_0k.S1[10,10],  R_85_0k.S1[10,10],  R_90_0k.S1[10,10],  R_95_0k.S1[10,10],  R_100_0k.S1[10,10],  R_105_0k.S1[10,10],  R_110_0k.S1[10,10],  R_115_0k.S1[10,10],  R_120_0k.S1[10,10],  R_125_0k.S1[10,10],  R_130_0k.S1[10,10],  R_135_0k.S1[10,10],  R_140_0k.S1[10,10],  R_145_0k.S1[10,10],  R_150_0k.S1[10,10]]
        
            PLV_R_S1 = [R_0_1k.S1[1,10], R_0_2k.S1[1,10],R_0_3k.S1[1,10] ,R_0_4k.S1[1,10] ,R_0_5k.S1[1,10] ,R_0_6k.S1[1,10] , R_0_7k.S1[1,10] ,R_0_8k.S1[1,10] ,R_0_9k.S1[1,10] ,R_1_0k.S1[1,10] ,R_1_2k.S1[1,10] ,R_1_4k.S1[1,10] ,R_1_6k.S1[1,10] , R_1_8k.S1[1,10] ,R_2_0k.S1[1,10] ,R_2_3k.S1[1,10] ,R_2_6k.S1[1,10] ,R_2_9k.S1[1,10] ,R_3_0k.S1[1,10] ,R_3_5k.S1[1,10] , R_4_0k.S1[1,10] ,R_4_5k.S1[1,10] ,R_5_0k.S1[1,10] ,R_6_0k.S1[1,10] ,R_7_0k.S1[1,10] ,R_8_0k.S1[1,10] ,R_9_0k.S1[1,10] , R_10_0k.S1[1,10],R_12_5k.S1[1,10],R_15_0k.S1[1,10],R_17_5k.S1[1,10],R_20_0k.S1[1,10],R_25_0k.S1[1,10],R_30_0k.S1[1,10], R_35_0k.S1[1,10],R_40_0k.S1[1,10],R_45_0k.S1[1,10],  R_50_0k.S1[1,10],  R_50_0k.S1[1,10],  R_60_0k.S1[1,10],  R_65_0k.S1[1,10],  R_70_0k.S1[1,10],  R_75_0k.S1[1,10],  R_80_0k.S1[1,10],  R_85_0k.S1[1,10],  R_90_0k.S1[1,10],  R_95_0k.S1[1,10],  R_100_0k.S1[1,10],  R_105_0k.S1[1,10],  R_110_0k.S1[1,10],  R_115_0k.S1[1,10],  R_120_0k.S1[1,10],  R_125_0k.S1[1,10],  R_130_0k.S1[1,10],  R_135_0k.S1[1,10],  R_140_0k.S1[1,10],  R_145_0k.S1[1,10],  R_150_0k.S1[1,10]]
        
            PSV_R_S1 = [R_0_1k.S1[3,10], R_0_2k.S1[3,10],R_0_3k.S1[3,10] ,R_0_4k.S1[3,10] ,R_0_5k.S1[3,10] ,R_0_6k.S1[3,10] , R_0_7k.S1[3,10] ,R_0_8k.S1[3,10] ,R_0_9k.S1[3,10] ,R_1_0k.S1[3,10] ,R_1_2k.S1[3,10] ,R_1_4k.S1[3,10] ,R_1_6k.S1[3,10] , R_1_8k.S1[3,10] ,R_2_0k.S1[3,10] ,R_2_3k.S1[3,10] ,R_2_6k.S1[3,10] ,R_2_9k.S1[3,10] ,R_3_0k.S1[3,10] ,R_3_5k.S1[3,10] , R_4_0k.S1[3,10] ,R_4_5k.S1[3,10] ,R_5_0k.S1[3,10] ,R_6_0k.S1[3,10] ,R_7_0k.S1[3,10] ,R_8_0k.S1[3,10] ,R_9_0k.S1[3,10] , R_10_0k.S1[3,10],R_12_5k.S1[3,10],R_15_0k.S1[3,10],R_17_5k.S1[3,10],R_20_0k.S1[3,10],R_25_0k.S1[3,10],R_30_0k.S1[3,10], R_35_0k.S1[3,10],R_40_0k.S1[3,10],R_45_0k.S1[3,10],  R_50_0k.S1[3,10],  R_50_0k.S1[3,10],  R_60_0k.S1[3,10],  R_65_0k.S1[3,10],  R_70_0k.S1[3,10],  R_75_0k.S1[3,10],  R_80_0k.S1[3,10],  R_85_0k.S1[3,10],  R_90_0k.S1[3,10],  R_95_0k.S1[3,10],  R_100_0k.S1[3,10],  R_105_0k.S1[3,10],  R_110_0k.S1[3,10],  R_115_0k.S1[3,10],  R_120_0k.S1[3,10],  R_125_0k.S1[3,10],  R_130_0k.S1[3,10],  R_135_0k.S1[3,10],  R_140_0k.S1[3,10],  R_145_0k.S1[3,10],  R_150_0k.S1[3,10]]
        end
    
        ## R errors for CO PSV PLV S1 ##
        begin
            CO_R_S1_E = [R_0_1k.S1_Conf_Int[10,10], R_0_2k.S1_Conf_Int[10,10],R_0_3k.S1_Conf_Int[10,10] ,R_0_4k.S1_Conf_Int[10,10] ,R_0_5k.S1_Conf_Int[10,10] ,R_0_6k.S1_Conf_Int[10,10] ,  R_0_7k.S1_Conf_Int[10,10] ,R_0_8k.S1_Conf_Int[10,10] ,R_0_9k.S1_Conf_Int[10,10] ,R_1_0k.S1_Conf_Int[10,10] ,R_1_2k.S1_Conf_Int[10,10] ,R_1_4k.S1_Conf_Int[10,10] ,R_1_6k.S1_Conf_Int[10,10] ,  R_1_8k.S1_Conf_Int[10,10] ,R_2_0k.S1_Conf_Int[10,10] ,R_2_3k.S1_Conf_Int[10,10] ,R_2_6k.S1_Conf_Int[10,10] ,R_2_9k.S1_Conf_Int[10,10] ,R_3_0k.S1_Conf_Int[10,10] ,R_3_5k.S1_Conf_Int[10,10] ,  R_4_0k.S1_Conf_Int[10,10] ,R_4_5k.S1_Conf_Int[10,10] ,R_5_0k.S1_Conf_Int[10,10] ,R_6_0k.S1_Conf_Int[10,10] ,R_7_0k.S1_Conf_Int[10,10] ,R_8_0k.S1_Conf_Int[10,10] ,R_9_0k.S1_Conf_Int[10,10] ,  R_10_0k.S1_Conf_Int[10,10],R_12_5k.S1_Conf_Int[10,10],R_15_0k.S1_Conf_Int[10,10],R_17_5k.S1_Conf_Int[10,10],R_20_0k.S1_Conf_Int[10,10],R_25_0k.S1_Conf_Int[10,10],R_30_0k.S1_Conf_Int[10,10],  R_35_0k.S1_Conf_Int[10,10],R_40_0k.S1_Conf_Int[10,10],R_45_0k.S1_Conf_Int[10,10],  R_50_0k.S1_Conf_Int[10,10],  R_50_0k.S1_Conf_Int[10,10],  R_60_0k.S1_Conf_Int[10,10],  R_65_0k.S1_Conf_Int[10,10],  R_70_0k.S1_Conf_Int[10,10],  R_75_0k.S1_Conf_Int[10,10],  R_80_0k.S1_Conf_Int[10,10],  R_85_0k.S1_Conf_Int[10,10],  R_90_0k.S1_Conf_Int[10,10],  R_95_0k.S1_Conf_Int[10,10],  R_100_0k.S1_Conf_Int[10,10],  R_105_0k.S1_Conf_Int[10,10],  R_110_0k.S1_Conf_Int[10,10],  R_115_0k.S1_Conf_Int[10,10],  R_120_0k.S1_Conf_Int[10,10],  R_125_0k.S1_Conf_Int[10,10],  R_130_0k.S1_Conf_Int[10,10],  R_135_0k.S1_Conf_Int[10,10],  R_140_0k.S1_Conf_Int[10,10],  R_145_0k.S1_Conf_Int[10,10],  R_150_0k.S1_Conf_Int[10,10]]
        
            PLV_R_S1_E = [R_0_1k.S1_Conf_Int[1,10], R_0_2k.S1_Conf_Int[1,10],R_0_3k.S1_Conf_Int[1,10] ,R_0_4k.S1_Conf_Int[1,10] ,R_0_5k.S1_Conf_Int[1,10] ,R_0_6k.S1_Conf_Int[1,10] , R_0_7k.S1_Conf_Int[1,10] ,R_0_8k.S1_Conf_Int[1,10] ,R_0_9k.S1_Conf_Int[1,10] ,R_1_0k.S1_Conf_Int[1,10] ,R_1_2k.S1_Conf_Int[1,10] ,R_1_4k.S1_Conf_Int[1,10] ,R_1_6k.S1_Conf_Int[1,10] , R_1_8k.S1_Conf_Int[1,10] ,R_2_0k.S1_Conf_Int[1,10] ,R_2_3k.S1_Conf_Int[1,10] ,R_2_6k.S1_Conf_Int[1,10] ,R_2_9k.S1_Conf_Int[1,10] ,R_3_0k.S1_Conf_Int[1,10] ,R_3_5k.S1_Conf_Int[1,10] , R_4_0k.S1_Conf_Int[1,10] ,R_4_5k.S1_Conf_Int[1,10] ,R_5_0k.S1_Conf_Int[1,10] ,R_6_0k.S1_Conf_Int[1,10] ,R_7_0k.S1_Conf_Int[1,10] ,R_8_0k.S1_Conf_Int[1,10] ,R_9_0k.S1_Conf_Int[1,10] , R_10_0k.S1_Conf_Int[1,10],R_12_5k.S1_Conf_Int[1,10],R_15_0k.S1_Conf_Int[1,10],R_17_5k.S1_Conf_Int[1,10],R_20_0k.S1_Conf_Int[1,10],R_25_0k.S1_Conf_Int[1,10],R_30_0k.S1_Conf_Int[1,10], R_35_0k.S1_Conf_Int[1,10],R_40_0k.S1_Conf_Int[1,10],R_45_0k.S1_Conf_Int[1,10],  R_50_0k.S1_Conf_Int[1,10],  R_50_0k.S1_Conf_Int[1,10],  R_60_0k.S1_Conf_Int[1,10],  R_65_0k.S1_Conf_Int[1,10],  R_70_0k.S1_Conf_Int[1,10],  R_75_0k.S1_Conf_Int[1,10],  R_80_0k.S1_Conf_Int[1,10],  R_85_0k.S1_Conf_Int[1,10],  R_90_0k.S1_Conf_Int[1,10],  R_95_0k.S1_Conf_Int[1,10],  R_100_0k.S1_Conf_Int[1,10],  R_105_0k.S1_Conf_Int[1,10],  R_110_0k.S1_Conf_Int[1,10],  R_115_0k.S1_Conf_Int[1,10],  R_120_0k.S1_Conf_Int[1,10],  R_125_0k.S1_Conf_Int[1,10],  R_130_0k.S1_Conf_Int[1,10],  R_135_0k.S1_Conf_Int[1,10],  R_140_0k.S1_Conf_Int[1,10],  R_145_0k.S1_Conf_Int[1,10],  R_150_0k.S1_Conf_Int[1,10]]
        
            PSV_R_S1_E = [R_0_1k.S1_Conf_Int[3,10], R_0_2k.S1_Conf_Int[3,10],R_0_3k.S1_Conf_Int[3,10] ,R_0_4k.S1_Conf_Int[3,10] ,R_0_5k.S1_Conf_Int[3,10] ,R_0_6k.S1_Conf_Int[3,10] , R_0_7k.S1_Conf_Int[3,10] ,R_0_8k.S1_Conf_Int[3,10] ,R_0_9k.S1_Conf_Int[3,10] ,R_1_0k.S1_Conf_Int[3,10] ,R_1_2k.S1_Conf_Int[3,10] ,R_1_4k.S1_Conf_Int[3,10] ,R_1_6k.S1_Conf_Int[3,10] , R_1_8k.S1_Conf_Int[3,10] ,R_2_0k.S1_Conf_Int[3,10] ,R_2_3k.S1_Conf_Int[3,10] ,R_2_6k.S1_Conf_Int[3,10] ,R_2_9k.S1_Conf_Int[3,10] ,R_3_0k.S1_Conf_Int[3,10] ,R_3_5k.S1_Conf_Int[3,10] , R_4_0k.S1_Conf_Int[3,10] ,R_4_5k.S1_Conf_Int[3,10] ,R_5_0k.S1_Conf_Int[3,10] ,R_6_0k.S1_Conf_Int[3,10] ,R_7_0k.S1_Conf_Int[3,10] ,R_8_0k.S1_Conf_Int[3,10] ,R_9_0k.S1_Conf_Int[3,10] , R_10_0k.S1_Conf_Int[3,10],R_12_5k.S1_Conf_Int[3,10],R_15_0k.S1_Conf_Int[3,10],R_17_5k.S1_Conf_Int[3,10],R_20_0k.S1_Conf_Int[3,10],R_25_0k.S1_Conf_Int[3,10],R_30_0k.S1_Conf_Int[3,10], R_35_0k.S1_Conf_Int[3,10],R_40_0k.S1_Conf_Int[3,10],R_45_0k.S1_Conf_Int[3,10],  R_50_0k.S1_Conf_Int[3,10],  R_50_0k.S1_Conf_Int[3,10],  R_60_0k.S1_Conf_Int[3,10],  R_65_0k.S1_Conf_Int[3,10],  R_70_0k.S1_Conf_Int[3,10],  R_75_0k.S1_Conf_Int[3,10],  R_80_0k.S1_Conf_Int[3,10],  R_85_0k.S1_Conf_Int[3,10],  R_90_0k.S1_Conf_Int[3,10],  R_95_0k.S1_Conf_Int[3,10],  R_100_0k.S1_Conf_Int[3,10],  R_105_0k.S1_Conf_Int[3,10],  R_110_0k.S1_Conf_Int[3,10],  R_115_0k.S1_Conf_Int[3,10],  R_120_0k.S1_Conf_Int[3,10],  R_125_0k.S1_Conf_Int[3,10],  R_130_0k.S1_Conf_Int[3,10],  R_135_0k.S1_Conf_Int[3,10],  R_140_0k.S1_Conf_Int[3,10],  R_145_0k.S1_Conf_Int[3,10],  R_150_0k.S1_Conf_Int[3,10]]
        end
    
        # High and Low errors reg S1 #
        # Cardiac Output
        LowE_CO_R_S1 = CO_R_S1 .- (1.96 .*CO_R_S1_E)
        HighE_CO_R_S1 = CO_R_S1 .+ (1.96 .*CO_R_S1_E)
        # Max PLV
        LowE_PLV_R_S1 = PLV_R_S1 .- (1.96 .*PLV_R_S1_E)
        HighE_PLV_R_S1 = PLV_R_S1 .+ (1.96 .*PLV_R_S1_E)
        # Max PSV
        LowE_PSV_R_S1 = PSV_R_S1 .- (1.96 .*PSV_R_S1_E)
        HighE_PSV_R_S1 = PSV_R_S1 .+ (1.96 .*PSV_R_S1_E)
    end 
    #CO S1 UR
    band!(x[1:end], min.(LowE_CO_R_S1, HighE_CO_R_S1), max.(LowE_CO_R_S1, HighE_CO_R_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_R_S1, HighE_PLV_R_S1), max.(LowE_PLV_R_S1, HighE_PLV_R_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_R_S1, HighE_PSV_R_S1), max.(LowE_PSV_R_S1, HighE_PSV_R_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_S1, label = "PSV")
    hidexdecorations!(axc, grid = false)

    axd = Axis(gd[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    Label(gd[1, 1, Left()], L"C_{sa}", valign = :center, font = :bold, padding = (0, 35, 0, 0))
    #Csa S1 reg data
    begin
        ## load Reg data for CO PSV PLV S1 ##
        begin
            CO_R_S1 = [R_0_1k.S1[10,2], R_0_2k.S1[10,2],R_0_3k.S1[10,2] ,R_0_4k.S1[10,2] ,R_0_5k.S1[10,2] ,R_0_6k.S1[10,2] ,  R_0_7k.S1[10,2] ,R_0_8k.S1[10,2] ,R_0_9k.S1[10,2] ,R_1_0k.S1[10,2] ,R_1_2k.S1[10,2] ,R_1_4k.S1[10,2] ,R_1_6k.S1[10,2] ,  R_1_8k.S1[10,2] ,R_2_0k.S1[10,2] ,R_2_3k.S1[10,2] ,R_2_6k.S1[10,2] ,R_2_9k.S1[10,2] ,R_3_0k.S1[10,2] ,R_3_5k.S1[10,2] ,  R_4_0k.S1[10,2] ,R_4_5k.S1[10,2] ,R_5_0k.S1[10,2] ,R_6_0k.S1[10,2] ,R_7_0k.S1[10,2] ,R_8_0k.S1[10,2] ,R_9_0k.S1[10,2] ,  R_10_0k.S1[10,2],R_12_5k.S1[10,2],R_15_0k.S1[10,2],R_17_5k.S1[10,2],R_20_0k.S1[10,2],R_25_0k.S1[10,2],R_30_0k.S1[10,2],  R_35_0k.S1[10,2],R_40_0k.S1[10,2],R_45_0k.S1[10,2],  R_50_0k.S1[10,2],  R_50_0k.S1[10,2],  R_60_0k.S1[10,2],  R_65_0k.S1[10,2],  R_70_0k.S1[10,2],  R_75_0k.S1[10,2],  R_80_0k.S1[10,2],  R_85_0k.S1[10,2],  R_90_0k.S1[10,2],  R_95_0k.S1[10,2],  R_100_0k.S1[10,2],  R_105_0k.S1[10,2],  R_110_0k.S1[10,2],  R_115_0k.S1[10,2],  R_120_0k.S1[10,2],  R_125_0k.S1[10,2],  R_130_0k.S1[10,2],  R_135_0k.S1[10,2],  R_140_0k.S1[10,2],  R_145_0k.S1[10,2],  R_150_0k.S1[10,2]]
        
            PLV_R_S1 = [R_0_1k.S1[1,2], R_0_2k.S1[1,2],R_0_3k.S1[1,2] ,R_0_4k.S1[1,2] ,R_0_5k.S1[1,2] ,R_0_6k.S1[1,2] , R_0_7k.S1[1,2] ,R_0_8k.S1[1,2] ,R_0_9k.S1[1,2] ,R_1_0k.S1[1,2] ,R_1_2k.S1[1,2] ,R_1_4k.S1[1,2] ,R_1_6k.S1[1,2] , R_1_8k.S1[1,2] ,R_2_0k.S1[1,2] ,R_2_3k.S1[1,2] ,R_2_6k.S1[1,2] ,R_2_9k.S1[1,2] ,R_3_0k.S1[1,2] ,R_3_5k.S1[1,2] , R_4_0k.S1[1,2] ,R_4_5k.S1[1,2] ,R_5_0k.S1[1,2] ,R_6_0k.S1[1,2] ,R_7_0k.S1[1,2] ,R_8_0k.S1[1,2] ,R_9_0k.S1[1,2] , R_10_0k.S1[1,2],R_12_5k.S1[1,2],R_15_0k.S1[1,2],R_17_5k.S1[1,2],R_20_0k.S1[1,2],R_25_0k.S1[1,2],R_30_0k.S1[1,2], R_35_0k.S1[1,2],R_40_0k.S1[1,2],R_45_0k.S1[1,2],  R_50_0k.S1[1,2],  R_50_0k.S1[1,2],  R_60_0k.S1[1,2],  R_65_0k.S1[1,2],  R_70_0k.S1[1,2],  R_75_0k.S1[1,2],  R_80_0k.S1[1,2],  R_85_0k.S1[1,2],  R_90_0k.S1[1,2],  R_95_0k.S1[1,2],  R_100_0k.S1[1,2],  R_105_0k.S1[1,2],  R_110_0k.S1[1,2],  R_115_0k.S1[1,2],  R_120_0k.S1[1,2],  R_125_0k.S1[1,2],  R_130_0k.S1[1,2],  R_135_0k.S1[1,2],  R_140_0k.S1[1,2],  R_145_0k.S1[1,2],  R_150_0k.S1[1,2]]
        
            PSV_R_S1 = [R_0_1k.S1[3,2], R_0_2k.S1[3,2],R_0_3k.S1[3,2] ,R_0_4k.S1[3,2] ,R_0_5k.S1[3,2] ,R_0_6k.S1[3,2] , R_0_7k.S1[3,2] ,R_0_8k.S1[3,2] ,R_0_9k.S1[3,2] ,R_1_0k.S1[3,2] ,R_1_2k.S1[3,2] ,R_1_4k.S1[3,2] ,R_1_6k.S1[3,2] , R_1_8k.S1[3,2] ,R_2_0k.S1[3,2] ,R_2_3k.S1[3,2] ,R_2_6k.S1[3,2] ,R_2_9k.S1[3,2] ,R_3_0k.S1[3,2] ,R_3_5k.S1[3,2] , R_4_0k.S1[3,2] ,R_4_5k.S1[3,2] ,R_5_0k.S1[3,2] ,R_6_0k.S1[3,2] ,R_7_0k.S1[3,2] ,R_8_0k.S1[3,2] ,R_9_0k.S1[3,2] , R_10_0k.S1[3,2],R_12_5k.S1[3,2],R_15_0k.S1[3,2],R_17_5k.S1[3,2],R_20_0k.S1[3,2],R_25_0k.S1[3,2],R_30_0k.S1[3,2], R_35_0k.S1[3,2],R_40_0k.S1[3,2],R_45_0k.S1[3,2],  R_50_0k.S1[3,2],  R_50_0k.S1[3,2],  R_60_0k.S1[3,2],  R_65_0k.S1[3,2],  R_70_0k.S1[3,2],  R_75_0k.S1[3,2],  R_80_0k.S1[3,2],  R_85_0k.S1[3,2],  R_90_0k.S1[3,2],  R_95_0k.S1[3,2],  R_100_0k.S1[3,2],  R_105_0k.S1[3,2],  R_110_0k.S1[3,2],  R_115_0k.S1[3,2],  R_120_0k.S1[3,2],  R_125_0k.S1[3,2],  R_130_0k.S1[3,2],  R_135_0k.S1[3,2],  R_140_0k.S1[3,2],  R_145_0k.S1[3,2],  R_150_0k.S1[3,2]]
        end
    
        ## R errors for CO PSV PLV S1 ##
        begin
            CO_R_S1_E = [R_0_1k.S1_Conf_Int[10,2], R_0_2k.S1_Conf_Int[10,2],R_0_3k.S1_Conf_Int[10,2] ,R_0_4k.S1_Conf_Int[10,2] ,R_0_5k.S1_Conf_Int[10,2] ,R_0_6k.S1_Conf_Int[10,2] ,  R_0_7k.S1_Conf_Int[10,2] ,R_0_8k.S1_Conf_Int[10,2] ,R_0_9k.S1_Conf_Int[10,2] ,R_1_0k.S1_Conf_Int[10,2] ,R_1_2k.S1_Conf_Int[10,2] ,R_1_4k.S1_Conf_Int[10,2] ,R_1_6k.S1_Conf_Int[10,2] ,  R_1_8k.S1_Conf_Int[10,2] ,R_2_0k.S1_Conf_Int[10,2] ,R_2_3k.S1_Conf_Int[10,2] ,R_2_6k.S1_Conf_Int[10,2] ,R_2_9k.S1_Conf_Int[10,2] ,R_3_0k.S1_Conf_Int[10,2] ,R_3_5k.S1_Conf_Int[10,2] ,  R_4_0k.S1_Conf_Int[10,2] ,R_4_5k.S1_Conf_Int[10,2] ,R_5_0k.S1_Conf_Int[10,2] ,R_6_0k.S1_Conf_Int[10,2] ,R_7_0k.S1_Conf_Int[10,2] ,R_8_0k.S1_Conf_Int[10,2] ,R_9_0k.S1_Conf_Int[10,2] ,  R_10_0k.S1_Conf_Int[10,2],R_12_5k.S1_Conf_Int[10,2],R_15_0k.S1_Conf_Int[10,2],R_17_5k.S1_Conf_Int[10,2],R_20_0k.S1_Conf_Int[10,2],R_25_0k.S1_Conf_Int[10,2],R_30_0k.S1_Conf_Int[10,2],  R_35_0k.S1_Conf_Int[10,2],R_40_0k.S1_Conf_Int[10,2],R_45_0k.S1_Conf_Int[10,2],  R_50_0k.S1_Conf_Int[10,2],  R_50_0k.S1_Conf_Int[10,2],  R_60_0k.S1_Conf_Int[10,2],  R_65_0k.S1_Conf_Int[10,2],  R_70_0k.S1_Conf_Int[10,2],  R_75_0k.S1_Conf_Int[10,2],  R_80_0k.S1_Conf_Int[10,2],  R_85_0k.S1_Conf_Int[10,2],  R_90_0k.S1_Conf_Int[10,2],  R_95_0k.S1_Conf_Int[10,2],  R_100_0k.S1_Conf_Int[10,2],  R_105_0k.S1_Conf_Int[10,2],  R_110_0k.S1_Conf_Int[10,2],  R_115_0k.S1_Conf_Int[10,2],  R_120_0k.S1_Conf_Int[10,2],  R_125_0k.S1_Conf_Int[10,2],  R_130_0k.S1_Conf_Int[10,2],  R_135_0k.S1_Conf_Int[10,2],  R_140_0k.S1_Conf_Int[10,2],  R_145_0k.S1_Conf_Int[10,2],  R_150_0k.S1_Conf_Int[10,2]]
        
            PLV_R_S1_E = [R_0_1k.S1_Conf_Int[1,2], R_0_2k.S1_Conf_Int[1,2],R_0_3k.S1_Conf_Int[1,2] ,R_0_4k.S1_Conf_Int[1,2] ,R_0_5k.S1_Conf_Int[1,2] ,R_0_6k.S1_Conf_Int[1,2] , R_0_7k.S1_Conf_Int[1,2] ,R_0_8k.S1_Conf_Int[1,2] ,R_0_9k.S1_Conf_Int[1,2] ,R_1_0k.S1_Conf_Int[1,2] ,R_1_2k.S1_Conf_Int[1,2] ,R_1_4k.S1_Conf_Int[1,2] ,R_1_6k.S1_Conf_Int[1,2] , R_1_8k.S1_Conf_Int[1,2] ,R_2_0k.S1_Conf_Int[1,2] ,R_2_3k.S1_Conf_Int[1,2] ,R_2_6k.S1_Conf_Int[1,2] ,R_2_9k.S1_Conf_Int[1,2] ,R_3_0k.S1_Conf_Int[1,2] ,R_3_5k.S1_Conf_Int[1,2] , R_4_0k.S1_Conf_Int[1,2] ,R_4_5k.S1_Conf_Int[1,2] ,R_5_0k.S1_Conf_Int[1,2] ,R_6_0k.S1_Conf_Int[1,2] ,R_7_0k.S1_Conf_Int[1,2] ,R_8_0k.S1_Conf_Int[1,2] ,R_9_0k.S1_Conf_Int[1,2] , R_10_0k.S1_Conf_Int[1,2],R_12_5k.S1_Conf_Int[1,2],R_15_0k.S1_Conf_Int[1,2],R_17_5k.S1_Conf_Int[1,2],R_20_0k.S1_Conf_Int[1,2],R_25_0k.S1_Conf_Int[1,2],R_30_0k.S1_Conf_Int[1,2], R_35_0k.S1_Conf_Int[1,2],R_40_0k.S1_Conf_Int[1,2],R_45_0k.S1_Conf_Int[1,2],  R_50_0k.S1_Conf_Int[1,2],  R_50_0k.S1_Conf_Int[1,2],  R_60_0k.S1_Conf_Int[1,2],  R_65_0k.S1_Conf_Int[1,2],  R_70_0k.S1_Conf_Int[1,2],  R_75_0k.S1_Conf_Int[1,2],  R_80_0k.S1_Conf_Int[1,2],  R_85_0k.S1_Conf_Int[1,2],  R_90_0k.S1_Conf_Int[1,2],  R_95_0k.S1_Conf_Int[1,2],  R_100_0k.S1_Conf_Int[1,2],  R_105_0k.S1_Conf_Int[1,2],  R_110_0k.S1_Conf_Int[1,2],  R_115_0k.S1_Conf_Int[1,2],  R_120_0k.S1_Conf_Int[1,2],  R_125_0k.S1_Conf_Int[1,2],  R_130_0k.S1_Conf_Int[1,2],  R_135_0k.S1_Conf_Int[1,2],  R_140_0k.S1_Conf_Int[1,2],  R_145_0k.S1_Conf_Int[1,2],  R_150_0k.S1_Conf_Int[1,2]]
        
            PSV_R_S1_E = [R_0_1k.S1_Conf_Int[3,2], R_0_2k.S1_Conf_Int[3,2],R_0_3k.S1_Conf_Int[3,2] ,R_0_4k.S1_Conf_Int[3,2] ,R_0_5k.S1_Conf_Int[3,2] ,R_0_6k.S1_Conf_Int[3,2] , R_0_7k.S1_Conf_Int[3,2] ,R_0_8k.S1_Conf_Int[3,2] ,R_0_9k.S1_Conf_Int[3,2] ,R_1_0k.S1_Conf_Int[3,2] ,R_1_2k.S1_Conf_Int[3,2] ,R_1_4k.S1_Conf_Int[3,2] ,R_1_6k.S1_Conf_Int[3,2] , R_1_8k.S1_Conf_Int[3,2] ,R_2_0k.S1_Conf_Int[3,2] ,R_2_3k.S1_Conf_Int[3,2] ,R_2_6k.S1_Conf_Int[3,2] ,R_2_9k.S1_Conf_Int[3,2] ,R_3_0k.S1_Conf_Int[3,2] ,R_3_5k.S1_Conf_Int[3,2] , R_4_0k.S1_Conf_Int[3,2] ,R_4_5k.S1_Conf_Int[3,2] ,R_5_0k.S1_Conf_Int[3,2] ,R_6_0k.S1_Conf_Int[3,2] ,R_7_0k.S1_Conf_Int[3,2] ,R_8_0k.S1_Conf_Int[3,2] ,R_9_0k.S1_Conf_Int[3,2] , R_10_0k.S1_Conf_Int[3,2],R_12_5k.S1_Conf_Int[3,2],R_15_0k.S1_Conf_Int[3,2],R_17_5k.S1_Conf_Int[3,2],R_20_0k.S1_Conf_Int[3,2],R_25_0k.S1_Conf_Int[3,2],R_30_0k.S1_Conf_Int[3,2], R_35_0k.S1_Conf_Int[3,2],R_40_0k.S1_Conf_Int[3,2],R_45_0k.S1_Conf_Int[3,2],  R_50_0k.S1_Conf_Int[3,2],  R_50_0k.S1_Conf_Int[3,2],  R_60_0k.S1_Conf_Int[3,2],  R_65_0k.S1_Conf_Int[3,2],  R_70_0k.S1_Conf_Int[3,2],  R_75_0k.S1_Conf_Int[3,2],  R_80_0k.S1_Conf_Int[3,2],  R_85_0k.S1_Conf_Int[3,2],  R_90_0k.S1_Conf_Int[3,2],  R_95_0k.S1_Conf_Int[3,2],  R_100_0k.S1_Conf_Int[3,2],  R_105_0k.S1_Conf_Int[3,2],  R_110_0k.S1_Conf_Int[3,2],  R_115_0k.S1_Conf_Int[3,2],  R_120_0k.S1_Conf_Int[3,2],  R_125_0k.S1_Conf_Int[3,2],  R_130_0k.S1_Conf_Int[3,2],  R_135_0k.S1_Conf_Int[3,2],  R_140_0k.S1_Conf_Int[3,2],  R_145_0k.S1_Conf_Int[3,2],  R_150_0k.S1_Conf_Int[3,2]]
        end
    
        # High and Low errors reg S1 #
        # Cardiac Output
        LowE_CO_R_S1 = CO_R_S1 .- (1.96 .*CO_R_S1_E)
        HighE_CO_R_S1 = CO_R_S1 .+ (1.96 .*CO_R_S1_E)
        # Max PLV
        LowE_PLV_R_S1 = PLV_R_S1 .- (1.96 .*PLV_R_S1_E)
        HighE_PLV_R_S1 = PLV_R_S1 .+ (1.96 .*PLV_R_S1_E)
        # Max PSV
        LowE_PSV_R_S1 = PSV_R_S1 .- (1.96 .*PSV_R_S1_E)
        HighE_PSV_R_S1 = PSV_R_S1 .+ (1.96 .*PSV_R_S1_E)
    end 
    #CO S1 UR
    band!(x[1:end], min.(LowE_CO_R_S1, HighE_CO_R_S1), max.(LowE_CO_R_S1, HighE_CO_R_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_R_S1, HighE_PLV_R_S1), max.(LowE_PLV_R_S1, HighE_PLV_R_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_R_S1, HighE_PSV_R_S1), max.(LowE_PSV_R_S1, HighE_PSV_R_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_S1, label = "PSV")
    hidexdecorations!(axd, grid = false)

    axe = Axis(ge[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,  xlabel = "Sample Size",  yticksize = 5)
    Label(ge[1, 1, Left()], L"P_{n}", valign = :center, font = :bold, padding = (0, 35, 0, 0))
    #Pn S1 reg data
    begin
        ## load Reg data for CO PSV PLV S1 ##
        begin
            CO_R_S1 = [R_0_1k.S1[10,11], R_0_2k.S1[10,11],R_0_3k.S1[10,11] ,R_0_4k.S1[10,11] ,R_0_5k.S1[10,11] ,R_0_6k.S1[10,11] ,  R_0_7k.S1[10,11] ,R_0_8k.S1[10,11] ,R_0_9k.S1[10,11] ,R_1_0k.S1[10,11] ,R_1_2k.S1[10,11] ,R_1_4k.S1[10,11] ,R_1_6k.S1[10,11] ,  R_1_8k.S1[10,11] ,R_2_0k.S1[10,11] ,R_2_3k.S1[10,11] ,R_2_6k.S1[10,11] ,R_2_9k.S1[10,11] ,R_3_0k.S1[10,11] ,R_3_5k.S1[10,11] ,  R_4_0k.S1[10,11] ,R_4_5k.S1[10,11] ,R_5_0k.S1[10,11] ,R_6_0k.S1[10,11] ,R_7_0k.S1[10,11] ,R_8_0k.S1[10,11] ,R_9_0k.S1[10,11] ,  R_10_0k.S1[10,11],R_12_5k.S1[10,11],R_15_0k.S1[10,11],R_17_5k.S1[10,11],R_20_0k.S1[10,11],R_25_0k.S1[10,11],R_30_0k.S1[10,11],  R_35_0k.S1[10,11],R_40_0k.S1[10,11],R_45_0k.S1[10,11],  R_50_0k.S1[10,11],  R_50_0k.S1[10,11],  R_60_0k.S1[10,11],  R_65_0k.S1[10,11],  R_70_0k.S1[10,11],  R_75_0k.S1[10,11],  R_80_0k.S1[10,11],  R_85_0k.S1[10,11],  R_90_0k.S1[10,11],  R_95_0k.S1[10,11],  R_100_0k.S1[10,11],  R_105_0k.S1[10,11],  R_110_0k.S1[10,11],  R_115_0k.S1[10,11],  R_120_0k.S1[10,11],  R_125_0k.S1[10,11],  R_130_0k.S1[10,11],  R_135_0k.S1[10,11],  R_140_0k.S1[10,11],  R_145_0k.S1[10,11],  R_150_0k.S1[10,11]]
        
            PLV_R_S1 = [R_0_1k.S1[1,11], R_0_2k.S1[1,11],R_0_3k.S1[1,11] ,R_0_4k.S1[1,11] ,R_0_5k.S1[1,11] ,R_0_6k.S1[1,11] , R_0_7k.S1[1,11] ,R_0_8k.S1[1,11] ,R_0_9k.S1[1,11] ,R_1_0k.S1[1,11] ,R_1_2k.S1[1,11] ,R_1_4k.S1[1,11] ,R_1_6k.S1[1,11] , R_1_8k.S1[1,11] ,R_2_0k.S1[1,11] ,R_2_3k.S1[1,11] ,R_2_6k.S1[1,11] ,R_2_9k.S1[1,11] ,R_3_0k.S1[1,11] ,R_3_5k.S1[1,11] , R_4_0k.S1[1,11] ,R_4_5k.S1[1,11] ,R_5_0k.S1[1,11] ,R_6_0k.S1[1,11] ,R_7_0k.S1[1,11] ,R_8_0k.S1[1,11] ,R_9_0k.S1[1,11] , R_10_0k.S1[1,11],R_12_5k.S1[1,11],R_15_0k.S1[1,11],R_17_5k.S1[1,11],R_20_0k.S1[1,11],R_25_0k.S1[1,11],R_30_0k.S1[1,11], R_35_0k.S1[1,11],R_40_0k.S1[1,11],R_45_0k.S1[1,11],  R_50_0k.S1[1,11],  R_50_0k.S1[1,11],  R_60_0k.S1[1,11],  R_65_0k.S1[1,11],  R_70_0k.S1[1,11],  R_75_0k.S1[1,11],  R_80_0k.S1[1,11],  R_85_0k.S1[1,11],  R_90_0k.S1[1,11],  R_95_0k.S1[1,11],  R_100_0k.S1[1,11],  R_105_0k.S1[1,11],  R_110_0k.S1[1,11],  R_115_0k.S1[1,11],  R_120_0k.S1[1,11],  R_125_0k.S1[1,11],  R_130_0k.S1[1,11],  R_135_0k.S1[1,11],  R_140_0k.S1[1,11],  R_145_0k.S1[1,11],  R_150_0k.S1[1,11]]
        
            PSV_R_S1 = [R_0_1k.S1[3,11], R_0_2k.S1[3,11],R_0_3k.S1[3,11] ,R_0_4k.S1[3,11] ,R_0_5k.S1[3,11] ,R_0_6k.S1[3,11] , R_0_7k.S1[3,11] ,R_0_8k.S1[3,11] ,R_0_9k.S1[3,11] ,R_1_0k.S1[3,11] ,R_1_2k.S1[3,11] ,R_1_4k.S1[3,11] ,R_1_6k.S1[3,11] , R_1_8k.S1[3,11] ,R_2_0k.S1[3,11] ,R_2_3k.S1[3,11] ,R_2_6k.S1[3,11] ,R_2_9k.S1[3,11] ,R_3_0k.S1[3,11] ,R_3_5k.S1[3,11] , R_4_0k.S1[3,11] ,R_4_5k.S1[3,11] ,R_5_0k.S1[3,11] ,R_6_0k.S1[3,11] ,R_7_0k.S1[3,11] ,R_8_0k.S1[3,11] ,R_9_0k.S1[3,11] , R_10_0k.S1[3,11],R_12_5k.S1[3,11],R_15_0k.S1[3,11],R_17_5k.S1[3,11],R_20_0k.S1[3,11],R_25_0k.S1[3,11],R_30_0k.S1[3,11], R_35_0k.S1[3,11],R_40_0k.S1[3,11],R_45_0k.S1[3,11],  R_50_0k.S1[3,11],  R_50_0k.S1[3,11],  R_60_0k.S1[3,11],  R_65_0k.S1[3,11],  R_70_0k.S1[3,11],  R_75_0k.S1[3,11],  R_80_0k.S1[3,11],  R_85_0k.S1[3,11],  R_90_0k.S1[3,11],  R_95_0k.S1[3,11],  R_100_0k.S1[3,11],  R_105_0k.S1[3,11],  R_110_0k.S1[3,11],  R_115_0k.S1[3,11],  R_120_0k.S1[3,11],  R_125_0k.S1[3,11],  R_130_0k.S1[3,11],  R_135_0k.S1[3,11],  R_140_0k.S1[3,11],  R_145_0k.S1[3,11],  R_150_0k.S1[3,11]]
        end
    
        ## R errors for CO PSV PLV S1 ##
        begin
            CO_R_S1_E = [R_0_1k.S1_Conf_Int[10,11], R_0_2k.S1_Conf_Int[10,11],R_0_3k.S1_Conf_Int[10,11] ,R_0_4k.S1_Conf_Int[10,11] ,R_0_5k.S1_Conf_Int[10,11] ,R_0_6k.S1_Conf_Int[10,11] ,  R_0_7k.S1_Conf_Int[10,11] ,R_0_8k.S1_Conf_Int[10,11] ,R_0_9k.S1_Conf_Int[10,11] ,R_1_0k.S1_Conf_Int[10,11] ,R_1_2k.S1_Conf_Int[10,11] ,R_1_4k.S1_Conf_Int[10,11] ,R_1_6k.S1_Conf_Int[10,11] ,  R_1_8k.S1_Conf_Int[10,11] ,R_2_0k.S1_Conf_Int[10,11] ,R_2_3k.S1_Conf_Int[10,11] ,R_2_6k.S1_Conf_Int[10,11] ,R_2_9k.S1_Conf_Int[10,11] ,R_3_0k.S1_Conf_Int[10,11] ,R_3_5k.S1_Conf_Int[10,11] ,  R_4_0k.S1_Conf_Int[10,11] ,R_4_5k.S1_Conf_Int[10,11] ,R_5_0k.S1_Conf_Int[10,11] ,R_6_0k.S1_Conf_Int[10,11] ,R_7_0k.S1_Conf_Int[10,11] ,R_8_0k.S1_Conf_Int[10,11] ,R_9_0k.S1_Conf_Int[10,11] ,  R_10_0k.S1_Conf_Int[10,11],R_12_5k.S1_Conf_Int[10,11],R_15_0k.S1_Conf_Int[10,11],R_17_5k.S1_Conf_Int[10,11],R_20_0k.S1_Conf_Int[10,11],R_25_0k.S1_Conf_Int[10,11],R_30_0k.S1_Conf_Int[10,11],  R_35_0k.S1_Conf_Int[10,11],R_40_0k.S1_Conf_Int[10,11],R_45_0k.S1_Conf_Int[10,11],  R_50_0k.S1_Conf_Int[10,11],  R_50_0k.S1_Conf_Int[10,11],  R_60_0k.S1_Conf_Int[10,11],  R_65_0k.S1_Conf_Int[10,11],  R_70_0k.S1_Conf_Int[10,11],  R_75_0k.S1_Conf_Int[10,11],  R_80_0k.S1_Conf_Int[10,11],  R_85_0k.S1_Conf_Int[10,11],  R_90_0k.S1_Conf_Int[10,11],  R_95_0k.S1_Conf_Int[10,11],  R_100_0k.S1_Conf_Int[10,11],  R_105_0k.S1_Conf_Int[10,11],  R_110_0k.S1_Conf_Int[10,11],  R_115_0k.S1_Conf_Int[10,11],  R_120_0k.S1_Conf_Int[10,11],  R_125_0k.S1_Conf_Int[10,11],  R_130_0k.S1_Conf_Int[10,11],  R_135_0k.S1_Conf_Int[10,11],  R_140_0k.S1_Conf_Int[10,11],  R_145_0k.S1_Conf_Int[10,11],  R_150_0k.S1_Conf_Int[10,11]]
        
            PLV_R_S1_E = [R_0_1k.S1_Conf_Int[1,11], R_0_2k.S1_Conf_Int[1,11],R_0_3k.S1_Conf_Int[1,11] ,R_0_4k.S1_Conf_Int[1,11] ,R_0_5k.S1_Conf_Int[1,11] ,R_0_6k.S1_Conf_Int[1,11] , R_0_7k.S1_Conf_Int[1,11] ,R_0_8k.S1_Conf_Int[1,11] ,R_0_9k.S1_Conf_Int[1,11] ,R_1_0k.S1_Conf_Int[1,11] ,R_1_2k.S1_Conf_Int[1,11] ,R_1_4k.S1_Conf_Int[1,11] ,R_1_6k.S1_Conf_Int[1,11] , R_1_8k.S1_Conf_Int[1,11] ,R_2_0k.S1_Conf_Int[1,11] ,R_2_3k.S1_Conf_Int[1,11] ,R_2_6k.S1_Conf_Int[1,11] ,R_2_9k.S1_Conf_Int[1,11] ,R_3_0k.S1_Conf_Int[1,11] ,R_3_5k.S1_Conf_Int[1,11] , R_4_0k.S1_Conf_Int[1,11] ,R_4_5k.S1_Conf_Int[1,11] ,R_5_0k.S1_Conf_Int[1,11] ,R_6_0k.S1_Conf_Int[1,11] ,R_7_0k.S1_Conf_Int[1,11] ,R_8_0k.S1_Conf_Int[1,11] ,R_9_0k.S1_Conf_Int[1,11] , R_10_0k.S1_Conf_Int[1,11],R_12_5k.S1_Conf_Int[1,11],R_15_0k.S1_Conf_Int[1,11],R_17_5k.S1_Conf_Int[1,11],R_20_0k.S1_Conf_Int[1,11],R_25_0k.S1_Conf_Int[1,11],R_30_0k.S1_Conf_Int[1,11], R_35_0k.S1_Conf_Int[1,11],R_40_0k.S1_Conf_Int[1,11],R_45_0k.S1_Conf_Int[1,11],  R_50_0k.S1_Conf_Int[1,11],  R_50_0k.S1_Conf_Int[1,11],  R_60_0k.S1_Conf_Int[1,11],  R_65_0k.S1_Conf_Int[1,11],  R_70_0k.S1_Conf_Int[1,11],  R_75_0k.S1_Conf_Int[1,11],  R_80_0k.S1_Conf_Int[1,11],  R_85_0k.S1_Conf_Int[1,11],  R_90_0k.S1_Conf_Int[1,11],  R_95_0k.S1_Conf_Int[1,11],  R_100_0k.S1_Conf_Int[1,11],  R_105_0k.S1_Conf_Int[1,11],  R_110_0k.S1_Conf_Int[1,11],  R_115_0k.S1_Conf_Int[1,11],  R_120_0k.S1_Conf_Int[1,11],  R_125_0k.S1_Conf_Int[1,11],  R_130_0k.S1_Conf_Int[1,11],  R_135_0k.S1_Conf_Int[1,11],  R_140_0k.S1_Conf_Int[1,11],  R_145_0k.S1_Conf_Int[1,11],  R_150_0k.S1_Conf_Int[1,11]]
        
            PSV_R_S1_E = [R_0_1k.S1_Conf_Int[3,11], R_0_2k.S1_Conf_Int[3,11],R_0_3k.S1_Conf_Int[3,11] ,R_0_4k.S1_Conf_Int[3,11] ,R_0_5k.S1_Conf_Int[3,11] ,R_0_6k.S1_Conf_Int[3,11] , R_0_7k.S1_Conf_Int[3,11] ,R_0_8k.S1_Conf_Int[3,11] ,R_0_9k.S1_Conf_Int[3,11] ,R_1_0k.S1_Conf_Int[3,11] ,R_1_2k.S1_Conf_Int[3,11] ,R_1_4k.S1_Conf_Int[3,11] ,R_1_6k.S1_Conf_Int[3,11] , R_1_8k.S1_Conf_Int[3,11] ,R_2_0k.S1_Conf_Int[3,11] ,R_2_3k.S1_Conf_Int[3,11] ,R_2_6k.S1_Conf_Int[3,11] ,R_2_9k.S1_Conf_Int[3,11] ,R_3_0k.S1_Conf_Int[3,11] ,R_3_5k.S1_Conf_Int[3,11] , R_4_0k.S1_Conf_Int[3,11] ,R_4_5k.S1_Conf_Int[3,11] ,R_5_0k.S1_Conf_Int[3,11] ,R_6_0k.S1_Conf_Int[3,11] ,R_7_0k.S1_Conf_Int[3,11] ,R_8_0k.S1_Conf_Int[3,11] ,R_9_0k.S1_Conf_Int[3,11] , R_10_0k.S1_Conf_Int[3,11],R_12_5k.S1_Conf_Int[3,11],R_15_0k.S1_Conf_Int[3,11],R_17_5k.S1_Conf_Int[3,11],R_20_0k.S1_Conf_Int[3,11],R_25_0k.S1_Conf_Int[3,11],R_30_0k.S1_Conf_Int[3,11], R_35_0k.S1_Conf_Int[3,11],R_40_0k.S1_Conf_Int[3,11],R_45_0k.S1_Conf_Int[3,11],  R_50_0k.S1_Conf_Int[3,11],  R_50_0k.S1_Conf_Int[3,11],  R_60_0k.S1_Conf_Int[3,11],  R_65_0k.S1_Conf_Int[3,11],  R_70_0k.S1_Conf_Int[3,11],  R_75_0k.S1_Conf_Int[3,11],  R_80_0k.S1_Conf_Int[3,11],  R_85_0k.S1_Conf_Int[3,11],  R_90_0k.S1_Conf_Int[3,11],  R_95_0k.S1_Conf_Int[3,11],  R_100_0k.S1_Conf_Int[3,11],  R_105_0k.S1_Conf_Int[3,11],  R_110_0k.S1_Conf_Int[3,11],  R_115_0k.S1_Conf_Int[3,11],  R_120_0k.S1_Conf_Int[3,11],  R_125_0k.S1_Conf_Int[3,11],  R_130_0k.S1_Conf_Int[3,11],  R_135_0k.S1_Conf_Int[3,11],  R_140_0k.S1_Conf_Int[3,11],  R_145_0k.S1_Conf_Int[3,11],  R_150_0k.S1_Conf_Int[3,11]]
        end
    
        # High and Low errors reg S1 #
        # Cardiac Output
        LowE_CO_R_S1 = CO_R_S1 .- (1.96 .*CO_R_S1_E)
        HighE_CO_R_S1 = CO_R_S1 .+ (1.96 .*CO_R_S1_E)
        # Max PLV
        LowE_PLV_R_S1 = PLV_R_S1 .- (1.96 .*PLV_R_S1_E)
        HighE_PLV_R_S1 = PLV_R_S1 .+ (1.96 .*PLV_R_S1_E)
        # Max PSV
        LowE_PSV_R_S1 = PSV_R_S1 .- (1.96 .*PSV_R_S1_E)
        HighE_PSV_R_S1 = PSV_R_S1 .+ (1.96 .*PSV_R_S1_E)
    end 
    #CO S1 UR
    band!(x[1:end], min.(LowE_CO_R_S1, HighE_CO_R_S1), max.(LowE_CO_R_S1, HighE_CO_R_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_R_S1, HighE_PLV_R_S1), max.(LowE_PLV_R_S1, HighE_PLV_R_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_R_S1, HighE_PSV_R_S1), max.(LowE_PSV_R_S1, HighE_PSV_R_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_S1, label = "PSV")
    hidexdecorations!(axe, grid = false)

    axf = Axis(gf[1,1], xlabel = L"\text{Sample~Size}", xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    Label(gf[1, 1, Left()], L"\tau", valign = :center, font = :bold, padding = (0, 35, 0, 0))
    #tau S1 reg data
    begin
        ## load Reg data for CO PSV PLV S1 ##
        begin
            CO_R_S1 = [R_0_1k.S1[10,6], R_0_2k.S1[10,6],R_0_3k.S1[10,6] ,R_0_4k.S1[10,6] ,R_0_5k.S1[10,6] ,R_0_6k.S1[10,6] ,  R_0_7k.S1[10,6] ,R_0_8k.S1[10,6] ,R_0_9k.S1[10,6] ,R_1_0k.S1[10,6] ,R_1_2k.S1[10,6] ,R_1_4k.S1[10,6] ,R_1_6k.S1[10,6] ,  R_1_8k.S1[10,6] ,R_2_0k.S1[10,6] ,R_2_3k.S1[10,6] ,R_2_6k.S1[10,6] ,R_2_9k.S1[10,6] ,R_3_0k.S1[10,6] ,R_3_5k.S1[10,6] ,  R_4_0k.S1[10,6] ,R_4_5k.S1[10,6] ,R_5_0k.S1[10,6] ,R_6_0k.S1[10,6] ,R_7_0k.S1[10,6] ,R_8_0k.S1[10,6] ,R_9_0k.S1[10,6] ,  R_10_0k.S1[10,6],R_12_5k.S1[10,6],R_15_0k.S1[10,6],R_17_5k.S1[10,6],R_20_0k.S1[10,6],R_25_0k.S1[10,6],R_30_0k.S1[10,6],  R_35_0k.S1[10,6],R_40_0k.S1[10,6],R_45_0k.S1[10,6],  R_50_0k.S1[10,6],  R_50_0k.S1[10,6],  R_60_0k.S1[10,6],  R_65_0k.S1[10,6],  R_70_0k.S1[10,6],  R_75_0k.S1[10,6],  R_80_0k.S1[10,6],  R_85_0k.S1[10,6],  R_90_0k.S1[10,6],  R_95_0k.S1[10,6],  R_100_0k.S1[10,6],  R_105_0k.S1[10,6],  R_110_0k.S1[10,6],  R_115_0k.S1[10,6],  R_120_0k.S1[10,6],  R_125_0k.S1[10,6],  R_130_0k.S1[10,6],  R_135_0k.S1[10,6],  R_140_0k.S1[10,6],  R_145_0k.S1[10,6],  R_150_0k.S1[10,6]]
        
            PLV_R_S1 = [R_0_1k.S1[1,6], R_0_2k.S1[1,6],R_0_3k.S1[1,6] ,R_0_4k.S1[1,6] ,R_0_5k.S1[1,6] ,R_0_6k.S1[1,6] , R_0_7k.S1[1,6] ,R_0_8k.S1[1,6] ,R_0_9k.S1[1,6] ,R_1_0k.S1[1,6] ,R_1_2k.S1[1,6] ,R_1_4k.S1[1,6] ,R_1_6k.S1[1,6] , R_1_8k.S1[1,6] ,R_2_0k.S1[1,6] ,R_2_3k.S1[1,6] ,R_2_6k.S1[1,6] ,R_2_9k.S1[1,6] ,R_3_0k.S1[1,6] ,R_3_5k.S1[1,6] , R_4_0k.S1[1,6] ,R_4_5k.S1[1,6] ,R_5_0k.S1[1,6] ,R_6_0k.S1[1,6] ,R_7_0k.S1[1,6] ,R_8_0k.S1[1,6] ,R_9_0k.S1[1,6] , R_10_0k.S1[1,6],R_12_5k.S1[1,6],R_15_0k.S1[1,6],R_17_5k.S1[1,6],R_20_0k.S1[1,6],R_25_0k.S1[1,6],R_30_0k.S1[1,6], R_35_0k.S1[1,6],R_40_0k.S1[1,6],R_45_0k.S1[1,6],  R_50_0k.S1[1,6],  R_50_0k.S1[1,6],  R_60_0k.S1[1,6],  R_65_0k.S1[1,6],  R_70_0k.S1[1,6],  R_75_0k.S1[1,6],  R_80_0k.S1[1,6],  R_85_0k.S1[1,6],  R_90_0k.S1[1,6],  R_95_0k.S1[1,6],  R_100_0k.S1[1,6],  R_105_0k.S1[1,6],  R_110_0k.S1[1,6],  R_115_0k.S1[1,6],  R_120_0k.S1[1,6],  R_125_0k.S1[1,6],  R_130_0k.S1[1,6],  R_135_0k.S1[1,6],  R_140_0k.S1[1,6],  R_145_0k.S1[1,6],  R_150_0k.S1[1,6]]
        
            PSV_R_S1 = [R_0_1k.S1[3,6], R_0_2k.S1[3,6],R_0_3k.S1[3,6] ,R_0_4k.S1[3,6] ,R_0_5k.S1[3,6] ,R_0_6k.S1[3,6] , R_0_7k.S1[3,6] ,R_0_8k.S1[3,6] ,R_0_9k.S1[3,6] ,R_1_0k.S1[3,6] ,R_1_2k.S1[3,6] ,R_1_4k.S1[3,6] ,R_1_6k.S1[3,6] , R_1_8k.S1[3,6] ,R_2_0k.S1[3,6] ,R_2_3k.S1[3,6] ,R_2_6k.S1[3,6] ,R_2_9k.S1[3,6] ,R_3_0k.S1[3,6] ,R_3_5k.S1[3,6] , R_4_0k.S1[3,6] ,R_4_5k.S1[3,6] ,R_5_0k.S1[3,6] ,R_6_0k.S1[3,6] ,R_7_0k.S1[3,6] ,R_8_0k.S1[3,6] ,R_9_0k.S1[3,6] , R_10_0k.S1[3,6],R_12_5k.S1[3,6],R_15_0k.S1[3,6],R_17_5k.S1[3,6],R_20_0k.S1[3,6],R_25_0k.S1[3,6],R_30_0k.S1[3,6], R_35_0k.S1[3,6],R_40_0k.S1[3,6],R_45_0k.S1[3,6],  R_50_0k.S1[3,6],  R_50_0k.S1[3,6],  R_60_0k.S1[3,6],  R_65_0k.S1[3,6],  R_70_0k.S1[3,6],  R_75_0k.S1[3,6],  R_80_0k.S1[3,6],  R_85_0k.S1[3,6],  R_90_0k.S1[3,6],  R_95_0k.S1[3,6],  R_100_0k.S1[3,6],  R_105_0k.S1[3,6],  R_110_0k.S1[3,6],  R_115_0k.S1[3,6],  R_120_0k.S1[3,6],  R_125_0k.S1[3,6],  R_130_0k.S1[3,6],  R_135_0k.S1[3,6],  R_140_0k.S1[3,6],  R_145_0k.S1[3,6],  R_150_0k.S1[3,6]]
        end
    
        ## R errors for CO PSV PLV S1 ##
        begin
            CO_R_S1_E = [R_0_1k.S1_Conf_Int[10,6], R_0_2k.S1_Conf_Int[10,6],R_0_3k.S1_Conf_Int[10,6] ,R_0_4k.S1_Conf_Int[10,6] ,R_0_5k.S1_Conf_Int[10,6] ,R_0_6k.S1_Conf_Int[10,6] ,  R_0_7k.S1_Conf_Int[10,6] ,R_0_8k.S1_Conf_Int[10,6] ,R_0_9k.S1_Conf_Int[10,6] ,R_1_0k.S1_Conf_Int[10,6] ,R_1_2k.S1_Conf_Int[10,6] ,R_1_4k.S1_Conf_Int[10,6] ,R_1_6k.S1_Conf_Int[10,6] ,  R_1_8k.S1_Conf_Int[10,6] ,R_2_0k.S1_Conf_Int[10,6] ,R_2_3k.S1_Conf_Int[10,6] ,R_2_6k.S1_Conf_Int[10,6] ,R_2_9k.S1_Conf_Int[10,6] ,R_3_0k.S1_Conf_Int[10,6] ,R_3_5k.S1_Conf_Int[10,6] ,  R_4_0k.S1_Conf_Int[10,6] ,R_4_5k.S1_Conf_Int[10,6] ,R_5_0k.S1_Conf_Int[10,6] ,R_6_0k.S1_Conf_Int[10,6] ,R_7_0k.S1_Conf_Int[10,6] ,R_8_0k.S1_Conf_Int[10,6] ,R_9_0k.S1_Conf_Int[10,6] ,  R_10_0k.S1_Conf_Int[10,6],R_12_5k.S1_Conf_Int[10,6],R_15_0k.S1_Conf_Int[10,6],R_17_5k.S1_Conf_Int[10,6],R_20_0k.S1_Conf_Int[10,6],R_25_0k.S1_Conf_Int[10,6],R_30_0k.S1_Conf_Int[10,6],  R_35_0k.S1_Conf_Int[10,6],R_40_0k.S1_Conf_Int[10,6],R_45_0k.S1_Conf_Int[10,6],  R_50_0k.S1_Conf_Int[10,6],  R_50_0k.S1_Conf_Int[10,6],  R_60_0k.S1_Conf_Int[10,6],  R_65_0k.S1_Conf_Int[10,6],  R_70_0k.S1_Conf_Int[10,6],  R_75_0k.S1_Conf_Int[10,6],  R_80_0k.S1_Conf_Int[10,6],  R_85_0k.S1_Conf_Int[10,6],  R_90_0k.S1_Conf_Int[10,6],  R_95_0k.S1_Conf_Int[10,6],  R_100_0k.S1_Conf_Int[10,6],  R_105_0k.S1_Conf_Int[10,6],  R_110_0k.S1_Conf_Int[10,6],  R_115_0k.S1_Conf_Int[10,6],  R_120_0k.S1_Conf_Int[10,6],  R_125_0k.S1_Conf_Int[10,6],  R_130_0k.S1_Conf_Int[10,6],  R_135_0k.S1_Conf_Int[10,6],  R_140_0k.S1_Conf_Int[10,6],  R_145_0k.S1_Conf_Int[10,6],  R_150_0k.S1_Conf_Int[10,6]]
        
            PLV_R_S1_E = [R_0_1k.S1_Conf_Int[1,6], R_0_2k.S1_Conf_Int[1,6],R_0_3k.S1_Conf_Int[1,6] ,R_0_4k.S1_Conf_Int[1,6] ,R_0_5k.S1_Conf_Int[1,6] ,R_0_6k.S1_Conf_Int[1,6] , R_0_7k.S1_Conf_Int[1,6] ,R_0_8k.S1_Conf_Int[1,6] ,R_0_9k.S1_Conf_Int[1,6] ,R_1_0k.S1_Conf_Int[1,6] ,R_1_2k.S1_Conf_Int[1,6] ,R_1_4k.S1_Conf_Int[1,6] ,R_1_6k.S1_Conf_Int[1,6] , R_1_8k.S1_Conf_Int[1,6] ,R_2_0k.S1_Conf_Int[1,6] ,R_2_3k.S1_Conf_Int[1,6] ,R_2_6k.S1_Conf_Int[1,6] ,R_2_9k.S1_Conf_Int[1,6] ,R_3_0k.S1_Conf_Int[1,6] ,R_3_5k.S1_Conf_Int[1,6] , R_4_0k.S1_Conf_Int[1,6] ,R_4_5k.S1_Conf_Int[1,6] ,R_5_0k.S1_Conf_Int[1,6] ,R_6_0k.S1_Conf_Int[1,6] ,R_7_0k.S1_Conf_Int[1,6] ,R_8_0k.S1_Conf_Int[1,6] ,R_9_0k.S1_Conf_Int[1,6] , R_10_0k.S1_Conf_Int[1,6],R_12_5k.S1_Conf_Int[1,6],R_15_0k.S1_Conf_Int[1,6],R_17_5k.S1_Conf_Int[1,6],R_20_0k.S1_Conf_Int[1,6],R_25_0k.S1_Conf_Int[1,6],R_30_0k.S1_Conf_Int[1,6], R_35_0k.S1_Conf_Int[1,6],R_40_0k.S1_Conf_Int[1,6],R_45_0k.S1_Conf_Int[1,6],  R_50_0k.S1_Conf_Int[1,6],  R_50_0k.S1_Conf_Int[1,6],  R_60_0k.S1_Conf_Int[1,6],  R_65_0k.S1_Conf_Int[1,6],  R_70_0k.S1_Conf_Int[1,6],  R_75_0k.S1_Conf_Int[1,6],  R_80_0k.S1_Conf_Int[1,6],  R_85_0k.S1_Conf_Int[1,6],  R_90_0k.S1_Conf_Int[1,6],  R_95_0k.S1_Conf_Int[1,6],  R_100_0k.S1_Conf_Int[1,6],  R_105_0k.S1_Conf_Int[1,6],  R_110_0k.S1_Conf_Int[1,6],  R_115_0k.S1_Conf_Int[1,6],  R_120_0k.S1_Conf_Int[1,6],  R_125_0k.S1_Conf_Int[1,6],  R_130_0k.S1_Conf_Int[1,6],  R_135_0k.S1_Conf_Int[1,6],  R_140_0k.S1_Conf_Int[1,6],  R_145_0k.S1_Conf_Int[1,6],  R_150_0k.S1_Conf_Int[1,6]]
        
            PSV_R_S1_E = [R_0_1k.S1_Conf_Int[3,6], R_0_2k.S1_Conf_Int[3,6],R_0_3k.S1_Conf_Int[3,6] ,R_0_4k.S1_Conf_Int[3,6] ,R_0_5k.S1_Conf_Int[3,6] ,R_0_6k.S1_Conf_Int[3,6] , R_0_7k.S1_Conf_Int[3,6] ,R_0_8k.S1_Conf_Int[3,6] ,R_0_9k.S1_Conf_Int[3,6] ,R_1_0k.S1_Conf_Int[3,6] ,R_1_2k.S1_Conf_Int[3,6] ,R_1_4k.S1_Conf_Int[3,6] ,R_1_6k.S1_Conf_Int[3,6] , R_1_8k.S1_Conf_Int[3,6] ,R_2_0k.S1_Conf_Int[3,6] ,R_2_3k.S1_Conf_Int[3,6] ,R_2_6k.S1_Conf_Int[3,6] ,R_2_9k.S1_Conf_Int[3,6] ,R_3_0k.S1_Conf_Int[3,6] ,R_3_5k.S1_Conf_Int[3,6] , R_4_0k.S1_Conf_Int[3,6] ,R_4_5k.S1_Conf_Int[3,6] ,R_5_0k.S1_Conf_Int[3,6] ,R_6_0k.S1_Conf_Int[3,6] ,R_7_0k.S1_Conf_Int[3,6] ,R_8_0k.S1_Conf_Int[3,6] ,R_9_0k.S1_Conf_Int[3,6] , R_10_0k.S1_Conf_Int[3,6],R_12_5k.S1_Conf_Int[3,6],R_15_0k.S1_Conf_Int[3,6],R_17_5k.S1_Conf_Int[3,6],R_20_0k.S1_Conf_Int[3,6],R_25_0k.S1_Conf_Int[3,6],R_30_0k.S1_Conf_Int[3,6], R_35_0k.S1_Conf_Int[3,6],R_40_0k.S1_Conf_Int[3,6],R_45_0k.S1_Conf_Int[3,6],  R_50_0k.S1_Conf_Int[3,6],  R_50_0k.S1_Conf_Int[3,6],  R_60_0k.S1_Conf_Int[3,6],  R_65_0k.S1_Conf_Int[3,6],  R_70_0k.S1_Conf_Int[3,6],  R_75_0k.S1_Conf_Int[3,6],  R_80_0k.S1_Conf_Int[3,6],  R_85_0k.S1_Conf_Int[3,6],  R_90_0k.S1_Conf_Int[3,6],  R_95_0k.S1_Conf_Int[3,6],  R_100_0k.S1_Conf_Int[3,6],  R_105_0k.S1_Conf_Int[3,6],  R_110_0k.S1_Conf_Int[3,6],  R_115_0k.S1_Conf_Int[3,6],  R_120_0k.S1_Conf_Int[3,6],  R_125_0k.S1_Conf_Int[3,6],  R_130_0k.S1_Conf_Int[3,6],  R_135_0k.S1_Conf_Int[3,6],  R_140_0k.S1_Conf_Int[3,6],  R_145_0k.S1_Conf_Int[3,6],  R_150_0k.S1_Conf_Int[3,6]]
        end
    
        # High and Low errors reg S1 #
        # Cardiac Output
        LowE_CO_R_S1 = CO_R_S1 .- (1.96 .*CO_R_S1_E)
        HighE_CO_R_S1 = CO_R_S1 .+ (1.96 .*CO_R_S1_E)
        # Max PLV
        LowE_PLV_R_S1 = PLV_R_S1 .- (1.96 .*PLV_R_S1_E)
        HighE_PLV_R_S1 = PLV_R_S1 .+ (1.96 .*PLV_R_S1_E)
        # Max PSV
        LowE_PSV_R_S1 = PSV_R_S1 .- (1.96 .*PSV_R_S1_E)
        HighE_PSV_R_S1 = PSV_R_S1 .+ (1.96 .*PSV_R_S1_E)
    end 
    #CO S1 UR
    band!(x[1:end], min.(LowE_CO_R_S1, HighE_CO_R_S1), max.(LowE_CO_R_S1, HighE_CO_R_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_R_S1, HighE_PLV_R_S1), max.(LowE_PLV_R_S1, HighE_PLV_R_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_R_S1, HighE_PSV_R_S1), max.(LowE_PSV_R_S1, HighE_PSV_R_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_S1, label = "PSV")

    axg = Axis(gg[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    Label(gg[1, 1, Top()], L"S_{T}~\text{Regulated}~\text{Model}", valign = :center, font = :bold, padding = (0, 0, 0, 0))
    #Rs ST reg data
    begin
        ## load Reg data for CO PSV PLV ST ##
        begin
            CO_R_ST = [R_0_1k.ST[10,1], R_0_2k.ST[10,1],R_0_3k.ST[10,1] ,R_0_4k.ST[10,1] ,R_0_5k.ST[10,1] ,R_0_6k.ST[10,1] ,  R_0_7k.ST[10,1] ,R_0_8k.ST[10,1] ,R_0_9k.ST[10,1] ,R_1_0k.ST[10,1] ,R_1_2k.ST[10,1] ,R_1_4k.ST[10,1] ,R_1_6k.ST[10,1] ,  R_1_8k.ST[10,1] ,R_2_0k.ST[10,1] ,R_2_3k.ST[10,1] ,R_2_6k.ST[10,1] ,R_2_9k.ST[10,1] ,R_3_0k.ST[10,1] ,R_3_5k.ST[10,1] ,  R_4_0k.ST[10,1] ,R_4_5k.ST[10,1] ,R_5_0k.ST[10,1] ,R_6_0k.ST[10,1] ,R_7_0k.ST[10,1] ,R_8_0k.ST[10,1] ,R_9_0k.ST[10,1] ,  R_10_0k.ST[10,1],R_12_5k.ST[10,1],R_15_0k.ST[10,1],R_17_5k.ST[10,1],R_20_0k.ST[10,1],R_25_0k.ST[10,1],R_30_0k.ST[10,1],  R_35_0k.ST[10,1],R_40_0k.ST[10,1],R_45_0k.ST[10,1],  R_50_0k.ST[10,1],  R_50_0k.ST[10,1],  R_60_0k.ST[10,1],  R_65_0k.ST[10,1],  R_70_0k.ST[10,1],  R_75_0k.ST[10,1],  R_80_0k.ST[10,1],  R_85_0k.ST[10,1],  R_90_0k.ST[10,1],  R_95_0k.ST[10,1],  R_100_0k.ST[10,1],  R_105_0k.ST[10,1],  R_110_0k.ST[10,1],  R_115_0k.ST[10,1],  R_120_0k.ST[10,1],  R_125_0k.ST[10,1],  R_130_0k.ST[10,1],  R_135_0k.ST[10,1],  R_140_0k.ST[10,1],  R_145_0k.ST[10,1],  R_150_0k.ST[10,1]]
        
            PLV_R_ST = [R_0_1k.ST[1,1], R_0_2k.ST[1,1],R_0_3k.ST[1,1] ,R_0_4k.ST[1,1] ,R_0_5k.ST[1,1] ,R_0_6k.ST[1,1] , R_0_7k.ST[1,1] ,R_0_8k.ST[1,1] ,R_0_9k.ST[1,1] ,R_1_0k.ST[1,1] ,R_1_2k.ST[1,1] ,R_1_4k.ST[1,1] ,R_1_6k.ST[1,1] , R_1_8k.ST[1,1] ,R_2_0k.ST[1,1] ,R_2_3k.ST[1,1] ,R_2_6k.ST[1,1] ,R_2_9k.ST[1,1] ,R_3_0k.ST[1,1] ,R_3_5k.ST[1,1] , R_4_0k.ST[1,1] ,R_4_5k.ST[1,1] ,R_5_0k.ST[1,1] ,R_6_0k.ST[1,1] ,R_7_0k.ST[1,1] ,R_8_0k.ST[1,1] ,R_9_0k.ST[1,1] , R_10_0k.ST[1,1],R_12_5k.ST[1,1],R_15_0k.ST[1,1],R_17_5k.ST[1,1],R_20_0k.ST[1,1],R_25_0k.ST[1,1],R_30_0k.ST[1,1], R_35_0k.ST[1,1],R_40_0k.ST[1,1],R_45_0k.ST[1,1],  R_50_0k.ST[1,1],  R_50_0k.ST[1,1],  R_60_0k.ST[1,1],  R_65_0k.ST[1,1],  R_70_0k.ST[1,1],  R_75_0k.ST[1,1],  R_80_0k.ST[1,1],  R_85_0k.ST[1,1],  R_90_0k.ST[1,1],  R_95_0k.ST[1,1],  R_100_0k.ST[1,1],  R_105_0k.ST[1,1],  R_110_0k.ST[1,1],  R_115_0k.ST[1,1],  R_120_0k.ST[1,1],  R_125_0k.ST[1,1],  R_130_0k.ST[1,1],  R_135_0k.ST[1,1],  R_140_0k.ST[1,1],  R_145_0k.ST[1,1],  R_150_0k.ST[1,1]]
        
            PSV_R_ST = [R_0_1k.ST[3,1], R_0_2k.ST[3,1],R_0_3k.ST[3,1] ,R_0_4k.ST[3,1] ,R_0_5k.ST[3,1] ,R_0_6k.ST[3,1] , R_0_7k.ST[3,1] ,R_0_8k.ST[3,1] ,R_0_9k.ST[3,1] ,R_1_0k.ST[3,1] ,R_1_2k.ST[3,1] ,R_1_4k.ST[3,1] ,R_1_6k.ST[3,1] , R_1_8k.ST[3,1] ,R_2_0k.ST[3,1] ,R_2_3k.ST[3,1] ,R_2_6k.ST[3,1] ,R_2_9k.ST[3,1] ,R_3_0k.ST[3,1] ,R_3_5k.ST[3,1] , R_4_0k.ST[3,1] ,R_4_5k.ST[3,1] ,R_5_0k.ST[3,1] ,R_6_0k.ST[3,1] ,R_7_0k.ST[3,1] ,R_8_0k.ST[3,1] ,R_9_0k.ST[3,1] , R_10_0k.ST[3,1],R_12_5k.ST[3,1],R_15_0k.ST[3,1],R_17_5k.ST[3,1],R_20_0k.ST[3,1],R_25_0k.ST[3,1],R_30_0k.ST[3,1], R_35_0k.ST[3,1],R_40_0k.ST[3,1],R_45_0k.ST[3,1],  R_50_0k.ST[3,1],  R_50_0k.ST[3,1],  R_60_0k.ST[3,1],  R_65_0k.ST[3,1],  R_70_0k.ST[3,1],  R_75_0k.ST[3,1],  R_80_0k.ST[3,1],  R_85_0k.ST[3,1],  R_90_0k.ST[3,1],  R_95_0k.ST[3,1],  R_100_0k.ST[3,1],  R_105_0k.ST[3,1],  R_110_0k.ST[3,1],  R_115_0k.ST[3,1],  R_120_0k.ST[3,1],  R_125_0k.ST[3,1],  R_130_0k.ST[3,1],  R_135_0k.ST[3,1],  R_140_0k.ST[3,1],  R_145_0k.ST[3,1],  R_150_0k.ST[3,1]]
        end

        ## R errors for CO PSV PLV ST ##
        begin
            CO_R_ST_E = [R_0_1k.ST_Conf_Int[10,1], R_0_2k.ST_Conf_Int[10,1],R_0_3k.ST_Conf_Int[10,1] ,R_0_4k.ST_Conf_Int[10,1] ,R_0_5k.ST_Conf_Int[10,1] ,R_0_6k.ST_Conf_Int[10,1] ,  R_0_7k.ST_Conf_Int[10,1] ,R_0_8k.ST_Conf_Int[10,1] ,R_0_9k.ST_Conf_Int[10,1] ,R_1_0k.ST_Conf_Int[10,1] ,R_1_2k.ST_Conf_Int[10,1] ,R_1_4k.ST_Conf_Int[10,1] ,R_1_6k.ST_Conf_Int[10,1] ,  R_1_8k.ST_Conf_Int[10,1] ,R_2_0k.ST_Conf_Int[10,1] ,R_2_3k.ST_Conf_Int[10,1] ,R_2_6k.ST_Conf_Int[10,1] ,R_2_9k.ST_Conf_Int[10,1] ,R_3_0k.ST_Conf_Int[10,1] ,R_3_5k.ST_Conf_Int[10,1] ,  R_4_0k.ST_Conf_Int[10,1] ,R_4_5k.ST_Conf_Int[10,1] ,R_5_0k.ST_Conf_Int[10,1] ,R_6_0k.ST_Conf_Int[10,1] ,R_7_0k.ST_Conf_Int[10,1] ,R_8_0k.ST_Conf_Int[10,1] ,R_9_0k.ST_Conf_Int[10,1] ,  R_10_0k.ST_Conf_Int[10,1],R_12_5k.ST_Conf_Int[10,1],R_15_0k.ST_Conf_Int[10,1],R_17_5k.ST_Conf_Int[10,1],R_20_0k.ST_Conf_Int[10,1],R_25_0k.ST_Conf_Int[10,1],R_30_0k.ST_Conf_Int[10,1],  R_35_0k.ST_Conf_Int[10,1],R_40_0k.ST_Conf_Int[10,1],R_45_0k.ST_Conf_Int[10,1],  R_50_0k.ST_Conf_Int[10,1],  R_50_0k.ST_Conf_Int[10,1],  R_60_0k.ST_Conf_Int[10,1],  R_65_0k.ST_Conf_Int[10,1],  R_70_0k.ST_Conf_Int[10,1],  R_75_0k.ST_Conf_Int[10,1],  R_80_0k.ST_Conf_Int[10,1],  R_85_0k.ST_Conf_Int[10,1],  R_90_0k.ST_Conf_Int[10,1],  R_95_0k.ST_Conf_Int[10,1],  R_100_0k.ST_Conf_Int[10,1],  R_105_0k.ST_Conf_Int[10,1],  R_110_0k.ST_Conf_Int[10,1],  R_115_0k.ST_Conf_Int[10,1],  R_120_0k.ST_Conf_Int[10,1],  R_125_0k.ST_Conf_Int[10,1],  R_130_0k.ST_Conf_Int[10,1],  R_135_0k.ST_Conf_Int[10,1],  R_140_0k.ST_Conf_Int[10,1],  R_145_0k.ST_Conf_Int[10,1],  R_150_0k.ST_Conf_Int[10,1]]
        
            PLV_R_ST_E = [R_0_1k.ST_Conf_Int[1,1], R_0_2k.ST_Conf_Int[1,1],R_0_3k.ST_Conf_Int[1,1] ,R_0_4k.ST_Conf_Int[1,1] ,R_0_5k.ST_Conf_Int[1,1] ,R_0_6k.ST_Conf_Int[1,1] , R_0_7k.ST_Conf_Int[1,1] ,R_0_8k.ST_Conf_Int[1,1] ,R_0_9k.ST_Conf_Int[1,1] ,R_1_0k.ST_Conf_Int[1,1] ,R_1_2k.ST_Conf_Int[1,1] ,R_1_4k.ST_Conf_Int[1,1] ,R_1_6k.ST_Conf_Int[1,1] , R_1_8k.ST_Conf_Int[1,1] ,R_2_0k.ST_Conf_Int[1,1] ,R_2_3k.ST_Conf_Int[1,1] ,R_2_6k.ST_Conf_Int[1,1] ,R_2_9k.ST_Conf_Int[1,1] ,R_3_0k.ST_Conf_Int[1,1] ,R_3_5k.ST_Conf_Int[1,1] , R_4_0k.ST_Conf_Int[1,1] ,R_4_5k.ST_Conf_Int[1,1] ,R_5_0k.ST_Conf_Int[1,1] ,R_6_0k.ST_Conf_Int[1,1] ,R_7_0k.ST_Conf_Int[1,1] ,R_8_0k.ST_Conf_Int[1,1] ,R_9_0k.ST_Conf_Int[1,1] , R_10_0k.ST_Conf_Int[1,1],R_12_5k.ST_Conf_Int[1,1],R_15_0k.ST_Conf_Int[1,1],R_17_5k.ST_Conf_Int[1,1],R_20_0k.ST_Conf_Int[1,1],R_25_0k.ST_Conf_Int[1,1],R_30_0k.ST_Conf_Int[1,1], R_35_0k.ST_Conf_Int[1,1],R_40_0k.ST_Conf_Int[1,1],R_45_0k.ST_Conf_Int[1,1],  R_50_0k.ST_Conf_Int[1,1],  R_50_0k.ST_Conf_Int[1,1],  R_60_0k.ST_Conf_Int[1,1],  R_65_0k.ST_Conf_Int[1,1],  R_70_0k.ST_Conf_Int[1,1],  R_75_0k.ST_Conf_Int[1,1],  R_80_0k.ST_Conf_Int[1,1],  R_85_0k.ST_Conf_Int[1,1],  R_90_0k.ST_Conf_Int[1,1],  R_95_0k.ST_Conf_Int[1,1],  R_100_0k.ST_Conf_Int[1,1],  R_105_0k.ST_Conf_Int[1,1],  R_110_0k.ST_Conf_Int[1,1],  R_115_0k.ST_Conf_Int[1,1],  R_120_0k.ST_Conf_Int[1,1],  R_125_0k.ST_Conf_Int[1,1],  R_130_0k.ST_Conf_Int[1,1],  R_135_0k.ST_Conf_Int[1,1],  R_140_0k.ST_Conf_Int[1,1],  R_145_0k.ST_Conf_Int[1,1],  R_150_0k.ST_Conf_Int[1,1]]
        
            PSV_R_ST_E = [R_0_1k.ST_Conf_Int[3,1], R_0_2k.ST_Conf_Int[3,1],R_0_3k.ST_Conf_Int[3,1] ,R_0_4k.ST_Conf_Int[3,1] ,R_0_5k.ST_Conf_Int[3,1] ,R_0_6k.ST_Conf_Int[3,1] , R_0_7k.ST_Conf_Int[3,1] ,R_0_8k.ST_Conf_Int[3,1] ,R_0_9k.ST_Conf_Int[3,1] ,R_1_0k.ST_Conf_Int[3,1] ,R_1_2k.ST_Conf_Int[3,1] ,R_1_4k.ST_Conf_Int[3,1] ,R_1_6k.ST_Conf_Int[3,1] , R_1_8k.ST_Conf_Int[3,1] ,R_2_0k.ST_Conf_Int[3,1] ,R_2_3k.ST_Conf_Int[3,1] ,R_2_6k.ST_Conf_Int[3,1] ,R_2_9k.ST_Conf_Int[3,1] ,R_3_0k.ST_Conf_Int[3,1] ,R_3_5k.ST_Conf_Int[3,1] , R_4_0k.ST_Conf_Int[3,1] ,R_4_5k.ST_Conf_Int[3,1] ,R_5_0k.ST_Conf_Int[3,1] ,R_6_0k.ST_Conf_Int[3,1] ,R_7_0k.ST_Conf_Int[3,1] ,R_8_0k.ST_Conf_Int[3,1] ,R_9_0k.ST_Conf_Int[3,1] , R_10_0k.ST_Conf_Int[3,1],R_12_5k.ST_Conf_Int[3,1],R_15_0k.ST_Conf_Int[3,1],R_17_5k.ST_Conf_Int[3,1],R_20_0k.ST_Conf_Int[3,1],R_25_0k.ST_Conf_Int[3,1],R_30_0k.ST_Conf_Int[3,1], R_35_0k.ST_Conf_Int[3,1],R_40_0k.ST_Conf_Int[3,1],R_45_0k.ST_Conf_Int[3,1],  R_50_0k.ST_Conf_Int[3,1],  R_50_0k.ST_Conf_Int[3,1],  R_60_0k.ST_Conf_Int[3,1],  R_65_0k.ST_Conf_Int[3,1],  R_70_0k.ST_Conf_Int[3,1],  R_75_0k.ST_Conf_Int[3,1],  R_80_0k.ST_Conf_Int[3,1],  R_85_0k.ST_Conf_Int[3,1],  R_90_0k.ST_Conf_Int[3,1],  R_95_0k.ST_Conf_Int[3,1],  R_100_0k.ST_Conf_Int[3,1],  R_105_0k.ST_Conf_Int[3,1],  R_110_0k.ST_Conf_Int[3,1],  R_115_0k.ST_Conf_Int[3,1],  R_120_0k.ST_Conf_Int[3,1],  R_125_0k.ST_Conf_Int[3,1],  R_130_0k.ST_Conf_Int[3,1],  R_135_0k.ST_Conf_Int[3,1],  R_140_0k.ST_Conf_Int[3,1],  R_145_0k.ST_Conf_Int[3,1],  R_150_0k.ST_Conf_Int[3,1]]
        end

        # High and Low errors reg S1 #
        # Cardiac Output
        LowE_CO_R_ST = CO_R_ST .- (1.96 .*CO_R_ST_E)
        HighE_CO_R_ST = CO_R_ST .+ (1.96 .*CO_R_ST_E)
        # Max PLV
        LowE_PLV_R_ST = PLV_R_ST .- (1.96 .*PLV_R_ST_E)
        HighE_PLV_R_ST = PLV_R_ST .+ (1.96 .*PLV_R_ST_E)
        # Max PSV
        LowE_PSV_R_ST = PSV_R_ST .- (1.96 .*PSV_R_ST_E)
        HighE_PSV_R_ST = PSV_R_ST .+ (1.96 .*PSV_R_ST_E)
    end 
    #CO ST R
    band!(x[1:end], min.(LowE_CO_R_ST, HighE_CO_R_ST), max.(LowE_CO_R_ST, HighE_CO_R_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_ST, label = "CO")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_R_ST, HighE_PLV_R_ST), max.(LowE_PLV_R_ST, HighE_PLV_R_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_ST, label = "PLV")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_R_ST, HighE_PSV_R_ST), max.(LowE_PSV_R_ST, HighE_PSV_R_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_ST, label = "PSV")
    hidexdecorations!(axg, grid = false)


    axh = Axis(gh[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    #Emax ST reg data
    begin
        ## load Reg data for CO PSV PLV ST ##
        begin
            CO_R_ST = [R_0_1k.ST[10,9], R_0_2k.ST[10,9],R_0_3k.ST[10,9] ,R_0_4k.ST[10,9] ,R_0_5k.ST[10,9] ,R_0_6k.ST[10,9] ,  R_0_7k.ST[10,9] ,R_0_8k.ST[10,9] ,R_0_9k.ST[10,9] ,R_1_0k.ST[10,9] ,R_1_2k.ST[10,9] ,R_1_4k.ST[10,9] ,R_1_6k.ST[10,9] ,  R_1_8k.ST[10,9] ,R_2_0k.ST[10,9] ,R_2_3k.ST[10,9] ,R_2_6k.ST[10,9] ,R_2_9k.ST[10,9] ,R_3_0k.ST[10,9] ,R_3_5k.ST[10,9] ,  R_4_0k.ST[10,9] ,R_4_5k.ST[10,9] ,R_5_0k.ST[10,9] ,R_6_0k.ST[10,9] ,R_7_0k.ST[10,9] ,R_8_0k.ST[10,9] ,R_9_0k.ST[10,9] ,  R_10_0k.ST[10,9],R_12_5k.ST[10,9],R_15_0k.ST[10,9],R_17_5k.ST[10,9],R_20_0k.ST[10,9],R_25_0k.ST[10,9],R_30_0k.ST[10,9],  R_35_0k.ST[10,9],R_40_0k.ST[10,9],R_45_0k.ST[10,9],  R_50_0k.ST[10,9],  R_50_0k.ST[10,9],  R_60_0k.ST[10,9],  R_65_0k.ST[10,9],  R_70_0k.ST[10,9],  R_75_0k.ST[10,9],  R_80_0k.ST[10,9],  R_85_0k.ST[10,9],  R_90_0k.ST[10,9],  R_95_0k.ST[10,9],  R_100_0k.ST[10,9],  R_105_0k.ST[10,9],  R_110_0k.ST[10,9],  R_115_0k.ST[10,9],  R_120_0k.ST[10,9],  R_125_0k.ST[10,9],  R_130_0k.ST[10,9],  R_135_0k.ST[10,9],  R_140_0k.ST[10,9],  R_145_0k.ST[10,9],  R_150_0k.ST[10,9]]
        
            PLV_R_ST = [R_0_1k.ST[1,9], R_0_2k.ST[1,9],R_0_3k.ST[1,9] ,R_0_4k.ST[1,9] ,R_0_5k.ST[1,9] ,R_0_6k.ST[1,9] , R_0_7k.ST[1,9] ,R_0_8k.ST[1,9] ,R_0_9k.ST[1,9] ,R_1_0k.ST[1,9] ,R_1_2k.ST[1,9] ,R_1_4k.ST[1,9] ,R_1_6k.ST[1,9] , R_1_8k.ST[1,9] ,R_2_0k.ST[1,9] ,R_2_3k.ST[1,9] ,R_2_6k.ST[1,9] ,R_2_9k.ST[1,9] ,R_3_0k.ST[1,9] ,R_3_5k.ST[1,9] , R_4_0k.ST[1,9] ,R_4_5k.ST[1,9] ,R_5_0k.ST[1,9] ,R_6_0k.ST[1,9] ,R_7_0k.ST[1,9] ,R_8_0k.ST[1,9] ,R_9_0k.ST[1,9] , R_10_0k.ST[1,9],R_12_5k.ST[1,9],R_15_0k.ST[1,9],R_17_5k.ST[1,9],R_20_0k.ST[1,9],R_25_0k.ST[1,9],R_30_0k.ST[1,9], R_35_0k.ST[1,9],R_40_0k.ST[1,9],R_45_0k.ST[1,9],  R_50_0k.ST[1,9],  R_50_0k.ST[1,9],  R_60_0k.ST[1,9],  R_65_0k.ST[1,9],  R_70_0k.ST[1,9],  R_75_0k.ST[1,9],  R_80_0k.ST[1,9],  R_85_0k.ST[1,9],  R_90_0k.ST[1,9],  R_95_0k.ST[1,9],  R_100_0k.ST[1,9],  R_105_0k.ST[1,9],  R_110_0k.ST[1,9],  R_115_0k.ST[1,9],  R_120_0k.ST[1,9],  R_125_0k.ST[1,9],  R_130_0k.ST[1,9],  R_135_0k.ST[1,9],  R_140_0k.ST[1,9],  R_145_0k.ST[1,9],  R_150_0k.ST[1,9]]
        
            PSV_R_ST = [R_0_1k.ST[3,9], R_0_2k.ST[3,9],R_0_3k.ST[3,9] ,R_0_4k.ST[3,9] ,R_0_5k.ST[3,9] ,R_0_6k.ST[3,9] , R_0_7k.ST[3,9] ,R_0_8k.ST[3,9] ,R_0_9k.ST[3,9] ,R_1_0k.ST[3,9] ,R_1_2k.ST[3,9] ,R_1_4k.ST[3,9] ,R_1_6k.ST[3,9] , R_1_8k.ST[3,9] ,R_2_0k.ST[3,9] ,R_2_3k.ST[3,9] ,R_2_6k.ST[3,9] ,R_2_9k.ST[3,9] ,R_3_0k.ST[3,9] ,R_3_5k.ST[3,9] , R_4_0k.ST[3,9] ,R_4_5k.ST[3,9] ,R_5_0k.ST[3,9] ,R_6_0k.ST[3,9] ,R_7_0k.ST[3,9] ,R_8_0k.ST[3,9] ,R_9_0k.ST[3,9] , R_10_0k.ST[3,9],R_12_5k.ST[3,9],R_15_0k.ST[3,9],R_17_5k.ST[3,9],R_20_0k.ST[3,9],R_25_0k.ST[3,9],R_30_0k.ST[3,9], R_35_0k.ST[3,9],R_40_0k.ST[3,9],R_45_0k.ST[3,9],  R_50_0k.ST[3,9],  R_50_0k.ST[3,9],  R_60_0k.ST[3,9],  R_65_0k.ST[3,9],  R_70_0k.ST[3,9],  R_75_0k.ST[3,9],  R_80_0k.ST[3,9],  R_85_0k.ST[3,9],  R_90_0k.ST[3,9],  R_95_0k.ST[3,9],  R_100_0k.ST[3,9],  R_105_0k.ST[3,9],  R_110_0k.ST[3,9],  R_115_0k.ST[3,9],  R_120_0k.ST[3,9],  R_125_0k.ST[3,9],  R_130_0k.ST[3,9],  R_135_0k.ST[3,9],  R_140_0k.ST[3,9],  R_145_0k.ST[3,9],  R_150_0k.ST[3,9]]
        end

        ## R errors for CO PSV PLV ST ##
        begin
            CO_R_ST_E = [R_0_1k.ST_Conf_Int[10,9], R_0_2k.ST_Conf_Int[10,9],R_0_3k.ST_Conf_Int[10,9] ,R_0_4k.ST_Conf_Int[10,9] ,R_0_5k.ST_Conf_Int[10,9] ,R_0_6k.ST_Conf_Int[10,9] ,  R_0_7k.ST_Conf_Int[10,9] ,R_0_8k.ST_Conf_Int[10,9] ,R_0_9k.ST_Conf_Int[10,9] ,R_1_0k.ST_Conf_Int[10,9] ,R_1_2k.ST_Conf_Int[10,9] ,R_1_4k.ST_Conf_Int[10,9] ,R_1_6k.ST_Conf_Int[10,9] ,  R_1_8k.ST_Conf_Int[10,9] ,R_2_0k.ST_Conf_Int[10,9] ,R_2_3k.ST_Conf_Int[10,9] ,R_2_6k.ST_Conf_Int[10,9] ,R_2_9k.ST_Conf_Int[10,9] ,R_3_0k.ST_Conf_Int[10,9] ,R_3_5k.ST_Conf_Int[10,9] ,  R_4_0k.ST_Conf_Int[10,9] ,R_4_5k.ST_Conf_Int[10,9] ,R_5_0k.ST_Conf_Int[10,9] ,R_6_0k.ST_Conf_Int[10,9] ,R_7_0k.ST_Conf_Int[10,9] ,R_8_0k.ST_Conf_Int[10,9] ,R_9_0k.ST_Conf_Int[10,9] ,  R_10_0k.ST_Conf_Int[10,9],R_12_5k.ST_Conf_Int[10,9],R_15_0k.ST_Conf_Int[10,9],R_17_5k.ST_Conf_Int[10,9],R_20_0k.ST_Conf_Int[10,9],R_25_0k.ST_Conf_Int[10,9],R_30_0k.ST_Conf_Int[10,9],  R_35_0k.ST_Conf_Int[10,9],R_40_0k.ST_Conf_Int[10,9],R_45_0k.ST_Conf_Int[10,9],  R_50_0k.ST_Conf_Int[10,9],  R_50_0k.ST_Conf_Int[10,9],  R_60_0k.ST_Conf_Int[10,9],  R_65_0k.ST_Conf_Int[10,9],  R_70_0k.ST_Conf_Int[10,9],  R_75_0k.ST_Conf_Int[10,9],  R_80_0k.ST_Conf_Int[10,9],  R_85_0k.ST_Conf_Int[10,9],  R_90_0k.ST_Conf_Int[10,9],  R_95_0k.ST_Conf_Int[10,9],  R_100_0k.ST_Conf_Int[10,9],  R_105_0k.ST_Conf_Int[10,9],  R_110_0k.ST_Conf_Int[10,9],  R_115_0k.ST_Conf_Int[10,9],  R_120_0k.ST_Conf_Int[10,9],  R_125_0k.ST_Conf_Int[10,9],  R_130_0k.ST_Conf_Int[10,9],  R_135_0k.ST_Conf_Int[10,9],  R_140_0k.ST_Conf_Int[10,9],  R_145_0k.ST_Conf_Int[10,9],  R_150_0k.ST_Conf_Int[10,9]]
        
            PLV_R_ST_E = [R_0_1k.ST_Conf_Int[1,9], R_0_2k.ST_Conf_Int[1,9],R_0_3k.ST_Conf_Int[1,9] ,R_0_4k.ST_Conf_Int[1,9] ,R_0_5k.ST_Conf_Int[1,9] ,R_0_6k.ST_Conf_Int[1,9] , R_0_7k.ST_Conf_Int[1,9] ,R_0_8k.ST_Conf_Int[1,9] ,R_0_9k.ST_Conf_Int[1,9] ,R_1_0k.ST_Conf_Int[1,9] ,R_1_2k.ST_Conf_Int[1,9] ,R_1_4k.ST_Conf_Int[1,9] ,R_1_6k.ST_Conf_Int[1,9] , R_1_8k.ST_Conf_Int[1,9] ,R_2_0k.ST_Conf_Int[1,9] ,R_2_3k.ST_Conf_Int[1,9] ,R_2_6k.ST_Conf_Int[1,9] ,R_2_9k.ST_Conf_Int[1,9] ,R_3_0k.ST_Conf_Int[1,9] ,R_3_5k.ST_Conf_Int[1,9] , R_4_0k.ST_Conf_Int[1,9] ,R_4_5k.ST_Conf_Int[1,9] ,R_5_0k.ST_Conf_Int[1,9] ,R_6_0k.ST_Conf_Int[1,9] ,R_7_0k.ST_Conf_Int[1,9] ,R_8_0k.ST_Conf_Int[1,9] ,R_9_0k.ST_Conf_Int[1,9] , R_10_0k.ST_Conf_Int[1,9],R_12_5k.ST_Conf_Int[1,9],R_15_0k.ST_Conf_Int[1,9],R_17_5k.ST_Conf_Int[1,9],R_20_0k.ST_Conf_Int[1,9],R_25_0k.ST_Conf_Int[1,9],R_30_0k.ST_Conf_Int[1,9], R_35_0k.ST_Conf_Int[1,9],R_40_0k.ST_Conf_Int[1,9],R_45_0k.ST_Conf_Int[1,9],  R_50_0k.ST_Conf_Int[1,9],  R_50_0k.ST_Conf_Int[1,9],  R_60_0k.ST_Conf_Int[1,9],  R_65_0k.ST_Conf_Int[1,9],  R_70_0k.ST_Conf_Int[1,9],  R_75_0k.ST_Conf_Int[1,9],  R_80_0k.ST_Conf_Int[1,9],  R_85_0k.ST_Conf_Int[1,9],  R_90_0k.ST_Conf_Int[1,9],  R_95_0k.ST_Conf_Int[1,9],  R_100_0k.ST_Conf_Int[1,9],  R_105_0k.ST_Conf_Int[1,9],  R_110_0k.ST_Conf_Int[1,9],  R_115_0k.ST_Conf_Int[1,9],  R_120_0k.ST_Conf_Int[1,9],  R_125_0k.ST_Conf_Int[1,9],  R_130_0k.ST_Conf_Int[1,9],  R_135_0k.ST_Conf_Int[1,9],  R_140_0k.ST_Conf_Int[1,9],  R_145_0k.ST_Conf_Int[1,9],  R_150_0k.ST_Conf_Int[1,9]]
        
            PSV_R_ST_E = [R_0_1k.ST_Conf_Int[3,9], R_0_2k.ST_Conf_Int[3,9],R_0_3k.ST_Conf_Int[3,9] ,R_0_4k.ST_Conf_Int[3,9] ,R_0_5k.ST_Conf_Int[3,9] ,R_0_6k.ST_Conf_Int[3,9] , R_0_7k.ST_Conf_Int[3,9] ,R_0_8k.ST_Conf_Int[3,9] ,R_0_9k.ST_Conf_Int[3,9] ,R_1_0k.ST_Conf_Int[3,9] ,R_1_2k.ST_Conf_Int[3,9] ,R_1_4k.ST_Conf_Int[3,9] ,R_1_6k.ST_Conf_Int[3,9] , R_1_8k.ST_Conf_Int[3,9] ,R_2_0k.ST_Conf_Int[3,9] ,R_2_3k.ST_Conf_Int[3,9] ,R_2_6k.ST_Conf_Int[3,9] ,R_2_9k.ST_Conf_Int[3,9] ,R_3_0k.ST_Conf_Int[3,9] ,R_3_5k.ST_Conf_Int[3,9] , R_4_0k.ST_Conf_Int[3,9] ,R_4_5k.ST_Conf_Int[3,9] ,R_5_0k.ST_Conf_Int[3,9] ,R_6_0k.ST_Conf_Int[3,9] ,R_7_0k.ST_Conf_Int[3,9] ,R_8_0k.ST_Conf_Int[3,9] ,R_9_0k.ST_Conf_Int[3,9] , R_10_0k.ST_Conf_Int[3,9],R_12_5k.ST_Conf_Int[3,9],R_15_0k.ST_Conf_Int[3,9],R_17_5k.ST_Conf_Int[3,9],R_20_0k.ST_Conf_Int[3,9],R_25_0k.ST_Conf_Int[3,9],R_30_0k.ST_Conf_Int[3,9], R_35_0k.ST_Conf_Int[3,9],R_40_0k.ST_Conf_Int[3,9],R_45_0k.ST_Conf_Int[3,9],  R_50_0k.ST_Conf_Int[3,9],  R_50_0k.ST_Conf_Int[3,9],  R_60_0k.ST_Conf_Int[3,9],  R_65_0k.ST_Conf_Int[3,9],  R_70_0k.ST_Conf_Int[3,9],  R_75_0k.ST_Conf_Int[3,9],  R_80_0k.ST_Conf_Int[3,9],  R_85_0k.ST_Conf_Int[3,9],  R_90_0k.ST_Conf_Int[3,9],  R_95_0k.ST_Conf_Int[3,9],  R_100_0k.ST_Conf_Int[3,9],  R_105_0k.ST_Conf_Int[3,9],  R_110_0k.ST_Conf_Int[3,9],  R_115_0k.ST_Conf_Int[3,9],  R_120_0k.ST_Conf_Int[3,9],  R_125_0k.ST_Conf_Int[3,9],  R_130_0k.ST_Conf_Int[3,9],  R_135_0k.ST_Conf_Int[3,9],  R_140_0k.ST_Conf_Int[3,9],  R_145_0k.ST_Conf_Int[3,9],  R_150_0k.ST_Conf_Int[3,9]]
        end

        # High and Low errors reg ST #
        # Cardiac Output
        LowE_CO_R_ST = CO_R_ST .- (1.96 .*CO_R_ST_E)
        HighE_CO_R_ST = CO_R_ST .+ (1.96 .*CO_R_ST_E)
        # Max PLV
        LowE_PLV_R_ST = PLV_R_ST .- (1.96 .*PLV_R_ST_E)
        HighE_PLV_R_ST = PLV_R_ST .+ (1.96 .*PLV_R_ST_E)
        # Max PSV
        LowE_PSV_R_ST = PSV_R_ST .- (1.96 .*PSV_R_ST_E)
        HighE_PSV_R_ST = PSV_R_ST .+ (1.96 .*PSV_R_ST_E)
    end 
    #CO ST R
    band!(x[1:end], min.(LowE_CO_R_ST, HighE_CO_R_ST), max.(LowE_CO_R_ST, HighE_CO_R_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_ST, label = "CO")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_R_ST, HighE_PLV_R_ST), max.(LowE_PLV_R_ST, HighE_PLV_R_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_ST, label = "PLV")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_R_ST, HighE_PSV_R_ST), max.(LowE_PSV_R_ST, HighE_PSV_R_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_ST, label = "PSV")
    hidexdecorations!(axh, grid = false)

    axi = Axis(gi[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    #Emin ST reg data
    begin
        ## load Reg data for CO PSV PLV ST ##
        begin
            CO_R_ST = [R_0_1k.ST[10,10], R_0_2k.ST[10,10],R_0_3k.ST[10,10] ,R_0_4k.ST[10,10] ,R_0_5k.ST[10,10] ,R_0_6k.ST[10,10] ,  R_0_7k.ST[10,10] ,R_0_8k.ST[10,10] ,R_0_9k.ST[10,10] ,R_1_0k.ST[10,10] ,R_1_2k.ST[10,10] ,R_1_4k.ST[10,10] ,R_1_6k.ST[10,10] ,  R_1_8k.ST[10,10] ,R_2_0k.ST[10,10] ,R_2_3k.ST[10,10] ,R_2_6k.ST[10,10] ,R_2_9k.ST[10,10] ,R_3_0k.ST[10,10] ,R_3_5k.ST[10,10] ,  R_4_0k.ST[10,10] ,R_4_5k.ST[10,10] ,R_5_0k.ST[10,10] ,R_6_0k.ST[10,10] ,R_7_0k.ST[10,10] ,R_8_0k.ST[10,10] ,R_9_0k.ST[10,10] ,  R_10_0k.ST[10,10],R_12_5k.ST[10,10],R_15_0k.ST[10,10],R_17_5k.ST[10,10],R_20_0k.ST[10,10],R_25_0k.ST[10,10],R_30_0k.ST[10,10],  R_35_0k.ST[10,10],R_40_0k.ST[10,10],R_45_0k.ST[10,10],  R_50_0k.ST[10,10],  R_50_0k.ST[10,10],  R_60_0k.ST[10,10],  R_65_0k.ST[10,10],  R_70_0k.ST[10,10],  R_75_0k.ST[10,10],  R_80_0k.ST[10,10],  R_85_0k.ST[10,10],  R_90_0k.ST[10,10],  R_95_0k.ST[10,10],  R_100_0k.ST[10,10],  R_105_0k.ST[10,10],  R_110_0k.ST[10,10],  R_115_0k.ST[10,10],  R_120_0k.ST[10,10],  R_125_0k.ST[10,10],  R_130_0k.ST[10,10],  R_135_0k.ST[10,10],  R_140_0k.ST[10,10],  R_145_0k.ST[10,10],  R_150_0k.ST[10,10]]
        
            PLV_R_ST = [R_0_1k.ST[1,10], R_0_2k.ST[1,10],R_0_3k.ST[1,10] ,R_0_4k.ST[1,10] ,R_0_5k.ST[1,10] ,R_0_6k.ST[1,10] , R_0_7k.ST[1,10] ,R_0_8k.ST[1,10] ,R_0_9k.ST[1,10] ,R_1_0k.ST[1,10] ,R_1_2k.ST[1,10] ,R_1_4k.ST[1,10] ,R_1_6k.ST[1,10] , R_1_8k.ST[1,10] ,R_2_0k.ST[1,10] ,R_2_3k.ST[1,10] ,R_2_6k.ST[1,10] ,R_2_9k.ST[1,10] ,R_3_0k.ST[1,10] ,R_3_5k.ST[1,10] , R_4_0k.ST[1,10] ,R_4_5k.ST[1,10] ,R_5_0k.ST[1,10] ,R_6_0k.ST[1,10] ,R_7_0k.ST[1,10] ,R_8_0k.ST[1,10] ,R_9_0k.ST[1,10] , R_10_0k.ST[1,10],R_12_5k.ST[1,10],R_15_0k.ST[1,10],R_17_5k.ST[1,10],R_20_0k.ST[1,10],R_25_0k.ST[1,10],R_30_0k.ST[1,10], R_35_0k.ST[1,10],R_40_0k.ST[1,10],R_45_0k.ST[1,10],  R_50_0k.ST[1,10],  R_50_0k.ST[1,10],  R_60_0k.ST[1,10],  R_65_0k.ST[1,10],  R_70_0k.ST[1,10],  R_75_0k.ST[1,10],  R_80_0k.ST[1,10],  R_85_0k.ST[1,10],  R_90_0k.ST[1,10],  R_95_0k.ST[1,10],  R_100_0k.ST[1,10],  R_105_0k.ST[1,10],  R_110_0k.ST[1,10],  R_115_0k.ST[1,10],  R_120_0k.ST[1,10],  R_125_0k.ST[1,10],  R_130_0k.ST[1,10],  R_135_0k.ST[1,10],  R_140_0k.ST[1,10],  R_145_0k.ST[1,10],  R_150_0k.ST[1,10]]
        
            PSV_R_ST = [R_0_1k.ST[3,10], R_0_2k.ST[3,10],R_0_3k.ST[3,10] ,R_0_4k.ST[3,10] ,R_0_5k.ST[3,10] ,R_0_6k.ST[3,10] , R_0_7k.ST[3,10] ,R_0_8k.ST[3,10] ,R_0_9k.ST[3,10] ,R_1_0k.ST[3,10] ,R_1_2k.ST[3,10] ,R_1_4k.ST[3,10] ,R_1_6k.ST[3,10] , R_1_8k.ST[3,10] ,R_2_0k.ST[3,10] ,R_2_3k.ST[3,10] ,R_2_6k.ST[3,10] ,R_2_9k.ST[3,10] ,R_3_0k.ST[3,10] ,R_3_5k.ST[3,10] , R_4_0k.ST[3,10] ,R_4_5k.ST[3,10] ,R_5_0k.ST[3,10] ,R_6_0k.ST[3,10] ,R_7_0k.ST[3,10] ,R_8_0k.ST[3,10] ,R_9_0k.ST[3,10] , R_10_0k.ST[3,10],R_12_5k.ST[3,10],R_15_0k.ST[3,10],R_17_5k.ST[3,10],R_20_0k.ST[3,10],R_25_0k.ST[3,10],R_30_0k.ST[3,10], R_35_0k.ST[3,10],R_40_0k.ST[3,10],R_45_0k.ST[3,10],  R_50_0k.ST[3,10],  R_50_0k.ST[3,10],  R_60_0k.ST[3,10],  R_65_0k.ST[3,10],  R_70_0k.ST[3,10],  R_75_0k.ST[3,10],  R_80_0k.ST[3,10],  R_85_0k.ST[3,10],  R_90_0k.ST[3,10],  R_95_0k.ST[3,10],  R_100_0k.ST[3,10],  R_105_0k.ST[3,10],  R_110_0k.ST[3,10],  R_115_0k.ST[3,10],  R_120_0k.ST[3,10],  R_125_0k.ST[3,10],  R_130_0k.ST[3,10],  R_135_0k.ST[3,10],  R_140_0k.ST[3,10],  R_145_0k.ST[3,10],  R_150_0k.ST[3,10]]
        end
    
        ## R errors for CO PSV PLV ST ##
        begin
            CO_R_ST_E = [R_0_1k.ST_Conf_Int[10,10], R_0_2k.ST_Conf_Int[10,10],R_0_3k.ST_Conf_Int[10,10] ,R_0_4k.ST_Conf_Int[10,10] ,R_0_5k.ST_Conf_Int[10,10] ,R_0_6k.ST_Conf_Int[10,10] ,  R_0_7k.ST_Conf_Int[10,10] ,R_0_8k.ST_Conf_Int[10,10] ,R_0_9k.ST_Conf_Int[10,10] ,R_1_0k.ST_Conf_Int[10,10] ,R_1_2k.ST_Conf_Int[10,10] ,R_1_4k.ST_Conf_Int[10,10] ,R_1_6k.ST_Conf_Int[10,10] ,  R_1_8k.ST_Conf_Int[10,10] ,R_2_0k.ST_Conf_Int[10,10] ,R_2_3k.ST_Conf_Int[10,10] ,R_2_6k.ST_Conf_Int[10,10] ,R_2_9k.ST_Conf_Int[10,10] ,R_3_0k.ST_Conf_Int[10,10] ,R_3_5k.ST_Conf_Int[10,10] ,  R_4_0k.ST_Conf_Int[10,10] ,R_4_5k.ST_Conf_Int[10,10] ,R_5_0k.ST_Conf_Int[10,10] ,R_6_0k.ST_Conf_Int[10,10] ,R_7_0k.ST_Conf_Int[10,10] ,R_8_0k.ST_Conf_Int[10,10] ,R_9_0k.ST_Conf_Int[10,10] ,  R_10_0k.ST_Conf_Int[10,10],R_12_5k.ST_Conf_Int[10,10],R_15_0k.ST_Conf_Int[10,10],R_17_5k.ST_Conf_Int[10,10],R_20_0k.ST_Conf_Int[10,10],R_25_0k.ST_Conf_Int[10,10],R_30_0k.ST_Conf_Int[10,10],  R_35_0k.ST_Conf_Int[10,10],R_40_0k.ST_Conf_Int[10,10],R_45_0k.ST_Conf_Int[10,10],  R_50_0k.ST_Conf_Int[10,10],  R_50_0k.ST_Conf_Int[10,10],  R_60_0k.ST_Conf_Int[10,10],  R_65_0k.ST_Conf_Int[10,10],  R_70_0k.ST_Conf_Int[10,10],  R_75_0k.ST_Conf_Int[10,10],  R_80_0k.ST_Conf_Int[10,10],  R_85_0k.ST_Conf_Int[10,10],  R_90_0k.ST_Conf_Int[10,10],  R_95_0k.ST_Conf_Int[10,10],  R_100_0k.ST_Conf_Int[10,10],  R_105_0k.ST_Conf_Int[10,10],  R_110_0k.ST_Conf_Int[10,10],  R_115_0k.ST_Conf_Int[10,10],  R_120_0k.ST_Conf_Int[10,10],  R_125_0k.ST_Conf_Int[10,10],  R_130_0k.ST_Conf_Int[10,10],  R_135_0k.ST_Conf_Int[10,10],  R_140_0k.ST_Conf_Int[10,10],  R_145_0k.ST_Conf_Int[10,10],  R_150_0k.ST_Conf_Int[10,10]]
        
            PLV_R_ST_E = [R_0_1k.ST_Conf_Int[1,10], R_0_2k.ST_Conf_Int[1,10],R_0_3k.ST_Conf_Int[1,10] ,R_0_4k.ST_Conf_Int[1,10] ,R_0_5k.ST_Conf_Int[1,10] ,R_0_6k.ST_Conf_Int[1,10] , R_0_7k.ST_Conf_Int[1,10] ,R_0_8k.ST_Conf_Int[1,10] ,R_0_9k.ST_Conf_Int[1,10] ,R_1_0k.ST_Conf_Int[1,10] ,R_1_2k.ST_Conf_Int[1,10] ,R_1_4k.ST_Conf_Int[1,10] ,R_1_6k.ST_Conf_Int[1,10] , R_1_8k.ST_Conf_Int[1,10] ,R_2_0k.ST_Conf_Int[1,10] ,R_2_3k.ST_Conf_Int[1,10] ,R_2_6k.ST_Conf_Int[1,10] ,R_2_9k.ST_Conf_Int[1,10] ,R_3_0k.ST_Conf_Int[1,10] ,R_3_5k.ST_Conf_Int[1,10] , R_4_0k.ST_Conf_Int[1,10] ,R_4_5k.ST_Conf_Int[1,10] ,R_5_0k.ST_Conf_Int[1,10] ,R_6_0k.ST_Conf_Int[1,10] ,R_7_0k.ST_Conf_Int[1,10] ,R_8_0k.ST_Conf_Int[1,10] ,R_9_0k.ST_Conf_Int[1,10] , R_10_0k.ST_Conf_Int[1,10],R_12_5k.ST_Conf_Int[1,10],R_15_0k.ST_Conf_Int[1,10],R_17_5k.ST_Conf_Int[1,10],R_20_0k.ST_Conf_Int[1,10],R_25_0k.ST_Conf_Int[1,10],R_30_0k.ST_Conf_Int[1,10], R_35_0k.ST_Conf_Int[1,10],R_40_0k.ST_Conf_Int[1,10],R_45_0k.ST_Conf_Int[1,10],  R_50_0k.ST_Conf_Int[1,10],  R_50_0k.ST_Conf_Int[1,10],  R_60_0k.ST_Conf_Int[1,10],  R_65_0k.ST_Conf_Int[1,10],  R_70_0k.ST_Conf_Int[1,10],  R_75_0k.ST_Conf_Int[1,10],  R_80_0k.ST_Conf_Int[1,10],  R_85_0k.ST_Conf_Int[1,10],  R_90_0k.ST_Conf_Int[1,10],  R_95_0k.ST_Conf_Int[1,10],  R_100_0k.ST_Conf_Int[1,10],  R_105_0k.ST_Conf_Int[1,10],  R_110_0k.ST_Conf_Int[1,10],  R_115_0k.ST_Conf_Int[1,10],  R_120_0k.ST_Conf_Int[1,10],  R_125_0k.ST_Conf_Int[1,10],  R_130_0k.ST_Conf_Int[1,10],  R_135_0k.ST_Conf_Int[1,10],  R_140_0k.ST_Conf_Int[1,10],  R_145_0k.ST_Conf_Int[1,10],  R_150_0k.ST_Conf_Int[1,10]]
        
            PSV_R_ST_E = [R_0_1k.ST_Conf_Int[3,10], R_0_2k.ST_Conf_Int[3,10],R_0_3k.ST_Conf_Int[3,10] ,R_0_4k.ST_Conf_Int[3,10] ,R_0_5k.ST_Conf_Int[3,10] ,R_0_6k.ST_Conf_Int[3,10] , R_0_7k.ST_Conf_Int[3,10] ,R_0_8k.ST_Conf_Int[3,10] ,R_0_9k.ST_Conf_Int[3,10] ,R_1_0k.ST_Conf_Int[3,10] ,R_1_2k.ST_Conf_Int[3,10] ,R_1_4k.ST_Conf_Int[3,10] ,R_1_6k.ST_Conf_Int[3,10] , R_1_8k.ST_Conf_Int[3,10] ,R_2_0k.ST_Conf_Int[3,10] ,R_2_3k.ST_Conf_Int[3,10] ,R_2_6k.ST_Conf_Int[3,10] ,R_2_9k.ST_Conf_Int[3,10] ,R_3_0k.ST_Conf_Int[3,10] ,R_3_5k.ST_Conf_Int[3,10] , R_4_0k.ST_Conf_Int[3,10] ,R_4_5k.ST_Conf_Int[3,10] ,R_5_0k.ST_Conf_Int[3,10] ,R_6_0k.ST_Conf_Int[3,10] ,R_7_0k.ST_Conf_Int[3,10] ,R_8_0k.ST_Conf_Int[3,10] ,R_9_0k.ST_Conf_Int[3,10] , R_10_0k.ST_Conf_Int[3,10],R_12_5k.ST_Conf_Int[3,10],R_15_0k.ST_Conf_Int[3,10],R_17_5k.ST_Conf_Int[3,10],R_20_0k.ST_Conf_Int[3,10],R_25_0k.ST_Conf_Int[3,10],R_30_0k.ST_Conf_Int[3,10], R_35_0k.ST_Conf_Int[3,10],R_40_0k.ST_Conf_Int[3,10],R_45_0k.ST_Conf_Int[3,10],  R_50_0k.ST_Conf_Int[3,10],  R_50_0k.ST_Conf_Int[3,10],  R_60_0k.ST_Conf_Int[3,10],  R_65_0k.ST_Conf_Int[3,10],  R_70_0k.ST_Conf_Int[3,10],  R_75_0k.ST_Conf_Int[3,10],  R_80_0k.ST_Conf_Int[3,10],  R_85_0k.ST_Conf_Int[3,10],  R_90_0k.ST_Conf_Int[3,10],  R_95_0k.ST_Conf_Int[3,10],  R_100_0k.ST_Conf_Int[3,10],  R_105_0k.ST_Conf_Int[3,10],  R_110_0k.ST_Conf_Int[3,10],  R_115_0k.ST_Conf_Int[3,10],  R_120_0k.ST_Conf_Int[3,10],  R_125_0k.ST_Conf_Int[3,10],  R_130_0k.ST_Conf_Int[3,10],  R_135_0k.ST_Conf_Int[3,10],  R_140_0k.ST_Conf_Int[3,10],  R_145_0k.ST_Conf_Int[3,10],  R_150_0k.ST_Conf_Int[3,10]]
        end
    
        # High and Low errors reg ST #
        # Cardiac Output
        LowE_CO_R_ST = CO_R_ST .- (1.96 .*CO_R_ST_E)
        HighE_CO_R_ST = CO_R_ST .+ (1.96 .*CO_R_ST_E)
        # Max PLV
        LowE_PLV_R_ST = PLV_R_ST .- (1.96 .*PLV_R_ST_E)
        HighE_PLV_R_ST = PLV_R_ST .+ (1.96 .*PLV_R_ST_E)
        # Max PSV
        LowE_PSV_R_ST = PSV_R_ST .- (1.96 .*PSV_R_ST_E)
        HighE_PSV_R_ST = PSV_R_ST .+ (1.96 .*PSV_R_ST_E)
    end 
    #CO ST R
    band!(x[1:end], min.(LowE_CO_R_ST, HighE_CO_R_ST), max.(LowE_CO_R_ST, HighE_CO_R_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_ST, label = "CO")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_R_ST, HighE_PLV_R_ST), max.(LowE_PLV_R_ST, HighE_PLV_R_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_ST, label = "PLV")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_R_ST, HighE_PSV_R_ST), max.(LowE_PSV_R_ST, HighE_PSV_R_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_ST, label = "PSV")
    hidexdecorations!(axi, grid = false)

    axj = Axis(gj[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    #Csa ST reg data
    begin
        ## load Reg data for CO PSV PLV ST ##
        begin
            CO_R_ST = [R_0_1k.ST[10,2], R_0_2k.ST[10,2],R_0_3k.ST[10,2] ,R_0_4k.ST[10,2] ,R_0_5k.ST[10,2] ,R_0_6k.ST[10,2] ,  R_0_7k.ST[10,2] ,R_0_8k.ST[10,2] ,R_0_9k.ST[10,2] ,R_1_0k.ST[10,2] ,R_1_2k.ST[10,2] ,R_1_4k.ST[10,2] ,R_1_6k.ST[10,2] ,  R_1_8k.ST[10,2] ,R_2_0k.ST[10,2] ,R_2_3k.ST[10,2] ,R_2_6k.ST[10,2] ,R_2_9k.ST[10,2] ,R_3_0k.ST[10,2] ,R_3_5k.ST[10,2] ,  R_4_0k.ST[10,2] ,R_4_5k.ST[10,2] ,R_5_0k.ST[10,2] ,R_6_0k.ST[10,2] ,R_7_0k.ST[10,2] ,R_8_0k.ST[10,2] ,R_9_0k.ST[10,2] ,  R_10_0k.ST[10,2],R_12_5k.ST[10,2],R_15_0k.ST[10,2],R_17_5k.ST[10,2],R_20_0k.ST[10,2],R_25_0k.ST[10,2],R_30_0k.ST[10,2],  R_35_0k.ST[10,2],R_40_0k.ST[10,2],R_45_0k.ST[10,2],  R_50_0k.ST[10,2],  R_50_0k.ST[10,2],  R_60_0k.ST[10,2],  R_65_0k.ST[10,2],  R_70_0k.ST[10,2],  R_75_0k.ST[10,2],  R_80_0k.ST[10,2],  R_85_0k.ST[10,2],  R_90_0k.ST[10,2],  R_95_0k.ST[10,2],  R_100_0k.ST[10,2],  R_105_0k.ST[10,2],  R_110_0k.ST[10,2],  R_115_0k.ST[10,2],  R_120_0k.ST[10,2],  R_125_0k.ST[10,2],  R_130_0k.ST[10,2],  R_135_0k.ST[10,2],  R_140_0k.ST[10,2],  R_145_0k.ST[10,2],  R_150_0k.ST[10,2]]
        
            PLV_R_ST = [R_0_1k.ST[1,2], R_0_2k.ST[1,2],R_0_3k.ST[1,2] ,R_0_4k.ST[1,2] ,R_0_5k.ST[1,2] ,R_0_6k.ST[1,2] , R_0_7k.ST[1,2] ,R_0_8k.ST[1,2] ,R_0_9k.ST[1,2] ,R_1_0k.ST[1,2] ,R_1_2k.ST[1,2] ,R_1_4k.ST[1,2] ,R_1_6k.ST[1,2] , R_1_8k.ST[1,2] ,R_2_0k.ST[1,2] ,R_2_3k.ST[1,2] ,R_2_6k.ST[1,2] ,R_2_9k.ST[1,2] ,R_3_0k.ST[1,2] ,R_3_5k.ST[1,2] , R_4_0k.ST[1,2] ,R_4_5k.ST[1,2] ,R_5_0k.ST[1,2] ,R_6_0k.ST[1,2] ,R_7_0k.ST[1,2] ,R_8_0k.ST[1,2] ,R_9_0k.ST[1,2] , R_10_0k.ST[1,2],R_12_5k.ST[1,2],R_15_0k.ST[1,2],R_17_5k.ST[1,2],R_20_0k.ST[1,2],R_25_0k.ST[1,2],R_30_0k.ST[1,2], R_35_0k.ST[1,2],R_40_0k.ST[1,2],R_45_0k.ST[1,2],  R_50_0k.ST[1,2],  R_50_0k.ST[1,2],  R_60_0k.ST[1,2],  R_65_0k.ST[1,2],  R_70_0k.ST[1,2],  R_75_0k.ST[1,2],  R_80_0k.ST[1,2],  R_85_0k.ST[1,2],  R_90_0k.ST[1,2],  R_95_0k.ST[1,2],  R_100_0k.ST[1,2],  R_105_0k.ST[1,2],  R_110_0k.ST[1,2],  R_115_0k.ST[1,2],  R_120_0k.ST[1,2],  R_125_0k.ST[1,2],  R_130_0k.ST[1,2],  R_135_0k.ST[1,2],  R_140_0k.ST[1,2],  R_145_0k.ST[1,2],  R_150_0k.ST[1,2]]
        
            PSV_R_ST = [R_0_1k.ST[3,2], R_0_2k.ST[3,2],R_0_3k.ST[3,2] ,R_0_4k.ST[3,2] ,R_0_5k.ST[3,2] ,R_0_6k.ST[3,2] , R_0_7k.ST[3,2] ,R_0_8k.ST[3,2] ,R_0_9k.ST[3,2] ,R_1_0k.ST[3,2] ,R_1_2k.ST[3,2] ,R_1_4k.ST[3,2] ,R_1_6k.ST[3,2] , R_1_8k.ST[3,2] ,R_2_0k.ST[3,2] ,R_2_3k.ST[3,2] ,R_2_6k.ST[3,2] ,R_2_9k.ST[3,2] ,R_3_0k.ST[3,2] ,R_3_5k.ST[3,2] , R_4_0k.ST[3,2] ,R_4_5k.ST[3,2] ,R_5_0k.ST[3,2] ,R_6_0k.ST[3,2] ,R_7_0k.ST[3,2] ,R_8_0k.ST[3,2] ,R_9_0k.ST[3,2] , R_10_0k.ST[3,2],R_12_5k.ST[3,2],R_15_0k.ST[3,2],R_17_5k.ST[3,2],R_20_0k.ST[3,2],R_25_0k.ST[3,2],R_30_0k.ST[3,2], R_35_0k.ST[3,2],R_40_0k.ST[3,2],R_45_0k.ST[3,2],  R_50_0k.ST[3,2],  R_50_0k.ST[3,2],  R_60_0k.ST[3,2],  R_65_0k.ST[3,2],  R_70_0k.ST[3,2],  R_75_0k.ST[3,2],  R_80_0k.ST[3,2],  R_85_0k.ST[3,2],  R_90_0k.ST[3,2],  R_95_0k.ST[3,2],  R_100_0k.ST[3,2],  R_105_0k.ST[3,2],  R_110_0k.ST[3,2],  R_115_0k.ST[3,2],  R_120_0k.ST[3,2],  R_125_0k.ST[3,2],  R_130_0k.ST[3,2],  R_135_0k.ST[3,2],  R_140_0k.ST[3,2],  R_145_0k.ST[3,2],  R_150_0k.ST[3,2]]
        end
    
        ## R errors for CO PSV PLV ST ##
        begin
            CO_R_ST_E = [R_0_1k.ST_Conf_Int[10,2], R_0_2k.ST_Conf_Int[10,2],R_0_3k.ST_Conf_Int[10,2] ,R_0_4k.ST_Conf_Int[10,2] ,R_0_5k.ST_Conf_Int[10,2] ,R_0_6k.ST_Conf_Int[10,2] ,  R_0_7k.ST_Conf_Int[10,2] ,R_0_8k.ST_Conf_Int[10,2] ,R_0_9k.ST_Conf_Int[10,2] ,R_1_0k.ST_Conf_Int[10,2] ,R_1_2k.ST_Conf_Int[10,2] ,R_1_4k.ST_Conf_Int[10,2] ,R_1_6k.ST_Conf_Int[10,2] ,  R_1_8k.ST_Conf_Int[10,2] ,R_2_0k.ST_Conf_Int[10,2] ,R_2_3k.ST_Conf_Int[10,2] ,R_2_6k.ST_Conf_Int[10,2] ,R_2_9k.ST_Conf_Int[10,2] ,R_3_0k.ST_Conf_Int[10,2] ,R_3_5k.ST_Conf_Int[10,2] ,  R_4_0k.ST_Conf_Int[10,2] ,R_4_5k.ST_Conf_Int[10,2] ,R_5_0k.ST_Conf_Int[10,2] ,R_6_0k.ST_Conf_Int[10,2] ,R_7_0k.ST_Conf_Int[10,2] ,R_8_0k.ST_Conf_Int[10,2] ,R_9_0k.ST_Conf_Int[10,2] ,  R_10_0k.ST_Conf_Int[10,2],R_12_5k.ST_Conf_Int[10,2],R_15_0k.ST_Conf_Int[10,2],R_17_5k.ST_Conf_Int[10,2],R_20_0k.ST_Conf_Int[10,2],R_25_0k.ST_Conf_Int[10,2],R_30_0k.ST_Conf_Int[10,2],  R_35_0k.ST_Conf_Int[10,2],R_40_0k.ST_Conf_Int[10,2],R_45_0k.ST_Conf_Int[10,2],  R_50_0k.ST_Conf_Int[10,2],  R_50_0k.ST_Conf_Int[10,2],  R_60_0k.ST_Conf_Int[10,2],  R_65_0k.ST_Conf_Int[10,2],  R_70_0k.ST_Conf_Int[10,2],  R_75_0k.ST_Conf_Int[10,2],  R_80_0k.ST_Conf_Int[10,2],  R_85_0k.ST_Conf_Int[10,2],  R_90_0k.ST_Conf_Int[10,2],  R_95_0k.ST_Conf_Int[10,2],  R_100_0k.ST_Conf_Int[10,2],  R_105_0k.ST_Conf_Int[10,2],  R_110_0k.ST_Conf_Int[10,2],  R_115_0k.ST_Conf_Int[10,2],  R_120_0k.ST_Conf_Int[10,2],  R_125_0k.ST_Conf_Int[10,2],  R_130_0k.ST_Conf_Int[10,2],  R_135_0k.ST_Conf_Int[10,2],  R_140_0k.ST_Conf_Int[10,2],  R_145_0k.ST_Conf_Int[10,2],  R_150_0k.ST_Conf_Int[10,2]]
        
            PLV_R_ST_E = [R_0_1k.ST_Conf_Int[1,2], R_0_2k.ST_Conf_Int[1,2],R_0_3k.ST_Conf_Int[1,2] ,R_0_4k.ST_Conf_Int[1,2] ,R_0_5k.ST_Conf_Int[1,2] ,R_0_6k.ST_Conf_Int[1,2] , R_0_7k.ST_Conf_Int[1,2] ,R_0_8k.ST_Conf_Int[1,2] ,R_0_9k.ST_Conf_Int[1,2] ,R_1_0k.ST_Conf_Int[1,2] ,R_1_2k.ST_Conf_Int[1,2] ,R_1_4k.ST_Conf_Int[1,2] ,R_1_6k.ST_Conf_Int[1,2] , R_1_8k.ST_Conf_Int[1,2] ,R_2_0k.ST_Conf_Int[1,2] ,R_2_3k.ST_Conf_Int[1,2] ,R_2_6k.ST_Conf_Int[1,2] ,R_2_9k.ST_Conf_Int[1,2] ,R_3_0k.ST_Conf_Int[1,2] ,R_3_5k.ST_Conf_Int[1,2] , R_4_0k.ST_Conf_Int[1,2] ,R_4_5k.ST_Conf_Int[1,2] ,R_5_0k.ST_Conf_Int[1,2] ,R_6_0k.ST_Conf_Int[1,2] ,R_7_0k.ST_Conf_Int[1,2] ,R_8_0k.ST_Conf_Int[1,2] ,R_9_0k.ST_Conf_Int[1,2] , R_10_0k.ST_Conf_Int[1,2],R_12_5k.ST_Conf_Int[1,2],R_15_0k.ST_Conf_Int[1,2],R_17_5k.ST_Conf_Int[1,2],R_20_0k.ST_Conf_Int[1,2],R_25_0k.ST_Conf_Int[1,2],R_30_0k.ST_Conf_Int[1,2], R_35_0k.ST_Conf_Int[1,2],R_40_0k.ST_Conf_Int[1,2],R_45_0k.ST_Conf_Int[1,2],  R_50_0k.ST_Conf_Int[1,2],  R_50_0k.ST_Conf_Int[1,2],  R_60_0k.ST_Conf_Int[1,2],  R_65_0k.ST_Conf_Int[1,2],  R_70_0k.ST_Conf_Int[1,2],  R_75_0k.ST_Conf_Int[1,2],  R_80_0k.ST_Conf_Int[1,2],  R_85_0k.ST_Conf_Int[1,2],  R_90_0k.ST_Conf_Int[1,2],  R_95_0k.ST_Conf_Int[1,2],  R_100_0k.ST_Conf_Int[1,2],  R_105_0k.ST_Conf_Int[1,2],  R_110_0k.ST_Conf_Int[1,2],  R_115_0k.ST_Conf_Int[1,2],  R_120_0k.ST_Conf_Int[1,2],  R_125_0k.ST_Conf_Int[1,2],  R_130_0k.ST_Conf_Int[1,2],  R_135_0k.ST_Conf_Int[1,2],  R_140_0k.ST_Conf_Int[1,2],  R_145_0k.ST_Conf_Int[1,2],  R_150_0k.ST_Conf_Int[1,2]]
        
            PSV_R_ST_E = [R_0_1k.ST_Conf_Int[3,2], R_0_2k.ST_Conf_Int[3,2],R_0_3k.ST_Conf_Int[3,2] ,R_0_4k.ST_Conf_Int[3,2] ,R_0_5k.ST_Conf_Int[3,2] ,R_0_6k.ST_Conf_Int[3,2] , R_0_7k.ST_Conf_Int[3,2] ,R_0_8k.ST_Conf_Int[3,2] ,R_0_9k.ST_Conf_Int[3,2] ,R_1_0k.ST_Conf_Int[3,2] ,R_1_2k.ST_Conf_Int[3,2] ,R_1_4k.ST_Conf_Int[3,2] ,R_1_6k.ST_Conf_Int[3,2] , R_1_8k.ST_Conf_Int[3,2] ,R_2_0k.ST_Conf_Int[3,2] ,R_2_3k.ST_Conf_Int[3,2] ,R_2_6k.ST_Conf_Int[3,2] ,R_2_9k.ST_Conf_Int[3,2] ,R_3_0k.ST_Conf_Int[3,2] ,R_3_5k.ST_Conf_Int[3,2] , R_4_0k.ST_Conf_Int[3,2] ,R_4_5k.ST_Conf_Int[3,2] ,R_5_0k.ST_Conf_Int[3,2] ,R_6_0k.ST_Conf_Int[3,2] ,R_7_0k.ST_Conf_Int[3,2] ,R_8_0k.ST_Conf_Int[3,2] ,R_9_0k.ST_Conf_Int[3,2] , R_10_0k.ST_Conf_Int[3,2],R_12_5k.ST_Conf_Int[3,2],R_15_0k.ST_Conf_Int[3,2],R_17_5k.ST_Conf_Int[3,2],R_20_0k.ST_Conf_Int[3,2],R_25_0k.ST_Conf_Int[3,2],R_30_0k.ST_Conf_Int[3,2], R_35_0k.ST_Conf_Int[3,2],R_40_0k.ST_Conf_Int[3,2],R_45_0k.ST_Conf_Int[3,2],  R_50_0k.ST_Conf_Int[3,2],  R_50_0k.ST_Conf_Int[3,2],  R_60_0k.ST_Conf_Int[3,2],  R_65_0k.ST_Conf_Int[3,2],  R_70_0k.ST_Conf_Int[3,2],  R_75_0k.ST_Conf_Int[3,2],  R_80_0k.ST_Conf_Int[3,2],  R_85_0k.ST_Conf_Int[3,2],  R_90_0k.ST_Conf_Int[3,2],  R_95_0k.ST_Conf_Int[3,2],  R_100_0k.ST_Conf_Int[3,2],  R_105_0k.ST_Conf_Int[3,2],  R_110_0k.ST_Conf_Int[3,2],  R_115_0k.ST_Conf_Int[3,2],  R_120_0k.ST_Conf_Int[3,2],  R_125_0k.ST_Conf_Int[3,2],  R_130_0k.ST_Conf_Int[3,2],  R_135_0k.ST_Conf_Int[3,2],  R_140_0k.ST_Conf_Int[3,2],  R_145_0k.ST_Conf_Int[3,2],  R_150_0k.ST_Conf_Int[3,2]]
        end
    
        # High and Low errors reg ST #
        # Cardiac Output
        LowE_CO_R_ST = CO_R_ST .- (1.96 .*CO_R_ST_E)
        HighE_CO_R_ST = CO_R_ST .+ (1.96 .*CO_R_ST_E)
        # Max PLV
        LowE_PLV_R_ST = PLV_R_ST .- (1.96 .*PLV_R_ST_E)
        HighE_PLV_R_ST = PLV_R_ST .+ (1.96 .*PLV_R_ST_E)
        # Max PSV
        LowE_PSV_R_ST = PSV_R_ST .- (1.96 .*PSV_R_ST_E)
        HighE_PSV_R_ST = PSV_R_ST .+ (1.96 .*PSV_R_ST_E)
    end 
    #CO ST R
    band!(x[1:end], min.(LowE_CO_R_ST, HighE_CO_R_ST), max.(LowE_CO_R_ST, HighE_CO_R_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_ST, label = "CO")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_R_ST, HighE_PLV_R_ST), max.(LowE_PLV_R_ST, HighE_PLV_R_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_ST, label = "PLV")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_R_ST, HighE_PSV_R_ST), max.(LowE_PSV_R_ST, HighE_PSV_R_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_ST, label = "PSV")
    hidexdecorations!(axj, grid = false)
    
    axk = Axis(gk[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    #Pn ST reg data
    begin
        ## load Reg data for CO PSV PLV ST ##
        begin
            CO_R_ST = [R_0_1k.ST[10,11], R_0_2k.ST[10,11],R_0_3k.ST[10,11] ,R_0_4k.ST[10,11] ,R_0_5k.ST[10,11] ,R_0_6k.ST[10,11] ,  R_0_7k.ST[10,11] ,R_0_8k.ST[10,11] ,R_0_9k.ST[10,11] ,R_1_0k.ST[10,11] ,R_1_2k.ST[10,11] ,R_1_4k.ST[10,11] ,R_1_6k.ST[10,11] ,  R_1_8k.ST[10,11] ,R_2_0k.ST[10,11] ,R_2_3k.ST[10,11] ,R_2_6k.ST[10,11] ,R_2_9k.ST[10,11] ,R_3_0k.ST[10,11] ,R_3_5k.ST[10,11] ,  R_4_0k.ST[10,11] ,R_4_5k.ST[10,11] ,R_5_0k.ST[10,11] ,R_6_0k.ST[10,11] ,R_7_0k.ST[10,11] ,R_8_0k.ST[10,11] ,R_9_0k.ST[10,11] ,  R_10_0k.ST[10,11],R_12_5k.ST[10,11],R_15_0k.ST[10,11],R_17_5k.ST[10,11],R_20_0k.ST[10,11],R_25_0k.ST[10,11],R_30_0k.ST[10,11],  R_35_0k.ST[10,11],R_40_0k.ST[10,11],R_45_0k.ST[10,11],  R_50_0k.ST[10,11],  R_50_0k.ST[10,11],  R_60_0k.ST[10,11],  R_65_0k.ST[10,11],  R_70_0k.ST[10,11],  R_75_0k.ST[10,11],  R_80_0k.ST[10,11],  R_85_0k.ST[10,11],  R_90_0k.ST[10,11],  R_95_0k.ST[10,11],  R_100_0k.ST[10,11],  R_105_0k.ST[10,11],  R_110_0k.ST[10,11],  R_115_0k.ST[10,11],  R_120_0k.ST[10,11],  R_125_0k.ST[10,11],  R_130_0k.ST[10,11],  R_135_0k.ST[10,11],  R_140_0k.ST[10,11],  R_145_0k.ST[10,11],  R_150_0k.ST[10,11]]
        
            PLV_R_ST = [R_0_1k.ST[1,11], R_0_2k.ST[1,11],R_0_3k.ST[1,11] ,R_0_4k.ST[1,11] ,R_0_5k.ST[1,11] ,R_0_6k.ST[1,11] , R_0_7k.ST[1,11] ,R_0_8k.ST[1,11] ,R_0_9k.ST[1,11] ,R_1_0k.ST[1,11] ,R_1_2k.ST[1,11] ,R_1_4k.ST[1,11] ,R_1_6k.ST[1,11] , R_1_8k.ST[1,11] ,R_2_0k.ST[1,11] ,R_2_3k.ST[1,11] ,R_2_6k.ST[1,11] ,R_2_9k.ST[1,11] ,R_3_0k.ST[1,11] ,R_3_5k.ST[1,11] , R_4_0k.ST[1,11] ,R_4_5k.ST[1,11] ,R_5_0k.ST[1,11] ,R_6_0k.ST[1,11] ,R_7_0k.ST[1,11] ,R_8_0k.ST[1,11] ,R_9_0k.ST[1,11] , R_10_0k.ST[1,11],R_12_5k.ST[1,11],R_15_0k.ST[1,11],R_17_5k.ST[1,11],R_20_0k.ST[1,11],R_25_0k.ST[1,11],R_30_0k.ST[1,11], R_35_0k.ST[1,11],R_40_0k.ST[1,11],R_45_0k.ST[1,11],  R_50_0k.ST[1,11],  R_50_0k.ST[1,11],  R_60_0k.ST[1,11],  R_65_0k.ST[1,11],  R_70_0k.ST[1,11],  R_75_0k.ST[1,11],  R_80_0k.ST[1,11],  R_85_0k.ST[1,11],  R_90_0k.ST[1,11],  R_95_0k.ST[1,11],  R_100_0k.ST[1,11],  R_105_0k.ST[1,11],  R_110_0k.ST[1,11],  R_115_0k.ST[1,11],  R_120_0k.ST[1,11],  R_125_0k.ST[1,11],  R_130_0k.ST[1,11],  R_135_0k.ST[1,11],  R_140_0k.ST[1,11],  R_145_0k.ST[1,11],  R_150_0k.ST[1,11]]
        
            PSV_R_ST = [R_0_1k.ST[3,11], R_0_2k.ST[3,11],R_0_3k.ST[3,11] ,R_0_4k.ST[3,11] ,R_0_5k.ST[3,11] ,R_0_6k.ST[3,11] , R_0_7k.ST[3,11] ,R_0_8k.ST[3,11] ,R_0_9k.ST[3,11] ,R_1_0k.ST[3,11] ,R_1_2k.ST[3,11] ,R_1_4k.ST[3,11] ,R_1_6k.ST[3,11] , R_1_8k.ST[3,11] ,R_2_0k.ST[3,11] ,R_2_3k.ST[3,11] ,R_2_6k.ST[3,11] ,R_2_9k.ST[3,11] ,R_3_0k.ST[3,11] ,R_3_5k.ST[3,11] , R_4_0k.ST[3,11] ,R_4_5k.ST[3,11] ,R_5_0k.ST[3,11] ,R_6_0k.ST[3,11] ,R_7_0k.ST[3,11] ,R_8_0k.ST[3,11] ,R_9_0k.ST[3,11] , R_10_0k.ST[3,11],R_12_5k.ST[3,11],R_15_0k.ST[3,11],R_17_5k.ST[3,11],R_20_0k.ST[3,11],R_25_0k.ST[3,11],R_30_0k.ST[3,11], R_35_0k.ST[3,11],R_40_0k.ST[3,11],R_45_0k.ST[3,11],  R_50_0k.ST[3,11],  R_50_0k.ST[3,11],  R_60_0k.ST[3,11],  R_65_0k.ST[3,11],  R_70_0k.ST[3,11],  R_75_0k.ST[3,11],  R_80_0k.ST[3,11],  R_85_0k.ST[3,11],  R_90_0k.ST[3,11],  R_95_0k.ST[3,11],  R_100_0k.ST[3,11],  R_105_0k.ST[3,11],  R_110_0k.ST[3,11],  R_115_0k.ST[3,11],  R_120_0k.ST[3,11],  R_125_0k.ST[3,11],  R_130_0k.ST[3,11],  R_135_0k.ST[3,11],  R_140_0k.ST[3,11],  R_145_0k.ST[3,11],  R_150_0k.ST[3,11]]
        end
    
        ## R errors for CO PSV PLV ST ##
        begin
            CO_R_ST_E = [R_0_1k.ST_Conf_Int[10,11], R_0_2k.ST_Conf_Int[10,11],R_0_3k.ST_Conf_Int[10,11] ,R_0_4k.ST_Conf_Int[10,11] ,R_0_5k.ST_Conf_Int[10,11] ,R_0_6k.ST_Conf_Int[10,11] ,  R_0_7k.ST_Conf_Int[10,11] ,R_0_8k.ST_Conf_Int[10,11] ,R_0_9k.ST_Conf_Int[10,11] ,R_1_0k.ST_Conf_Int[10,11] ,R_1_2k.ST_Conf_Int[10,11] ,R_1_4k.ST_Conf_Int[10,11] ,R_1_6k.ST_Conf_Int[10,11] ,  R_1_8k.ST_Conf_Int[10,11] ,R_2_0k.ST_Conf_Int[10,11] ,R_2_3k.ST_Conf_Int[10,11] ,R_2_6k.ST_Conf_Int[10,11] ,R_2_9k.ST_Conf_Int[10,11] ,R_3_0k.ST_Conf_Int[10,11] ,R_3_5k.ST_Conf_Int[10,11] ,  R_4_0k.ST_Conf_Int[10,11] ,R_4_5k.ST_Conf_Int[10,11] ,R_5_0k.ST_Conf_Int[10,11] ,R_6_0k.ST_Conf_Int[10,11] ,R_7_0k.ST_Conf_Int[10,11] ,R_8_0k.ST_Conf_Int[10,11] ,R_9_0k.ST_Conf_Int[10,11] ,  R_10_0k.ST_Conf_Int[10,11],R_12_5k.ST_Conf_Int[10,11],R_15_0k.ST_Conf_Int[10,11],R_17_5k.ST_Conf_Int[10,11],R_20_0k.ST_Conf_Int[10,11],R_25_0k.ST_Conf_Int[10,11],R_30_0k.ST_Conf_Int[10,11],  R_35_0k.ST_Conf_Int[10,11],R_40_0k.ST_Conf_Int[10,11],R_45_0k.ST_Conf_Int[10,11],  R_50_0k.ST_Conf_Int[10,11],  R_50_0k.ST_Conf_Int[10,11],  R_60_0k.ST_Conf_Int[10,11],  R_65_0k.ST_Conf_Int[10,11],  R_70_0k.ST_Conf_Int[10,11],  R_75_0k.ST_Conf_Int[10,11],  R_80_0k.ST_Conf_Int[10,11],  R_85_0k.ST_Conf_Int[10,11],  R_90_0k.ST_Conf_Int[10,11],  R_95_0k.ST_Conf_Int[10,11],  R_100_0k.ST_Conf_Int[10,11],  R_105_0k.ST_Conf_Int[10,11],  R_110_0k.ST_Conf_Int[10,11],  R_115_0k.ST_Conf_Int[10,11],  R_120_0k.ST_Conf_Int[10,11],  R_125_0k.ST_Conf_Int[10,11],  R_130_0k.ST_Conf_Int[10,11],  R_135_0k.ST_Conf_Int[10,11],  R_140_0k.ST_Conf_Int[10,11],  R_145_0k.ST_Conf_Int[10,11],  R_150_0k.ST_Conf_Int[10,11]]
        
            PLV_R_ST_E = [R_0_1k.ST_Conf_Int[1,11], R_0_2k.ST_Conf_Int[1,11],R_0_3k.ST_Conf_Int[1,11] ,R_0_4k.ST_Conf_Int[1,11] ,R_0_5k.ST_Conf_Int[1,11] ,R_0_6k.ST_Conf_Int[1,11] , R_0_7k.ST_Conf_Int[1,11] ,R_0_8k.ST_Conf_Int[1,11] ,R_0_9k.ST_Conf_Int[1,11] ,R_1_0k.ST_Conf_Int[1,11] ,R_1_2k.ST_Conf_Int[1,11] ,R_1_4k.ST_Conf_Int[1,11] ,R_1_6k.ST_Conf_Int[1,11] , R_1_8k.ST_Conf_Int[1,11] ,R_2_0k.ST_Conf_Int[1,11] ,R_2_3k.ST_Conf_Int[1,11] ,R_2_6k.ST_Conf_Int[1,11] ,R_2_9k.ST_Conf_Int[1,11] ,R_3_0k.ST_Conf_Int[1,11] ,R_3_5k.ST_Conf_Int[1,11] , R_4_0k.ST_Conf_Int[1,11] ,R_4_5k.ST_Conf_Int[1,11] ,R_5_0k.ST_Conf_Int[1,11] ,R_6_0k.ST_Conf_Int[1,11] ,R_7_0k.ST_Conf_Int[1,11] ,R_8_0k.ST_Conf_Int[1,11] ,R_9_0k.ST_Conf_Int[1,11] , R_10_0k.ST_Conf_Int[1,11],R_12_5k.ST_Conf_Int[1,11],R_15_0k.ST_Conf_Int[1,11],R_17_5k.ST_Conf_Int[1,11],R_20_0k.ST_Conf_Int[1,11],R_25_0k.ST_Conf_Int[1,11],R_30_0k.ST_Conf_Int[1,11], R_35_0k.ST_Conf_Int[1,11],R_40_0k.ST_Conf_Int[1,11],R_45_0k.ST_Conf_Int[1,11],  R_50_0k.ST_Conf_Int[1,11],  R_50_0k.ST_Conf_Int[1,11],  R_60_0k.ST_Conf_Int[1,11],  R_65_0k.ST_Conf_Int[1,11],  R_70_0k.ST_Conf_Int[1,11],  R_75_0k.ST_Conf_Int[1,11],  R_80_0k.ST_Conf_Int[1,11],  R_85_0k.ST_Conf_Int[1,11],  R_90_0k.ST_Conf_Int[1,11],  R_95_0k.ST_Conf_Int[1,11],  R_100_0k.ST_Conf_Int[1,11],  R_105_0k.ST_Conf_Int[1,11],  R_110_0k.ST_Conf_Int[1,11],  R_115_0k.ST_Conf_Int[1,11],  R_120_0k.ST_Conf_Int[1,11],  R_125_0k.ST_Conf_Int[1,11],  R_130_0k.ST_Conf_Int[1,11],  R_135_0k.ST_Conf_Int[1,11],  R_140_0k.ST_Conf_Int[1,11],  R_145_0k.ST_Conf_Int[1,11],  R_150_0k.ST_Conf_Int[1,11]]
        
            PSV_R_ST_E = [R_0_1k.ST_Conf_Int[3,11], R_0_2k.ST_Conf_Int[3,11],R_0_3k.ST_Conf_Int[3,11] ,R_0_4k.ST_Conf_Int[3,11] ,R_0_5k.ST_Conf_Int[3,11] ,R_0_6k.ST_Conf_Int[3,11] , R_0_7k.ST_Conf_Int[3,11] ,R_0_8k.ST_Conf_Int[3,11] ,R_0_9k.ST_Conf_Int[3,11] ,R_1_0k.ST_Conf_Int[3,11] ,R_1_2k.ST_Conf_Int[3,11] ,R_1_4k.ST_Conf_Int[3,11] ,R_1_6k.ST_Conf_Int[3,11] , R_1_8k.ST_Conf_Int[3,11] ,R_2_0k.ST_Conf_Int[3,11] ,R_2_3k.ST_Conf_Int[3,11] ,R_2_6k.ST_Conf_Int[3,11] ,R_2_9k.ST_Conf_Int[3,11] ,R_3_0k.ST_Conf_Int[3,11] ,R_3_5k.ST_Conf_Int[3,11] , R_4_0k.ST_Conf_Int[3,11] ,R_4_5k.ST_Conf_Int[3,11] ,R_5_0k.ST_Conf_Int[3,11] ,R_6_0k.ST_Conf_Int[3,11] ,R_7_0k.ST_Conf_Int[3,11] ,R_8_0k.ST_Conf_Int[3,11] ,R_9_0k.ST_Conf_Int[3,11] , R_10_0k.ST_Conf_Int[3,11],R_12_5k.ST_Conf_Int[3,11],R_15_0k.ST_Conf_Int[3,11],R_17_5k.ST_Conf_Int[3,11],R_20_0k.ST_Conf_Int[3,11],R_25_0k.ST_Conf_Int[3,11],R_30_0k.ST_Conf_Int[3,11], R_35_0k.ST_Conf_Int[3,11],R_40_0k.ST_Conf_Int[3,11],R_45_0k.ST_Conf_Int[3,11],  R_50_0k.ST_Conf_Int[3,11],  R_50_0k.ST_Conf_Int[3,11],  R_60_0k.ST_Conf_Int[3,11],  R_65_0k.ST_Conf_Int[3,11],  R_70_0k.ST_Conf_Int[3,11],  R_75_0k.ST_Conf_Int[3,11],  R_80_0k.ST_Conf_Int[3,11],  R_85_0k.ST_Conf_Int[3,11],  R_90_0k.ST_Conf_Int[3,11],  R_95_0k.ST_Conf_Int[3,11],  R_100_0k.ST_Conf_Int[3,11],  R_105_0k.ST_Conf_Int[3,11],  R_110_0k.ST_Conf_Int[3,11],  R_115_0k.ST_Conf_Int[3,11],  R_120_0k.ST_Conf_Int[3,11],  R_125_0k.ST_Conf_Int[3,11],  R_130_0k.ST_Conf_Int[3,11],  R_135_0k.ST_Conf_Int[3,11],  R_140_0k.ST_Conf_Int[3,11],  R_145_0k.ST_Conf_Int[3,11],  R_150_0k.ST_Conf_Int[3,11]]
        end
    
        # High and Low errors reg ST #
        # Cardiac Output
        LowE_CO_R_ST = CO_R_ST .- (1.96 .*CO_R_ST_E)
        HighE_CO_R_ST = CO_R_ST .+ (1.96 .*CO_R_ST_E)
        # Max PLV
        LowE_PLV_R_ST = PLV_R_ST .- (1.96 .*PLV_R_ST_E)
        HighE_PLV_R_ST = PLV_R_ST .+ (1.96 .*PLV_R_ST_E)
        # Max PSV
        LowE_PSV_R_ST = PSV_R_ST .- (1.96 .*PSV_R_ST_E)
        HighE_PSV_R_ST = PSV_R_ST .+ (1.96 .*PSV_R_ST_E)
    end 
    #CO ST R
    band!(x[1:end], min.(LowE_CO_R_ST, HighE_CO_R_ST), max.(LowE_CO_R_ST, HighE_CO_R_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_ST, label = "CO")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_R_ST, HighE_PLV_R_ST), max.(LowE_PLV_R_ST, HighE_PLV_R_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_ST, label = "PLV")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_R_ST, HighE_PSV_R_ST), max.(LowE_PSV_R_ST, HighE_PSV_R_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_ST, label = "PSV")
    hidexdecorations!(axk, grid = false)

    axl = Axis(gl[1,1], xlabel = L"\text{Sample~Size}", xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    #tau ST reg data
    begin
        ## load Reg data for CO PSV PLV ST ##
        begin
            CO_R_ST = [R_0_1k.ST[10,6], R_0_2k.ST[10,6],R_0_3k.ST[10,6] ,R_0_4k.ST[10,6] ,R_0_5k.ST[10,6] ,R_0_6k.ST[10,6] ,  R_0_7k.ST[10,6] ,R_0_8k.ST[10,6] ,R_0_9k.ST[10,6] ,R_1_0k.ST[10,6] ,R_1_2k.ST[10,6] ,R_1_4k.ST[10,6] ,R_1_6k.ST[10,6] ,  R_1_8k.ST[10,6] ,R_2_0k.ST[10,6] ,R_2_3k.ST[10,6] ,R_2_6k.ST[10,6] ,R_2_9k.ST[10,6] ,R_3_0k.ST[10,6] ,R_3_5k.ST[10,6] ,  R_4_0k.ST[10,6] ,R_4_5k.ST[10,6] ,R_5_0k.ST[10,6] ,R_6_0k.ST[10,6] ,R_7_0k.ST[10,6] ,R_8_0k.ST[10,6] ,R_9_0k.ST[10,6] ,  R_10_0k.ST[10,6],R_12_5k.ST[10,6],R_15_0k.ST[10,6],R_17_5k.ST[10,6],R_20_0k.ST[10,6],R_25_0k.ST[10,6],R_30_0k.ST[10,6],  R_35_0k.ST[10,6],R_40_0k.ST[10,6],R_45_0k.ST[10,6],  R_50_0k.ST[10,6],  R_50_0k.ST[10,6],  R_60_0k.ST[10,6],  R_65_0k.ST[10,6],  R_70_0k.ST[10,6],  R_75_0k.ST[10,6],  R_80_0k.ST[10,6],  R_85_0k.ST[10,6],  R_90_0k.ST[10,6],  R_95_0k.ST[10,6],  R_100_0k.ST[10,6],  R_105_0k.ST[10,6],  R_110_0k.ST[10,6],  R_115_0k.ST[10,6],  R_120_0k.ST[10,6],  R_125_0k.ST[10,6],  R_130_0k.ST[10,6],  R_135_0k.ST[10,6],  R_140_0k.ST[10,6],  R_145_0k.ST[10,6],  R_150_0k.ST[10,6]]
        
            PLV_R_ST = [R_0_1k.ST[1,6], R_0_2k.ST[1,6],R_0_3k.ST[1,6] ,R_0_4k.ST[1,6] ,R_0_5k.ST[1,6] ,R_0_6k.ST[1,6] , R_0_7k.ST[1,6] ,R_0_8k.ST[1,6] ,R_0_9k.ST[1,6] ,R_1_0k.ST[1,6] ,R_1_2k.ST[1,6] ,R_1_4k.ST[1,6] ,R_1_6k.ST[1,6] , R_1_8k.ST[1,6] ,R_2_0k.ST[1,6] ,R_2_3k.ST[1,6] ,R_2_6k.ST[1,6] ,R_2_9k.ST[1,6] ,R_3_0k.ST[1,6] ,R_3_5k.ST[1,6] , R_4_0k.ST[1,6] ,R_4_5k.ST[1,6] ,R_5_0k.ST[1,6] ,R_6_0k.ST[1,6] ,R_7_0k.ST[1,6] ,R_8_0k.ST[1,6] ,R_9_0k.ST[1,6] , R_10_0k.ST[1,6],R_12_5k.ST[1,6],R_15_0k.ST[1,6],R_17_5k.ST[1,6],R_20_0k.ST[1,6],R_25_0k.ST[1,6],R_30_0k.ST[1,6], R_35_0k.ST[1,6],R_40_0k.ST[1,6],R_45_0k.ST[1,6],  R_50_0k.ST[1,6],  R_50_0k.ST[1,6],  R_60_0k.ST[1,6],  R_65_0k.ST[1,6],  R_70_0k.ST[1,6],  R_75_0k.ST[1,6],  R_80_0k.ST[1,6],  R_85_0k.ST[1,6],  R_90_0k.ST[1,6],  R_95_0k.ST[1,6],  R_100_0k.ST[1,6],  R_105_0k.ST[1,6],  R_110_0k.ST[1,6],  R_115_0k.ST[1,6],  R_120_0k.ST[1,6],  R_125_0k.ST[1,6],  R_130_0k.ST[1,6],  R_135_0k.ST[1,6],  R_140_0k.ST[1,6],  R_145_0k.ST[1,6],  R_150_0k.ST[1,6]]
        
            PSV_R_ST = [R_0_1k.ST[3,6], R_0_2k.ST[3,6],R_0_3k.ST[3,6] ,R_0_4k.ST[3,6] ,R_0_5k.ST[3,6] ,R_0_6k.ST[3,6] , R_0_7k.ST[3,6] ,R_0_8k.ST[3,6] ,R_0_9k.ST[3,6] ,R_1_0k.ST[3,6] ,R_1_2k.ST[3,6] ,R_1_4k.ST[3,6] ,R_1_6k.ST[3,6] , R_1_8k.ST[3,6] ,R_2_0k.ST[3,6] ,R_2_3k.ST[3,6] ,R_2_6k.ST[3,6] ,R_2_9k.ST[3,6] ,R_3_0k.ST[3,6] ,R_3_5k.ST[3,6] , R_4_0k.ST[3,6] ,R_4_5k.ST[3,6] ,R_5_0k.ST[3,6] ,R_6_0k.ST[3,6] ,R_7_0k.ST[3,6] ,R_8_0k.ST[3,6] ,R_9_0k.ST[3,6] , R_10_0k.ST[3,6],R_12_5k.ST[3,6],R_15_0k.ST[3,6],R_17_5k.ST[3,6],R_20_0k.ST[3,6],R_25_0k.ST[3,6],R_30_0k.ST[3,6], R_35_0k.ST[3,6],R_40_0k.ST[3,6],R_45_0k.ST[3,6],  R_50_0k.ST[3,6],  R_50_0k.ST[3,6],  R_60_0k.ST[3,6],  R_65_0k.ST[3,6],  R_70_0k.ST[3,6],  R_75_0k.ST[3,6],  R_80_0k.ST[3,6],  R_85_0k.ST[3,6],  R_90_0k.ST[3,6],  R_95_0k.ST[3,6],  R_100_0k.ST[3,6],  R_105_0k.ST[3,6],  R_110_0k.ST[3,6],  R_115_0k.ST[3,6],  R_120_0k.ST[3,6],  R_125_0k.ST[3,6],  R_130_0k.ST[3,6],  R_135_0k.ST[3,6],  R_140_0k.ST[3,6],  R_145_0k.ST[3,6],  R_150_0k.ST[3,6]]
        end
    
        ## R errors for CO PSV PLV ST ##
        begin
            CO_R_ST_E = [R_0_1k.ST_Conf_Int[10,6], R_0_2k.ST_Conf_Int[10,6],R_0_3k.ST_Conf_Int[10,6] ,R_0_4k.ST_Conf_Int[10,6] ,R_0_5k.ST_Conf_Int[10,6] ,R_0_6k.ST_Conf_Int[10,6] ,  R_0_7k.ST_Conf_Int[10,6] ,R_0_8k.ST_Conf_Int[10,6] ,R_0_9k.ST_Conf_Int[10,6] ,R_1_0k.ST_Conf_Int[10,6] ,R_1_2k.ST_Conf_Int[10,6] ,R_1_4k.ST_Conf_Int[10,6] ,R_1_6k.ST_Conf_Int[10,6] ,  R_1_8k.ST_Conf_Int[10,6] ,R_2_0k.ST_Conf_Int[10,6] ,R_2_3k.ST_Conf_Int[10,6] ,R_2_6k.ST_Conf_Int[10,6] ,R_2_9k.ST_Conf_Int[10,6] ,R_3_0k.ST_Conf_Int[10,6] ,R_3_5k.ST_Conf_Int[10,6] ,  R_4_0k.ST_Conf_Int[10,6] ,R_4_5k.ST_Conf_Int[10,6] ,R_5_0k.ST_Conf_Int[10,6] ,R_6_0k.ST_Conf_Int[10,6] ,R_7_0k.ST_Conf_Int[10,6] ,R_8_0k.ST_Conf_Int[10,6] ,R_9_0k.ST_Conf_Int[10,6] ,  R_10_0k.ST_Conf_Int[10,6],R_12_5k.ST_Conf_Int[10,6],R_15_0k.ST_Conf_Int[10,6],R_17_5k.ST_Conf_Int[10,6],R_20_0k.ST_Conf_Int[10,6],R_25_0k.ST_Conf_Int[10,6],R_30_0k.ST_Conf_Int[10,6],  R_35_0k.ST_Conf_Int[10,6],R_40_0k.ST_Conf_Int[10,6],R_45_0k.ST_Conf_Int[10,6],  R_50_0k.ST_Conf_Int[10,6],  R_50_0k.ST_Conf_Int[10,6],  R_60_0k.ST_Conf_Int[10,6],  R_65_0k.ST_Conf_Int[10,6],  R_70_0k.ST_Conf_Int[10,6],  R_75_0k.ST_Conf_Int[10,6],  R_80_0k.ST_Conf_Int[10,6],  R_85_0k.ST_Conf_Int[10,6],  R_90_0k.ST_Conf_Int[10,6],  R_95_0k.ST_Conf_Int[10,6],  R_100_0k.ST_Conf_Int[10,6],  R_105_0k.ST_Conf_Int[10,6],  R_110_0k.ST_Conf_Int[10,6],  R_115_0k.ST_Conf_Int[10,6],  R_120_0k.ST_Conf_Int[10,6],  R_125_0k.ST_Conf_Int[10,6],  R_130_0k.ST_Conf_Int[10,6],  R_135_0k.ST_Conf_Int[10,6],  R_140_0k.ST_Conf_Int[10,6],  R_145_0k.ST_Conf_Int[10,6],  R_150_0k.ST_Conf_Int[10,6]]
        
            PLV_R_ST_E = [R_0_1k.ST_Conf_Int[1,6], R_0_2k.ST_Conf_Int[1,6],R_0_3k.ST_Conf_Int[1,6] ,R_0_4k.ST_Conf_Int[1,6] ,R_0_5k.ST_Conf_Int[1,6] ,R_0_6k.ST_Conf_Int[1,6] , R_0_7k.ST_Conf_Int[1,6] ,R_0_8k.ST_Conf_Int[1,6] ,R_0_9k.ST_Conf_Int[1,6] ,R_1_0k.ST_Conf_Int[1,6] ,R_1_2k.ST_Conf_Int[1,6] ,R_1_4k.ST_Conf_Int[1,6] ,R_1_6k.ST_Conf_Int[1,6] , R_1_8k.ST_Conf_Int[1,6] ,R_2_0k.ST_Conf_Int[1,6] ,R_2_3k.ST_Conf_Int[1,6] ,R_2_6k.ST_Conf_Int[1,6] ,R_2_9k.ST_Conf_Int[1,6] ,R_3_0k.ST_Conf_Int[1,6] ,R_3_5k.ST_Conf_Int[1,6] , R_4_0k.ST_Conf_Int[1,6] ,R_4_5k.ST_Conf_Int[1,6] ,R_5_0k.ST_Conf_Int[1,6] ,R_6_0k.ST_Conf_Int[1,6] ,R_7_0k.ST_Conf_Int[1,6] ,R_8_0k.ST_Conf_Int[1,6] ,R_9_0k.ST_Conf_Int[1,6] , R_10_0k.ST_Conf_Int[1,6],R_12_5k.ST_Conf_Int[1,6],R_15_0k.ST_Conf_Int[1,6],R_17_5k.ST_Conf_Int[1,6],R_20_0k.ST_Conf_Int[1,6],R_25_0k.ST_Conf_Int[1,6],R_30_0k.ST_Conf_Int[1,6], R_35_0k.ST_Conf_Int[1,6],R_40_0k.ST_Conf_Int[1,6],R_45_0k.ST_Conf_Int[1,6],  R_50_0k.ST_Conf_Int[1,6],  R_50_0k.ST_Conf_Int[1,6],  R_60_0k.ST_Conf_Int[1,6],  R_65_0k.ST_Conf_Int[1,6],  R_70_0k.ST_Conf_Int[1,6],  R_75_0k.ST_Conf_Int[1,6],  R_80_0k.ST_Conf_Int[1,6],  R_85_0k.ST_Conf_Int[1,6],  R_90_0k.ST_Conf_Int[1,6],  R_95_0k.ST_Conf_Int[1,6],  R_100_0k.ST_Conf_Int[1,6],  R_105_0k.ST_Conf_Int[1,6],  R_110_0k.ST_Conf_Int[1,6],  R_115_0k.ST_Conf_Int[1,6],  R_120_0k.ST_Conf_Int[1,6],  R_125_0k.ST_Conf_Int[1,6],  R_130_0k.ST_Conf_Int[1,6],  R_135_0k.ST_Conf_Int[1,6],  R_140_0k.ST_Conf_Int[1,6],  R_145_0k.ST_Conf_Int[1,6],  R_150_0k.ST_Conf_Int[1,6]]
        
            PSV_R_ST_E = [R_0_1k.ST_Conf_Int[3,6], R_0_2k.ST_Conf_Int[3,6],R_0_3k.ST_Conf_Int[3,6] ,R_0_4k.ST_Conf_Int[3,6] ,R_0_5k.ST_Conf_Int[3,6] ,R_0_6k.ST_Conf_Int[3,6] , R_0_7k.ST_Conf_Int[3,6] ,R_0_8k.ST_Conf_Int[3,6] ,R_0_9k.ST_Conf_Int[3,6] ,R_1_0k.ST_Conf_Int[3,6] ,R_1_2k.ST_Conf_Int[3,6] ,R_1_4k.ST_Conf_Int[3,6] ,R_1_6k.ST_Conf_Int[3,6] , R_1_8k.ST_Conf_Int[3,6] ,R_2_0k.ST_Conf_Int[3,6] ,R_2_3k.ST_Conf_Int[3,6] ,R_2_6k.ST_Conf_Int[3,6] ,R_2_9k.ST_Conf_Int[3,6] ,R_3_0k.ST_Conf_Int[3,6] ,R_3_5k.ST_Conf_Int[3,6] , R_4_0k.ST_Conf_Int[3,6] ,R_4_5k.ST_Conf_Int[3,6] ,R_5_0k.ST_Conf_Int[3,6] ,R_6_0k.ST_Conf_Int[3,6] ,R_7_0k.ST_Conf_Int[3,6] ,R_8_0k.ST_Conf_Int[3,6] ,R_9_0k.ST_Conf_Int[3,6] , R_10_0k.ST_Conf_Int[3,6],R_12_5k.ST_Conf_Int[3,6],R_15_0k.ST_Conf_Int[3,6],R_17_5k.ST_Conf_Int[3,6],R_20_0k.ST_Conf_Int[3,6],R_25_0k.ST_Conf_Int[3,6],R_30_0k.ST_Conf_Int[3,6], R_35_0k.ST_Conf_Int[3,6],R_40_0k.ST_Conf_Int[3,6],R_45_0k.ST_Conf_Int[3,6],  R_50_0k.ST_Conf_Int[3,6],  R_50_0k.ST_Conf_Int[3,6],  R_60_0k.ST_Conf_Int[3,6],  R_65_0k.ST_Conf_Int[3,6],  R_70_0k.ST_Conf_Int[3,6],  R_75_0k.ST_Conf_Int[3,6],  R_80_0k.ST_Conf_Int[3,6],  R_85_0k.ST_Conf_Int[3,6],  R_90_0k.ST_Conf_Int[3,6],  R_95_0k.ST_Conf_Int[3,6],  R_100_0k.ST_Conf_Int[3,6],  R_105_0k.ST_Conf_Int[3,6],  R_110_0k.ST_Conf_Int[3,6],  R_115_0k.ST_Conf_Int[3,6],  R_120_0k.ST_Conf_Int[3,6],  R_125_0k.ST_Conf_Int[3,6],  R_130_0k.ST_Conf_Int[3,6],  R_135_0k.ST_Conf_Int[3,6],  R_140_0k.ST_Conf_Int[3,6],  R_145_0k.ST_Conf_Int[3,6],  R_150_0k.ST_Conf_Int[3,6]]
        end
    
        # High and Low errors reg ST #
        # Cardiac Output
        LowE_CO_R_ST = CO_R_ST .- (1.96 .*CO_R_ST_E)
        HighE_CO_R_ST = CO_R_ST .+ (1.96 .*CO_R_ST_E)
        # Max PLV
        LowE_PLV_R_ST = PLV_R_ST .- (1.96 .*PLV_R_ST_E)
        HighE_PLV_R_ST = PLV_R_ST .+ (1.96 .*PLV_R_ST_E)
        # Max PSV
        LowE_PSV_R_ST = PSV_R_ST .- (1.96 .*PSV_R_ST_E)
        HighE_PSV_R_ST = PSV_R_ST .+ (1.96 .*PSV_R_ST_E)
    end 
    #CO ST R
    band!(x[1:end], min.(LowE_CO_R_ST, HighE_CO_R_ST), max.(LowE_CO_R_ST, HighE_CO_R_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_R_ST, label = "CO")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_R_ST, HighE_PLV_R_ST), max.(LowE_PLV_R_ST, HighE_PLV_R_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_R_ST, label = "PLV")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_R_ST, HighE_PSV_R_ST), max.(LowE_PSV_R_ST, HighE_PSV_R_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_R_ST, label = "PSV")
    #hideydecorations!(axl, grid = false)

    axm = Axis(gm[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    Label(gm[1, 1, Top()], L"S_{1}~\text{Fixed}~\text{HR}", valign = :center, font = :bold, padding = (0, 0, 0, 0))
    # Rs S1 fixed HR
    begin
        ## load No HR data for CO PSV PLV S1 ##
        begin
            CO_HR_S1 = [HR_0_1k.S1[9,5], HR_0_2k.S1[9,5],HR_0_3k.S1[9,5] ,HR_0_4k.S1[9,5] ,HR_0_5k.S1[9,5] ,HR_0_6k.S1[9,5] ,  HR_0_7k.S1[9,5] ,HR_0_8k.S1[9,5] ,HR_0_9k.S1[9,5] ,HR_1_0k.S1[9,5] ,HR_1_2k.S1[9,5] ,HR_1_4k.S1[9,5] ,HR_1_6k.S1[9,5] ,  HR_1_8k.S1[9,5] ,HR_2_0k.S1[9,5] ,HR_2_3k.S1[9,5] ,HR_2_6k.S1[9,5] ,HR_2_9k.S1[9,5] ,HR_3_0k.S1[9,5] ,HR_3_5k.S1[9,5] ,  HR_4_0k.S1[9,5] ,HR_4_5k.S1[9,5] ,HR_5_0k.S1[9,5] ,HR_6_0k.S1[9,5] ,HR_7_0k.S1[9,5] ,HR_8_0k.S1[9,5] ,HR_9_0k.S1[9,5] ,  HR_10_0k.S1[9,5],HR_12_5k.S1[9,5],HR_15_0k.S1[9,5],HR_17_5k.S1[9,5],HR_20_0k.S1[9,5],HR_25_0k.S1[9,5],HR_30_0k.S1[9,5],  HR_35_0k.S1[9,5],HR_40_0k.S1[9,5],HR_45_0k.S1[9,5],  HR_50_0k.S1[9,5],  HR_55_0k.S1[9,5],  HR_60_0k.S1[9,5],  HR_65_0k.S1[9,5],  HR_70_0k.S1[9,5],  HR_75_0k.S1[9,5],  HR_80_0k.S1[9,5],  HR_85_0k.S1[9,5],  HR_90_0k.S1[9,5],  HR_95_0k.S1[9,5],  HR_100_0k.S1[9,5],  HR_105_0k.S1[9,5],  HR_110_0k.S1[9,5],  HR_115_0k.S1[9,5],  HR_120_0k.S1[9,5],  HR_125_0k.S1[9,5],  HR_130_0k.S1[9,5],  HR_135_0k.S1[9,5],  HR_140_0k.S1[9,5],  HR_145_0k.S1[9,5],  HR_150_0k.S1[9,5]]
        
            PLV_HR_S1 = [HR_0_1k.S1[1,5], HR_0_2k.S1[1,5],HR_0_3k.S1[1,5] ,HR_0_4k.S1[1,5] ,HR_0_5k.S1[1,5] ,HR_0_6k.S1[1,5] , HR_0_7k.S1[1,5] ,HR_0_8k.S1[1,5] ,HR_0_9k.S1[1,5] ,HR_1_0k.S1[1,5] ,HR_1_2k.S1[1,5] ,HR_1_4k.S1[1,5] ,HR_1_6k.S1[1,5] , HR_1_8k.S1[1,5] ,HR_2_0k.S1[1,5] ,HR_2_3k.S1[1,5] ,HR_2_6k.S1[1,5] ,HR_2_9k.S1[1,5] ,HR_3_0k.S1[1,5] ,HR_3_5k.S1[1,5] , HR_4_0k.S1[1,5] ,HR_4_5k.S1[1,5] ,HR_5_0k.S1[1,5] ,HR_6_0k.S1[1,5] ,HR_7_0k.S1[1,5] ,HR_8_0k.S1[1,5] ,HR_9_0k.S1[1,5] , HR_10_0k.S1[1,5],HR_12_5k.S1[1,5],HR_15_0k.S1[1,5],HR_17_5k.S1[1,5],HR_20_0k.S1[1,5],HR_25_0k.S1[1,5],HR_30_0k.S1[1,5], HR_35_0k.S1[1,5],HR_40_0k.S1[1,5],HR_45_0k.S1[1,5],  HR_50_0k.S1[1,5],  HR_55_0k.S1[1,5],  HR_60_0k.S1[1,5],  HR_65_0k.S1[1,5],  HR_70_0k.S1[1,5],  HR_75_0k.S1[1,5],  HR_80_0k.S1[1,5],  HR_85_0k.S1[1,5],  HR_90_0k.S1[1,5],  HR_95_0k.S1[1,5],  HR_100_0k.S1[1,5],  HR_105_0k.S1[1,5],  HR_110_0k.S1[1,5],  HR_115_0k.S1[1,5],  HR_120_0k.S1[1,5],  HR_125_0k.S1[1,5],  HR_130_0k.S1[1,5],  HR_135_0k.S1[1,5],  HR_140_0k.S1[1,5],  HR_145_0k.S1[1,5],  HR_150_0k.S1[1,5]]
        
            PSV_HR_S1 = [HR_0_1k.S1[3,5], HR_0_2k.S1[3,5],HR_0_3k.S1[3,5] ,HR_0_4k.S1[3,5] ,HR_0_5k.S1[3,5] ,HR_0_6k.S1[3,5] , HR_0_7k.S1[3,5] ,HR_0_8k.S1[3,5] ,HR_0_9k.S1[3,5] ,HR_1_0k.S1[3,5] ,HR_1_2k.S1[3,5] ,HR_1_4k.S1[3,5] ,HR_1_6k.S1[3,5] , HR_1_8k.S1[3,5] ,HR_2_0k.S1[3,5] ,HR_2_3k.S1[3,5] ,HR_2_6k.S1[3,5] ,HR_2_9k.S1[3,5] ,HR_3_0k.S1[3,5] ,HR_3_5k.S1[3,5] , HR_4_0k.S1[3,5] ,HR_4_5k.S1[3,5] ,HR_5_0k.S1[3,5] ,HR_6_0k.S1[3,5] ,HR_7_0k.S1[3,5] ,HR_8_0k.S1[3,5] ,HR_9_0k.S1[3,5] , HR_10_0k.S1[3,5],HR_12_5k.S1[3,5],HR_15_0k.S1[3,5],HR_17_5k.S1[3,5],HR_20_0k.S1[3,5],HR_25_0k.S1[3,5],HR_30_0k.S1[3,5], HR_35_0k.S1[3,5],HR_40_0k.S1[3,5],HR_45_0k.S1[3,5],  HR_50_0k.S1[3,5],  HR_55_0k.S1[3,5],  HR_60_0k.S1[3,5],  HR_65_0k.S1[3,5],  HR_70_0k.S1[3,5],  HR_75_0k.S1[3,5],  HR_80_0k.S1[3,5],  HR_85_0k.S1[3,5],  HR_90_0k.S1[3,5],  HR_95_0k.S1[3,5],  HR_100_0k.S1[3,5],  HR_105_0k.S1[3,5],  HR_110_0k.S1[3,5],  HR_115_0k.S1[3,5],  HR_120_0k.S1[3,5],  HR_125_0k.S1[3,5],  HR_130_0k.S1[3,5],  HR_135_0k.S1[3,5],  HR_140_0k.S1[3,5],  HR_145_0k.S1[3,5],  HR_150_0k.S1[3,5]]
        end

        ## No HR errors for CO PSV PLV S1 ##
        begin
            CO_HR_S1_E = [HR_0_1k.S1_Conf_Int[9,5], HR_0_2k.S1_Conf_Int[9,5],HR_0_3k.S1_Conf_Int[9,5] ,HR_0_4k.S1_Conf_Int[9,5] ,HR_0_5k.S1_Conf_Int[9,5] ,HR_0_6k.S1_Conf_Int[9,5] ,  HR_0_7k.S1_Conf_Int[9,5] ,HR_0_8k.S1_Conf_Int[9,5] ,HR_0_9k.S1_Conf_Int[9,5] ,HR_1_0k.S1_Conf_Int[9,5] ,HR_1_2k.S1_Conf_Int[9,5] ,HR_1_4k.S1_Conf_Int[9,5] ,HR_1_6k.S1_Conf_Int[9,5] ,  HR_1_8k.S1_Conf_Int[9,5] ,HR_2_0k.S1_Conf_Int[9,5] ,HR_2_3k.S1_Conf_Int[9,5] ,HR_2_6k.S1_Conf_Int[9,5] ,HR_2_9k.S1_Conf_Int[9,5] ,HR_3_0k.S1_Conf_Int[9,5] ,HR_3_5k.S1_Conf_Int[9,5] ,  HR_4_0k.S1_Conf_Int[9,5] ,HR_4_5k.S1_Conf_Int[9,5] ,HR_5_0k.S1_Conf_Int[9,5] ,HR_6_0k.S1_Conf_Int[9,5] ,HR_7_0k.S1_Conf_Int[9,5] ,HR_8_0k.S1_Conf_Int[9,5] ,HR_9_0k.S1_Conf_Int[9,5] ,  HR_10_0k.S1_Conf_Int[9,5],HR_12_5k.S1_Conf_Int[9,5],HR_15_0k.S1_Conf_Int[9,5],HR_17_5k.S1_Conf_Int[9,5],HR_20_0k.S1_Conf_Int[9,5],HR_25_0k.S1_Conf_Int[9,5],HR_30_0k.S1_Conf_Int[9,5],  HR_35_0k.S1_Conf_Int[9,5],HR_40_0k.S1_Conf_Int[9,5],HR_45_0k.S1_Conf_Int[9,5],  HR_50_0k.S1_Conf_Int[9,5],  HR_55_0k.S1_Conf_Int[9,5],  HR_60_0k.S1_Conf_Int[9,5],  HR_65_0k.S1_Conf_Int[9,5],  HR_70_0k.S1_Conf_Int[9,5],  HR_75_0k.S1_Conf_Int[9,5],  HR_80_0k.S1_Conf_Int[9,5],  HR_85_0k.S1_Conf_Int[9,5],  HR_90_0k.S1_Conf_Int[9,5],  HR_95_0k.S1_Conf_Int[9,5],  HR_100_0k.S1_Conf_Int[9,5],  HR_105_0k.S1_Conf_Int[9,5],  HR_110_0k.S1_Conf_Int[9,5],  HR_115_0k.S1_Conf_Int[9,5],  HR_120_0k.S1_Conf_Int[9,5],  HR_125_0k.S1_Conf_Int[9,5],  HR_130_0k.S1_Conf_Int[9,5],  HR_135_0k.S1_Conf_Int[9,5],  HR_140_0k.S1_Conf_Int[9,5],  HR_145_0k.S1_Conf_Int[9,5],  HR_150_0k.S1_Conf_Int[9,5]]
        
            PLV_HR_S1_E = [HR_0_1k.S1_Conf_Int[1,5], HR_0_2k.S1_Conf_Int[1,5],HR_0_3k.S1_Conf_Int[1,5] ,HR_0_4k.S1_Conf_Int[1,5] ,HR_0_5k.S1_Conf_Int[1,5] ,HR_0_6k.S1_Conf_Int[1,5] , HR_0_7k.S1_Conf_Int[1,5] ,HR_0_8k.S1_Conf_Int[1,5] ,HR_0_9k.S1_Conf_Int[1,5] ,HR_1_0k.S1_Conf_Int[1,5] ,HR_1_2k.S1_Conf_Int[1,5] ,HR_1_4k.S1_Conf_Int[1,5] ,HR_1_6k.S1_Conf_Int[1,5] , HR_1_8k.S1_Conf_Int[1,5] ,HR_2_0k.S1_Conf_Int[1,5] ,HR_2_3k.S1_Conf_Int[1,5] ,HR_2_6k.S1_Conf_Int[1,5] ,HR_2_9k.S1_Conf_Int[1,5] ,HR_3_0k.S1_Conf_Int[1,5] ,HR_3_5k.S1_Conf_Int[1,5] , HR_4_0k.S1_Conf_Int[1,5] ,HR_4_5k.S1_Conf_Int[1,5] ,HR_5_0k.S1_Conf_Int[1,5] ,HR_6_0k.S1_Conf_Int[1,5] ,HR_7_0k.S1_Conf_Int[1,5] ,HR_8_0k.S1_Conf_Int[1,5] ,HR_9_0k.S1_Conf_Int[1,5] , HR_10_0k.S1_Conf_Int[1,5],HR_12_5k.S1_Conf_Int[1,5],HR_15_0k.S1_Conf_Int[1,5],HR_17_5k.S1_Conf_Int[1,5],HR_20_0k.S1_Conf_Int[1,5],HR_25_0k.S1_Conf_Int[1,5],HR_30_0k.S1_Conf_Int[1,5], HR_35_0k.S1_Conf_Int[1,5],HR_40_0k.S1_Conf_Int[1,5],HR_45_0k.S1_Conf_Int[1,5],  HR_50_0k.S1_Conf_Int[1,5],  HR_55_0k.S1_Conf_Int[1,5],  HR_60_0k.S1_Conf_Int[1,5],  HR_65_0k.S1_Conf_Int[1,5],  HR_70_0k.S1_Conf_Int[1,5],  HR_75_0k.S1_Conf_Int[1,5],  HR_80_0k.S1_Conf_Int[1,5],  HR_85_0k.S1_Conf_Int[1,5],  HR_90_0k.S1_Conf_Int[1,5],  HR_95_0k.S1_Conf_Int[1,5],  HR_100_0k.S1_Conf_Int[1,5],  HR_105_0k.S1_Conf_Int[1,5],  HR_110_0k.S1_Conf_Int[1,5],  HR_115_0k.S1_Conf_Int[1,5],  HR_120_0k.S1_Conf_Int[1,5],  HR_125_0k.S1_Conf_Int[1,5],  HR_130_0k.S1_Conf_Int[1,5],  HR_135_0k.S1_Conf_Int[1,5],  HR_140_0k.S1_Conf_Int[1,5],  HR_145_0k.S1_Conf_Int[1,5],  HR_150_0k.S1_Conf_Int[1,5]]
        
            PSV_HR_S1_E = [HR_0_1k.S1_Conf_Int[3,5], HR_0_2k.S1_Conf_Int[3,5],HR_0_3k.S1_Conf_Int[3,5] ,HR_0_4k.S1_Conf_Int[3,5] ,HR_0_5k.S1_Conf_Int[3,5] ,HR_0_6k.S1_Conf_Int[3,5] , HR_0_7k.S1_Conf_Int[3,5] ,HR_0_8k.S1_Conf_Int[3,5] ,HR_0_9k.S1_Conf_Int[3,5] ,HR_1_0k.S1_Conf_Int[3,5] ,HR_1_2k.S1_Conf_Int[3,5] ,HR_1_4k.S1_Conf_Int[3,5] ,HR_1_6k.S1_Conf_Int[3,5] , HR_1_8k.S1_Conf_Int[3,5] ,HR_2_0k.S1_Conf_Int[3,5] ,HR_2_3k.S1_Conf_Int[3,5] ,HR_2_6k.S1_Conf_Int[3,5] ,HR_2_9k.S1_Conf_Int[3,5] ,HR_3_0k.S1_Conf_Int[3,5] ,HR_3_5k.S1_Conf_Int[3,5] , HR_4_0k.S1_Conf_Int[3,5] ,HR_4_5k.S1_Conf_Int[3,5] ,HR_5_0k.S1_Conf_Int[3,5] ,HR_6_0k.S1_Conf_Int[3,5] ,HR_7_0k.S1_Conf_Int[3,5] ,HR_8_0k.S1_Conf_Int[3,5] ,HR_9_0k.S1_Conf_Int[3,5] , HR_10_0k.S1_Conf_Int[3,5],HR_12_5k.S1_Conf_Int[3,5],HR_15_0k.S1_Conf_Int[3,5],HR_17_5k.S1_Conf_Int[3,5],HR_20_0k.S1_Conf_Int[3,5],HR_25_0k.S1_Conf_Int[3,5],HR_30_0k.S1_Conf_Int[3,5], HR_35_0k.S1_Conf_Int[3,5],HR_40_0k.S1_Conf_Int[3,5],HR_45_0k.S1_Conf_Int[3,5],  HR_50_0k.S1_Conf_Int[3,5],  HR_55_0k.S1_Conf_Int[3,5],  HR_60_0k.S1_Conf_Int[3,5],  HR_65_0k.S1_Conf_Int[3,5],  HR_70_0k.S1_Conf_Int[3,5],  HR_75_0k.S1_Conf_Int[3,5],  HR_80_0k.S1_Conf_Int[3,5],  HR_85_0k.S1_Conf_Int[3,5],  HR_90_0k.S1_Conf_Int[3,5],  HR_95_0k.S1_Conf_Int[3,5],  HR_100_0k.S1_Conf_Int[3,5],  HR_105_0k.S1_Conf_Int[3,5],  HR_110_0k.S1_Conf_Int[3,5],  HR_115_0k.S1_Conf_Int[3,5],  HR_120_0k.S1_Conf_Int[3,5],  HR_125_0k.S1_Conf_Int[3,5],  HR_130_0k.S1_Conf_Int[3,5],  HR_135_0k.S1_Conf_Int[3,5],  HR_140_0k.S1_Conf_Int[3,5],  HR_145_0k.S1_Conf_Int[3,5],  HR_150_0k.S1_Conf_Int[3,5]]
        end

        # High and Low errors No HR S1 #
        # Cardiac Output
        LowE_CO_HR_S1 = CO_HR_S1 .- (1.96 .*CO_HR_S1_E)
        HighE_CO_HR_S1 = CO_HR_S1 .+ (1.96 .*CO_HR_S1_E)
        # Max PLV
        LowE_PLV_HR_S1 = PLV_HR_S1 .- (1.96 .*PLV_HR_S1_E)
        HighE_PLV_HR_S1 = PLV_HR_S1 .+ (1.96 .*PLV_HR_S1_E)
        # Max PSV
        LowE_PSV_HR_S1 = PSV_HR_S1 .- (1.96 .*PSV_HR_S1_E)
        HighE_PSV_HR_S1 = PSV_HR_S1 .+ (1.96 .*PSV_HR_S1_E)
    end
    #CO S1 R
    band!(x[1:end], min.(LowE_CO_HR_S1, HighE_CO_HR_S1), max.(LowE_CO_HR_S1, HighE_CO_HR_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_HR_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_HR_S1, HighE_PLV_HR_S1), max.(LowE_PLV_HR_S1, HighE_PLV_HR_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_HR_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_HR_S1, HighE_PSV_HR_S1), max.(LowE_PSV_HR_S1, HighE_PSV_HR_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_HR_S1, label = "PSV")
    hidexdecorations!(axm, grid = false)

    axn = Axis(gn[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    # Emax S1 fixed HR
    begin
        ## load No HR data for CO PSV PLV S1 ##
        begin
            CO_HR_S1 = [HR_0_1k.S1[9,8], HR_0_2k.S1[9,8],HR_0_3k.S1[9,8] ,HR_0_4k.S1[9,8] ,HR_0_5k.S1[9,8] ,HR_0_6k.S1[9,8] ,  HR_0_7k.S1[9,8] ,HR_0_8k.S1[9,8] ,HR_0_9k.S1[9,8] ,HR_1_0k.S1[9,8] ,HR_1_2k.S1[9,8] ,HR_1_4k.S1[9,8] ,HR_1_6k.S1[9,8] ,  HR_1_8k.S1[9,8] ,HR_2_0k.S1[9,8] ,HR_2_3k.S1[9,8] ,HR_2_6k.S1[9,8] ,HR_2_9k.S1[9,8] ,HR_3_0k.S1[9,8] ,HR_3_5k.S1[9,8] ,  HR_4_0k.S1[9,8] ,HR_4_5k.S1[9,8] ,HR_5_0k.S1[9,8] ,HR_6_0k.S1[9,8] ,HR_7_0k.S1[9,8] ,HR_8_0k.S1[9,8] ,HR_9_0k.S1[9,8] ,  HR_10_0k.S1[9,8],HR_12_5k.S1[9,8],HR_15_0k.S1[9,8],HR_17_5k.S1[9,8],HR_20_0k.S1[9,8],HR_25_0k.S1[9,8],HR_30_0k.S1[9,8],  HR_35_0k.S1[9,8],HR_40_0k.S1[9,8],HR_45_0k.S1[9,8],  HR_50_0k.S1[9,8],  HR_55_0k.S1[9,8],  HR_60_0k.S1[9,8],  HR_65_0k.S1[9,8],  HR_70_0k.S1[9,8],  HR_75_0k.S1[9,8],  HR_80_0k.S1[9,8],  HR_85_0k.S1[9,8],  HR_90_0k.S1[9,8],  HR_95_0k.S1[9,8],  HR_100_0k.S1[9,8],  HR_105_0k.S1[9,8],  HR_110_0k.S1[9,8],  HR_115_0k.S1[9,8],  HR_120_0k.S1[9,8],  HR_125_0k.S1[9,8],  HR_130_0k.S1[9,8],  HR_135_0k.S1[9,8],  HR_140_0k.S1[9,8],  HR_145_0k.S1[9,8],  HR_150_0k.S1[9,8]]
        
            PLV_HR_S1 = [HR_0_1k.S1[1,8], HR_0_2k.S1[1,8],HR_0_3k.S1[1,8] ,HR_0_4k.S1[1,8] ,HR_0_5k.S1[1,8] ,HR_0_6k.S1[1,8] , HR_0_7k.S1[1,8] ,HR_0_8k.S1[1,8] ,HR_0_9k.S1[1,8] ,HR_1_0k.S1[1,8] ,HR_1_2k.S1[1,8] ,HR_1_4k.S1[1,8] ,HR_1_6k.S1[1,8] , HR_1_8k.S1[1,8] ,HR_2_0k.S1[1,8] ,HR_2_3k.S1[1,8] ,HR_2_6k.S1[1,8] ,HR_2_9k.S1[1,8] ,HR_3_0k.S1[1,8] ,HR_3_5k.S1[1,8] , HR_4_0k.S1[1,8] ,HR_4_5k.S1[1,8] ,HR_5_0k.S1[1,8] ,HR_6_0k.S1[1,8] ,HR_7_0k.S1[1,8] ,HR_8_0k.S1[1,8] ,HR_9_0k.S1[1,8] , HR_10_0k.S1[1,8],HR_12_5k.S1[1,8],HR_15_0k.S1[1,8],HR_17_5k.S1[1,8],HR_20_0k.S1[1,8],HR_25_0k.S1[1,8],HR_30_0k.S1[1,8], HR_35_0k.S1[1,8],HR_40_0k.S1[1,8],HR_45_0k.S1[1,8],  HR_50_0k.S1[1,8],  HR_55_0k.S1[1,8],  HR_60_0k.S1[1,8],  HR_65_0k.S1[1,8],  HR_70_0k.S1[1,8],  HR_75_0k.S1[1,8],  HR_80_0k.S1[1,8],  HR_85_0k.S1[1,8],  HR_90_0k.S1[1,8],  HR_95_0k.S1[1,8],  HR_100_0k.S1[1,8],  HR_105_0k.S1[1,8],  HR_110_0k.S1[1,8],  HR_115_0k.S1[1,8],  HR_120_0k.S1[1,8],  HR_125_0k.S1[1,8],  HR_130_0k.S1[1,8],  HR_135_0k.S1[1,8],  HR_140_0k.S1[1,8],  HR_145_0k.S1[1,8],  HR_150_0k.S1[1,8]]
        
            PSV_HR_S1 = [HR_0_1k.S1[3,8], HR_0_2k.S1[3,8],HR_0_3k.S1[3,8] ,HR_0_4k.S1[3,8] ,HR_0_5k.S1[3,8] ,HR_0_6k.S1[3,8] , HR_0_7k.S1[3,8] ,HR_0_8k.S1[3,8] ,HR_0_9k.S1[3,8] ,HR_1_0k.S1[3,8] ,HR_1_2k.S1[3,8] ,HR_1_4k.S1[3,8] ,HR_1_6k.S1[3,8] , HR_1_8k.S1[3,8] ,HR_2_0k.S1[3,8] ,HR_2_3k.S1[3,8] ,HR_2_6k.S1[3,8] ,HR_2_9k.S1[3,8] ,HR_3_0k.S1[3,8] ,HR_3_5k.S1[3,8] , HR_4_0k.S1[3,8] ,HR_4_5k.S1[3,8] ,HR_5_0k.S1[3,8] ,HR_6_0k.S1[3,8] ,HR_7_0k.S1[3,8] ,HR_8_0k.S1[3,8] ,HR_9_0k.S1[3,8] , HR_10_0k.S1[3,8],HR_12_5k.S1[3,8],HR_15_0k.S1[3,8],HR_17_5k.S1[3,8],HR_20_0k.S1[3,8],HR_25_0k.S1[3,8],HR_30_0k.S1[3,8], HR_35_0k.S1[3,8],HR_40_0k.S1[3,8],HR_45_0k.S1[3,8],  HR_50_0k.S1[3,8],  HR_55_0k.S1[3,8],  HR_60_0k.S1[3,8],  HR_65_0k.S1[3,8],  HR_70_0k.S1[3,8],  HR_75_0k.S1[3,8],  HR_80_0k.S1[3,8],  HR_85_0k.S1[3,8],  HR_90_0k.S1[3,8],  HR_95_0k.S1[3,8],  HR_100_0k.S1[3,8],  HR_105_0k.S1[3,8],  HR_110_0k.S1[3,8],  HR_115_0k.S1[3,8],  HR_120_0k.S1[3,8],  HR_125_0k.S1[3,8],  HR_130_0k.S1[3,8],  HR_135_0k.S1[3,8],  HR_140_0k.S1[3,8],  HR_145_0k.S1[3,8],  HR_150_0k.S1[3,8]]
        end

        ## No HR errors for CO PSV PLV S1 ##
        begin
            CO_HR_S1_E = [HR_0_1k.S1_Conf_Int[9,8], HR_0_2k.S1_Conf_Int[9,8],HR_0_3k.S1_Conf_Int[9,8] ,HR_0_4k.S1_Conf_Int[9,8] ,HR_0_5k.S1_Conf_Int[9,8] ,HR_0_6k.S1_Conf_Int[9,8] ,  HR_0_7k.S1_Conf_Int[9,8] ,HR_0_8k.S1_Conf_Int[9,8] ,HR_0_9k.S1_Conf_Int[9,8] ,HR_1_0k.S1_Conf_Int[9,8] ,HR_1_2k.S1_Conf_Int[9,8] ,HR_1_4k.S1_Conf_Int[9,8] ,HR_1_6k.S1_Conf_Int[9,8] ,  HR_1_8k.S1_Conf_Int[9,8] ,HR_2_0k.S1_Conf_Int[9,8] ,HR_2_3k.S1_Conf_Int[9,8] ,HR_2_6k.S1_Conf_Int[9,8] ,HR_2_9k.S1_Conf_Int[9,8] ,HR_3_0k.S1_Conf_Int[9,8] ,HR_3_5k.S1_Conf_Int[9,8] ,  HR_4_0k.S1_Conf_Int[9,8] ,HR_4_5k.S1_Conf_Int[9,8] ,HR_5_0k.S1_Conf_Int[9,8] ,HR_6_0k.S1_Conf_Int[9,8] ,HR_7_0k.S1_Conf_Int[9,8] ,HR_8_0k.S1_Conf_Int[9,8] ,HR_9_0k.S1_Conf_Int[9,8] ,  HR_10_0k.S1_Conf_Int[9,8],HR_12_5k.S1_Conf_Int[9,8],HR_15_0k.S1_Conf_Int[9,8],HR_17_5k.S1_Conf_Int[9,8],HR_20_0k.S1_Conf_Int[9,8],HR_25_0k.S1_Conf_Int[9,8],HR_30_0k.S1_Conf_Int[9,8],  HR_35_0k.S1_Conf_Int[9,8],HR_40_0k.S1_Conf_Int[9,8],HR_45_0k.S1_Conf_Int[9,8],  HR_50_0k.S1_Conf_Int[9,8],  HR_55_0k.S1_Conf_Int[9,8],  HR_60_0k.S1_Conf_Int[9,8],  HR_65_0k.S1_Conf_Int[9,8],  HR_70_0k.S1_Conf_Int[9,8],  HR_75_0k.S1_Conf_Int[9,8],  HR_80_0k.S1_Conf_Int[9,8],  HR_85_0k.S1_Conf_Int[9,8],  HR_90_0k.S1_Conf_Int[9,8],  HR_95_0k.S1_Conf_Int[9,8],  HR_100_0k.S1_Conf_Int[9,8],  HR_105_0k.S1_Conf_Int[9,8],  HR_110_0k.S1_Conf_Int[9,8],  HR_115_0k.S1_Conf_Int[9,8],  HR_120_0k.S1_Conf_Int[9,8],  HR_125_0k.S1_Conf_Int[9,8],  HR_130_0k.S1_Conf_Int[9,8],  HR_135_0k.S1_Conf_Int[9,8],  HR_140_0k.S1_Conf_Int[9,8],  HR_145_0k.S1_Conf_Int[9,8],  HR_150_0k.S1_Conf_Int[9,8]]
        
            PLV_HR_S1_E = [HR_0_1k.S1_Conf_Int[1,8], HR_0_2k.S1_Conf_Int[1,8],HR_0_3k.S1_Conf_Int[1,8] ,HR_0_4k.S1_Conf_Int[1,8] ,HR_0_5k.S1_Conf_Int[1,8] ,HR_0_6k.S1_Conf_Int[1,8] , HR_0_7k.S1_Conf_Int[1,8] ,HR_0_8k.S1_Conf_Int[1,8] ,HR_0_9k.S1_Conf_Int[1,8] ,HR_1_0k.S1_Conf_Int[1,8] ,HR_1_2k.S1_Conf_Int[1,8] ,HR_1_4k.S1_Conf_Int[1,8] ,HR_1_6k.S1_Conf_Int[1,8] , HR_1_8k.S1_Conf_Int[1,8] ,HR_2_0k.S1_Conf_Int[1,8] ,HR_2_3k.S1_Conf_Int[1,8] ,HR_2_6k.S1_Conf_Int[1,8] ,HR_2_9k.S1_Conf_Int[1,8] ,HR_3_0k.S1_Conf_Int[1,8] ,HR_3_5k.S1_Conf_Int[1,8] , HR_4_0k.S1_Conf_Int[1,8] ,HR_4_5k.S1_Conf_Int[1,8] ,HR_5_0k.S1_Conf_Int[1,8] ,HR_6_0k.S1_Conf_Int[1,8] ,HR_7_0k.S1_Conf_Int[1,8] ,HR_8_0k.S1_Conf_Int[1,8] ,HR_9_0k.S1_Conf_Int[1,8] , HR_10_0k.S1_Conf_Int[1,8],HR_12_5k.S1_Conf_Int[1,8],HR_15_0k.S1_Conf_Int[1,8],HR_17_5k.S1_Conf_Int[1,8],HR_20_0k.S1_Conf_Int[1,8],HR_25_0k.S1_Conf_Int[1,8],HR_30_0k.S1_Conf_Int[1,8], HR_35_0k.S1_Conf_Int[1,8],HR_40_0k.S1_Conf_Int[1,8],HR_45_0k.S1_Conf_Int[1,8],  HR_50_0k.S1_Conf_Int[1,8],  HR_55_0k.S1_Conf_Int[1,8],  HR_60_0k.S1_Conf_Int[1,8],  HR_65_0k.S1_Conf_Int[1,8],  HR_70_0k.S1_Conf_Int[1,8],  HR_75_0k.S1_Conf_Int[1,8],  HR_80_0k.S1_Conf_Int[1,8],  HR_85_0k.S1_Conf_Int[1,8],  HR_90_0k.S1_Conf_Int[1,8],  HR_95_0k.S1_Conf_Int[1,8],  HR_100_0k.S1_Conf_Int[1,8],  HR_105_0k.S1_Conf_Int[1,8],  HR_110_0k.S1_Conf_Int[1,8],  HR_115_0k.S1_Conf_Int[1,8],  HR_120_0k.S1_Conf_Int[1,8],  HR_125_0k.S1_Conf_Int[1,8],  HR_130_0k.S1_Conf_Int[1,8],  HR_135_0k.S1_Conf_Int[1,8],  HR_140_0k.S1_Conf_Int[1,8],  HR_145_0k.S1_Conf_Int[1,8],  HR_150_0k.S1_Conf_Int[1,8]]
        
            PSV_HR_S1_E = [HR_0_1k.S1_Conf_Int[3,8], HR_0_2k.S1_Conf_Int[3,8],HR_0_3k.S1_Conf_Int[3,8] ,HR_0_4k.S1_Conf_Int[3,8] ,HR_0_5k.S1_Conf_Int[3,8] ,HR_0_6k.S1_Conf_Int[3,8] , HR_0_7k.S1_Conf_Int[3,8] ,HR_0_8k.S1_Conf_Int[3,8] ,HR_0_9k.S1_Conf_Int[3,8] ,HR_1_0k.S1_Conf_Int[3,8] ,HR_1_2k.S1_Conf_Int[3,8] ,HR_1_4k.S1_Conf_Int[3,8] ,HR_1_6k.S1_Conf_Int[3,8] , HR_1_8k.S1_Conf_Int[3,8] ,HR_2_0k.S1_Conf_Int[3,8] ,HR_2_3k.S1_Conf_Int[3,8] ,HR_2_6k.S1_Conf_Int[3,8] ,HR_2_9k.S1_Conf_Int[3,8] ,HR_3_0k.S1_Conf_Int[3,8] ,HR_3_5k.S1_Conf_Int[3,8] , HR_4_0k.S1_Conf_Int[3,8] ,HR_4_5k.S1_Conf_Int[3,8] ,HR_5_0k.S1_Conf_Int[3,8] ,HR_6_0k.S1_Conf_Int[3,8] ,HR_7_0k.S1_Conf_Int[3,8] ,HR_8_0k.S1_Conf_Int[3,8] ,HR_9_0k.S1_Conf_Int[3,8] , HR_10_0k.S1_Conf_Int[3,8],HR_12_5k.S1_Conf_Int[3,8],HR_15_0k.S1_Conf_Int[3,8],HR_17_5k.S1_Conf_Int[3,8],HR_20_0k.S1_Conf_Int[3,8],HR_25_0k.S1_Conf_Int[3,8],HR_30_0k.S1_Conf_Int[3,8], HR_35_0k.S1_Conf_Int[3,8],HR_40_0k.S1_Conf_Int[3,8],HR_45_0k.S1_Conf_Int[3,8],  HR_50_0k.S1_Conf_Int[3,8],  HR_55_0k.S1_Conf_Int[3,8],  HR_60_0k.S1_Conf_Int[3,8],  HR_65_0k.S1_Conf_Int[3,8],  HR_70_0k.S1_Conf_Int[3,8],  HR_75_0k.S1_Conf_Int[3,8],  HR_80_0k.S1_Conf_Int[3,8],  HR_85_0k.S1_Conf_Int[3,8],  HR_90_0k.S1_Conf_Int[3,8],  HR_95_0k.S1_Conf_Int[3,8],  HR_100_0k.S1_Conf_Int[3,8],  HR_105_0k.S1_Conf_Int[3,8],  HR_110_0k.S1_Conf_Int[3,8],  HR_115_0k.S1_Conf_Int[3,8],  HR_120_0k.S1_Conf_Int[3,8],  HR_125_0k.S1_Conf_Int[3,8],  HR_130_0k.S1_Conf_Int[3,8],  HR_135_0k.S1_Conf_Int[3,8],  HR_140_0k.S1_Conf_Int[3,8],  HR_145_0k.S1_Conf_Int[3,8],  HR_150_0k.S1_Conf_Int[3,8]]
        end

        # High and Low errors No HR S1 #
        # Cardiac Output
        LowE_CO_HR_S1 = CO_HR_S1 .- (1.96 .*CO_HR_S1_E)
        HighE_CO_HR_S1 = CO_HR_S1 .+ (1.96 .*CO_HR_S1_E)
        # Max PLV
        LowE_PLV_HR_S1 = PLV_HR_S1 .- (1.96 .*PLV_HR_S1_E)
        HighE_PLV_HR_S1 = PLV_HR_S1 .+ (1.96 .*PLV_HR_S1_E)
        # Max PSV
        LowE_PSV_HR_S1 = PSV_HR_S1 .- (1.96 .*PSV_HR_S1_E)
        HighE_PSV_HR_S1 = PSV_HR_S1 .+ (1.96 .*PSV_HR_S1_E)
    end
    #CO S1 R
    band!(x[1:end], min.(LowE_CO_HR_S1, HighE_CO_HR_S1), max.(LowE_CO_HR_S1, HighE_CO_HR_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_HR_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_HR_S1, HighE_PLV_HR_S1), max.(LowE_PLV_HR_S1, HighE_PLV_HR_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_HR_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_HR_S1, HighE_PSV_HR_S1), max.(LowE_PSV_HR_S1, HighE_PSV_HR_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_HR_S1, label = "PSV")
    hidexdecorations!(axn, grid = false)

    axo = Axis(go[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    # Emin S1 fixed HR
    begin
        ## load No HR data for CO PSV PLV S1 ##
        begin
            CO_HR_S1 = [HR_0_1k.S1[9,9], HR_0_2k.S1[9,9],HR_0_3k.S1[9,9] ,HR_0_4k.S1[9,9] ,HR_0_5k.S1[9,9] ,HR_0_6k.S1[9,9] ,  HR_0_7k.S1[9,9] ,HR_0_8k.S1[9,9] ,HR_0_9k.S1[9,9] ,HR_1_0k.S1[9,9] ,HR_1_2k.S1[9,9] ,HR_1_4k.S1[9,9] ,HR_1_6k.S1[9,9] ,  HR_1_8k.S1[9,9] ,HR_2_0k.S1[9,9] ,HR_2_3k.S1[9,9] ,HR_2_6k.S1[9,9] ,HR_2_9k.S1[9,9] ,HR_3_0k.S1[9,9] ,HR_3_5k.S1[9,9] ,  HR_4_0k.S1[9,9] ,HR_4_5k.S1[9,9] ,HR_5_0k.S1[9,9] ,HR_6_0k.S1[9,9] ,HR_7_0k.S1[9,9] ,HR_8_0k.S1[9,9] ,HR_9_0k.S1[9,9] ,  HR_10_0k.S1[9,9],HR_12_5k.S1[9,9],HR_15_0k.S1[9,9],HR_17_5k.S1[9,9],HR_20_0k.S1[9,9],HR_25_0k.S1[9,9],HR_30_0k.S1[9,9],  HR_35_0k.S1[9,9],HR_40_0k.S1[9,9],HR_45_0k.S1[9,9],  HR_50_0k.S1[9,9],  HR_55_0k.S1[9,9],  HR_60_0k.S1[9,9],  HR_65_0k.S1[9,9],  HR_70_0k.S1[9,9],  HR_75_0k.S1[9,9],  HR_80_0k.S1[9,9],  HR_85_0k.S1[9,9],  HR_90_0k.S1[9,9],  HR_95_0k.S1[9,9],  HR_100_0k.S1[9,9],  HR_105_0k.S1[9,9],  HR_110_0k.S1[9,9],  HR_115_0k.S1[9,9],  HR_120_0k.S1[9,9],  HR_125_0k.S1[9,9],  HR_130_0k.S1[9,9],  HR_135_0k.S1[9,9],  HR_140_0k.S1[9,9],  HR_145_0k.S1[9,9],  HR_150_0k.S1[9,9]]
        
            PLV_HR_S1 = [HR_0_1k.S1[1,9], HR_0_2k.S1[1,9],HR_0_3k.S1[1,9] ,HR_0_4k.S1[1,9] ,HR_0_5k.S1[1,9] ,HR_0_6k.S1[1,9] , HR_0_7k.S1[1,9] ,HR_0_8k.S1[1,9] ,HR_0_9k.S1[1,9] ,HR_1_0k.S1[1,9] ,HR_1_2k.S1[1,9] ,HR_1_4k.S1[1,9] ,HR_1_6k.S1[1,9] , HR_1_8k.S1[1,9] ,HR_2_0k.S1[1,9] ,HR_2_3k.S1[1,9] ,HR_2_6k.S1[1,9] ,HR_2_9k.S1[1,9] ,HR_3_0k.S1[1,9] ,HR_3_5k.S1[1,9] , HR_4_0k.S1[1,9] ,HR_4_5k.S1[1,9] ,HR_5_0k.S1[1,9] ,HR_6_0k.S1[1,9] ,HR_7_0k.S1[1,9] ,HR_8_0k.S1[1,9] ,HR_9_0k.S1[1,9] , HR_10_0k.S1[1,9],HR_12_5k.S1[1,9],HR_15_0k.S1[1,9],HR_17_5k.S1[1,9],HR_20_0k.S1[1,9],HR_25_0k.S1[1,9],HR_30_0k.S1[1,9], HR_35_0k.S1[1,9],HR_40_0k.S1[1,9],HR_45_0k.S1[1,9],  HR_50_0k.S1[1,9],  HR_55_0k.S1[1,9],  HR_60_0k.S1[1,9],  HR_65_0k.S1[1,9],  HR_70_0k.S1[1,9],  HR_75_0k.S1[1,9],  HR_80_0k.S1[1,9],  HR_85_0k.S1[1,9],  HR_90_0k.S1[1,9],  HR_95_0k.S1[1,9],  HR_100_0k.S1[1,9],  HR_105_0k.S1[1,9],  HR_110_0k.S1[1,9],  HR_115_0k.S1[1,9],  HR_120_0k.S1[1,9],  HR_125_0k.S1[1,9],  HR_130_0k.S1[1,9],  HR_135_0k.S1[1,9],  HR_140_0k.S1[1,9],  HR_145_0k.S1[1,9],  HR_150_0k.S1[1,9]]
        
            PSV_HR_S1 = [HR_0_1k.S1[3,9], HR_0_2k.S1[3,9],HR_0_3k.S1[3,9] ,HR_0_4k.S1[3,9] ,HR_0_5k.S1[3,9] ,HR_0_6k.S1[3,9] , HR_0_7k.S1[3,9] ,HR_0_8k.S1[3,9] ,HR_0_9k.S1[3,9] ,HR_1_0k.S1[3,9] ,HR_1_2k.S1[3,9] ,HR_1_4k.S1[3,9] ,HR_1_6k.S1[3,9] , HR_1_8k.S1[3,9] ,HR_2_0k.S1[3,9] ,HR_2_3k.S1[3,9] ,HR_2_6k.S1[3,9] ,HR_2_9k.S1[3,9] ,HR_3_0k.S1[3,9] ,HR_3_5k.S1[3,9] , HR_4_0k.S1[3,9] ,HR_4_5k.S1[3,9] ,HR_5_0k.S1[3,9] ,HR_6_0k.S1[3,9] ,HR_7_0k.S1[3,9] ,HR_8_0k.S1[3,9] ,HR_9_0k.S1[3,9] , HR_10_0k.S1[3,9],HR_12_5k.S1[3,9],HR_15_0k.S1[3,9],HR_17_5k.S1[3,9],HR_20_0k.S1[3,9],HR_25_0k.S1[3,9],HR_30_0k.S1[3,9], HR_35_0k.S1[3,9],HR_40_0k.S1[3,9],HR_45_0k.S1[3,9],  HR_50_0k.S1[3,9],  HR_55_0k.S1[3,9],  HR_60_0k.S1[3,9],  HR_65_0k.S1[3,9],  HR_70_0k.S1[3,9],  HR_75_0k.S1[3,9],  HR_80_0k.S1[3,9],  HR_85_0k.S1[3,9],  HR_90_0k.S1[3,9],  HR_95_0k.S1[3,9],  HR_100_0k.S1[3,9],  HR_105_0k.S1[3,9],  HR_110_0k.S1[3,9],  HR_115_0k.S1[3,9],  HR_120_0k.S1[3,9],  HR_125_0k.S1[3,9],  HR_130_0k.S1[3,9],  HR_135_0k.S1[3,9],  HR_140_0k.S1[3,9],  HR_145_0k.S1[3,9],  HR_150_0k.S1[3,9]]
        end

        ## No HR errors for CO PSV PLV S1 ##
        begin
            CO_HR_S1_E = [HR_0_1k.S1_Conf_Int[9,9], HR_0_2k.S1_Conf_Int[9,9],HR_0_3k.S1_Conf_Int[9,9] ,HR_0_4k.S1_Conf_Int[9,9] ,HR_0_5k.S1_Conf_Int[9,9] ,HR_0_6k.S1_Conf_Int[9,9] ,  HR_0_7k.S1_Conf_Int[9,9] ,HR_0_8k.S1_Conf_Int[9,9] ,HR_0_9k.S1_Conf_Int[9,9] ,HR_1_0k.S1_Conf_Int[9,9] ,HR_1_2k.S1_Conf_Int[9,9] ,HR_1_4k.S1_Conf_Int[9,9] ,HR_1_6k.S1_Conf_Int[9,9] ,  HR_1_8k.S1_Conf_Int[9,9] ,HR_2_0k.S1_Conf_Int[9,9] ,HR_2_3k.S1_Conf_Int[9,9] ,HR_2_6k.S1_Conf_Int[9,9] ,HR_2_9k.S1_Conf_Int[9,9] ,HR_3_0k.S1_Conf_Int[9,9] ,HR_3_5k.S1_Conf_Int[9,9] ,  HR_4_0k.S1_Conf_Int[9,9] ,HR_4_5k.S1_Conf_Int[9,9] ,HR_5_0k.S1_Conf_Int[9,9] ,HR_6_0k.S1_Conf_Int[9,9] ,HR_7_0k.S1_Conf_Int[9,9] ,HR_8_0k.S1_Conf_Int[9,9] ,HR_9_0k.S1_Conf_Int[9,9] ,  HR_10_0k.S1_Conf_Int[9,9],HR_12_5k.S1_Conf_Int[9,9],HR_15_0k.S1_Conf_Int[9,9],HR_17_5k.S1_Conf_Int[9,9],HR_20_0k.S1_Conf_Int[9,9],HR_25_0k.S1_Conf_Int[9,9],HR_30_0k.S1_Conf_Int[9,9],  HR_35_0k.S1_Conf_Int[9,9],HR_40_0k.S1_Conf_Int[9,9],HR_45_0k.S1_Conf_Int[9,9],  HR_50_0k.S1_Conf_Int[9,9],  HR_55_0k.S1_Conf_Int[9,9],  HR_60_0k.S1_Conf_Int[9,9],  HR_65_0k.S1_Conf_Int[9,9],  HR_70_0k.S1_Conf_Int[9,9],  HR_75_0k.S1_Conf_Int[9,9],  HR_80_0k.S1_Conf_Int[9,9],  HR_85_0k.S1_Conf_Int[9,9],  HR_90_0k.S1_Conf_Int[9,9],  HR_95_0k.S1_Conf_Int[9,9],  HR_100_0k.S1_Conf_Int[9,9],  HR_105_0k.S1_Conf_Int[9,9],  HR_110_0k.S1_Conf_Int[9,9],  HR_115_0k.S1_Conf_Int[9,9],  HR_120_0k.S1_Conf_Int[9,9],  HR_125_0k.S1_Conf_Int[9,9],  HR_130_0k.S1_Conf_Int[9,9],  HR_135_0k.S1_Conf_Int[9,9],  HR_140_0k.S1_Conf_Int[9,9],  HR_145_0k.S1_Conf_Int[9,9],  HR_150_0k.S1_Conf_Int[9,9]]
        
            PLV_HR_S1_E = [HR_0_1k.S1_Conf_Int[1,9], HR_0_2k.S1_Conf_Int[1,9],HR_0_3k.S1_Conf_Int[1,9] ,HR_0_4k.S1_Conf_Int[1,9] ,HR_0_5k.S1_Conf_Int[1,9] ,HR_0_6k.S1_Conf_Int[1,9] , HR_0_7k.S1_Conf_Int[1,9] ,HR_0_8k.S1_Conf_Int[1,9] ,HR_0_9k.S1_Conf_Int[1,9] ,HR_1_0k.S1_Conf_Int[1,9] ,HR_1_2k.S1_Conf_Int[1,9] ,HR_1_4k.S1_Conf_Int[1,9] ,HR_1_6k.S1_Conf_Int[1,9] , HR_1_8k.S1_Conf_Int[1,9] ,HR_2_0k.S1_Conf_Int[1,9] ,HR_2_3k.S1_Conf_Int[1,9] ,HR_2_6k.S1_Conf_Int[1,9] ,HR_2_9k.S1_Conf_Int[1,9] ,HR_3_0k.S1_Conf_Int[1,9] ,HR_3_5k.S1_Conf_Int[1,9] , HR_4_0k.S1_Conf_Int[1,9] ,HR_4_5k.S1_Conf_Int[1,9] ,HR_5_0k.S1_Conf_Int[1,9] ,HR_6_0k.S1_Conf_Int[1,9] ,HR_7_0k.S1_Conf_Int[1,9] ,HR_8_0k.S1_Conf_Int[1,9] ,HR_9_0k.S1_Conf_Int[1,9] , HR_10_0k.S1_Conf_Int[1,9],HR_12_5k.S1_Conf_Int[1,9],HR_15_0k.S1_Conf_Int[1,9],HR_17_5k.S1_Conf_Int[1,9],HR_20_0k.S1_Conf_Int[1,9],HR_25_0k.S1_Conf_Int[1,9],HR_30_0k.S1_Conf_Int[1,9], HR_35_0k.S1_Conf_Int[1,9],HR_40_0k.S1_Conf_Int[1,9],HR_45_0k.S1_Conf_Int[1,9],  HR_50_0k.S1_Conf_Int[1,9],  HR_55_0k.S1_Conf_Int[1,9],  HR_60_0k.S1_Conf_Int[1,9],  HR_65_0k.S1_Conf_Int[1,9],  HR_70_0k.S1_Conf_Int[1,9],  HR_75_0k.S1_Conf_Int[1,9],  HR_80_0k.S1_Conf_Int[1,9],  HR_85_0k.S1_Conf_Int[1,9],  HR_90_0k.S1_Conf_Int[1,9],  HR_95_0k.S1_Conf_Int[1,9],  HR_100_0k.S1_Conf_Int[1,9],  HR_105_0k.S1_Conf_Int[1,9],  HR_110_0k.S1_Conf_Int[1,9],  HR_115_0k.S1_Conf_Int[1,9],  HR_120_0k.S1_Conf_Int[1,9],  HR_125_0k.S1_Conf_Int[1,9],  HR_130_0k.S1_Conf_Int[1,9],  HR_135_0k.S1_Conf_Int[1,9],  HR_140_0k.S1_Conf_Int[1,9],  HR_145_0k.S1_Conf_Int[1,9],  HR_150_0k.S1_Conf_Int[1,9]]
        
            PSV_HR_S1_E = [HR_0_1k.S1_Conf_Int[3,9], HR_0_2k.S1_Conf_Int[3,9],HR_0_3k.S1_Conf_Int[3,9] ,HR_0_4k.S1_Conf_Int[3,9] ,HR_0_5k.S1_Conf_Int[3,9] ,HR_0_6k.S1_Conf_Int[3,9] , HR_0_7k.S1_Conf_Int[3,9] ,HR_0_8k.S1_Conf_Int[3,9] ,HR_0_9k.S1_Conf_Int[3,9] ,HR_1_0k.S1_Conf_Int[3,9] ,HR_1_2k.S1_Conf_Int[3,9] ,HR_1_4k.S1_Conf_Int[3,9] ,HR_1_6k.S1_Conf_Int[3,9] , HR_1_8k.S1_Conf_Int[3,9] ,HR_2_0k.S1_Conf_Int[3,9] ,HR_2_3k.S1_Conf_Int[3,9] ,HR_2_6k.S1_Conf_Int[3,9] ,HR_2_9k.S1_Conf_Int[3,9] ,HR_3_0k.S1_Conf_Int[3,9] ,HR_3_5k.S1_Conf_Int[3,9] , HR_4_0k.S1_Conf_Int[3,9] ,HR_4_5k.S1_Conf_Int[3,9] ,HR_5_0k.S1_Conf_Int[3,9] ,HR_6_0k.S1_Conf_Int[3,9] ,HR_7_0k.S1_Conf_Int[3,9] ,HR_8_0k.S1_Conf_Int[3,9] ,HR_9_0k.S1_Conf_Int[3,9] , HR_10_0k.S1_Conf_Int[3,9],HR_12_5k.S1_Conf_Int[3,9],HR_15_0k.S1_Conf_Int[3,9],HR_17_5k.S1_Conf_Int[3,9],HR_20_0k.S1_Conf_Int[3,9],HR_25_0k.S1_Conf_Int[3,9],HR_30_0k.S1_Conf_Int[3,9], HR_35_0k.S1_Conf_Int[3,9],HR_40_0k.S1_Conf_Int[3,9],HR_45_0k.S1_Conf_Int[3,9],  HR_50_0k.S1_Conf_Int[3,9],  HR_55_0k.S1_Conf_Int[3,9],  HR_60_0k.S1_Conf_Int[3,9],  HR_65_0k.S1_Conf_Int[3,9],  HR_70_0k.S1_Conf_Int[3,9],  HR_75_0k.S1_Conf_Int[3,9],  HR_80_0k.S1_Conf_Int[3,9],  HR_85_0k.S1_Conf_Int[3,9],  HR_90_0k.S1_Conf_Int[3,9],  HR_95_0k.S1_Conf_Int[3,9],  HR_100_0k.S1_Conf_Int[3,9],  HR_105_0k.S1_Conf_Int[3,9],  HR_110_0k.S1_Conf_Int[3,9],  HR_115_0k.S1_Conf_Int[3,9],  HR_120_0k.S1_Conf_Int[3,9],  HR_125_0k.S1_Conf_Int[3,9],  HR_130_0k.S1_Conf_Int[3,9],  HR_135_0k.S1_Conf_Int[3,9],  HR_140_0k.S1_Conf_Int[3,9],  HR_145_0k.S1_Conf_Int[3,9],  HR_150_0k.S1_Conf_Int[3,9]]
        end

        # High and Low errors No HR S1 #
        # Cardiac Output
        LowE_CO_HR_S1 = CO_HR_S1 .- (1.96 .*CO_HR_S1_E)
        HighE_CO_HR_S1 = CO_HR_S1 .+ (1.96 .*CO_HR_S1_E)
        # Max PLV
        LowE_PLV_HR_S1 = PLV_HR_S1 .- (1.96 .*PLV_HR_S1_E)
        HighE_PLV_HR_S1 = PLV_HR_S1 .+ (1.96 .*PLV_HR_S1_E)
        # Max PSV
        LowE_PSV_HR_S1 = PSV_HR_S1 .- (1.96 .*PSV_HR_S1_E)
        HighE_PSV_HR_S1 = PSV_HR_S1 .+ (1.96 .*PSV_HR_S1_E)
    end
    #CO S1 R
    band!(x[1:end], min.(LowE_CO_HR_S1, HighE_CO_HR_S1), max.(LowE_CO_HR_S1, HighE_CO_HR_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_HR_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_HR_S1, HighE_PLV_HR_S1), max.(LowE_PLV_HR_S1, HighE_PLV_HR_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_HR_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_HR_S1, HighE_PSV_HR_S1), max.(LowE_PSV_HR_S1, HighE_PSV_HR_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_HR_S1, label = "PSV")
    hidexdecorations!(axo, grid = false)

    axp = Axis(gp[1,1], xlabel = L"\text{Sample~Size}", xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    # Csa S1 fixed HR
    begin
        ## load No HR data for CO PSV PLV S1 ##
        begin
            CO_HR_S1 = [HR_0_1k.S1[9,6], HR_0_2k.S1[9,6],HR_0_3k.S1[9,6] ,HR_0_4k.S1[9,6] ,HR_0_5k.S1[9,6] ,HR_0_6k.S1[9,6] ,  HR_0_7k.S1[9,6] ,HR_0_8k.S1[9,6] ,HR_0_9k.S1[9,6] ,HR_1_0k.S1[9,6] ,HR_1_2k.S1[9,6] ,HR_1_4k.S1[9,6] ,HR_1_6k.S1[9,6] ,  HR_1_8k.S1[9,6] ,HR_2_0k.S1[9,6] ,HR_2_3k.S1[9,6] ,HR_2_6k.S1[9,6] ,HR_2_9k.S1[9,6] ,HR_3_0k.S1[9,6] ,HR_3_5k.S1[9,6] ,  HR_4_0k.S1[9,6] ,HR_4_5k.S1[9,6] ,HR_5_0k.S1[9,6] ,HR_6_0k.S1[9,6] ,HR_7_0k.S1[9,6] ,HR_8_0k.S1[9,6] ,HR_9_0k.S1[9,6] ,  HR_10_0k.S1[9,6],HR_12_5k.S1[9,6],HR_15_0k.S1[9,6],HR_17_5k.S1[9,6],HR_20_0k.S1[9,6],HR_25_0k.S1[9,6],HR_30_0k.S1[9,6],  HR_35_0k.S1[9,6],HR_40_0k.S1[9,6],HR_45_0k.S1[9,6],  HR_50_0k.S1[9,6],  HR_55_0k.S1[9,6],  HR_60_0k.S1[9,6],  HR_65_0k.S1[9,6],  HR_70_0k.S1[9,6],  HR_75_0k.S1[9,6],  HR_80_0k.S1[9,6],  HR_85_0k.S1[9,6],  HR_90_0k.S1[9,6],  HR_95_0k.S1[9,6],  HR_100_0k.S1[9,6],  HR_105_0k.S1[9,6],  HR_110_0k.S1[9,6],  HR_115_0k.S1[9,6],  HR_120_0k.S1[9,6],  HR_125_0k.S1[9,6],  HR_130_0k.S1[9,6],  HR_135_0k.S1[9,6],  HR_140_0k.S1[9,6],  HR_145_0k.S1[9,6],  HR_150_0k.S1[9,6]]
        
            PLV_HR_S1 = [HR_0_1k.S1[1,6], HR_0_2k.S1[1,6],HR_0_3k.S1[1,6] ,HR_0_4k.S1[1,6] ,HR_0_5k.S1[1,6] ,HR_0_6k.S1[1,6] , HR_0_7k.S1[1,6] ,HR_0_8k.S1[1,6] ,HR_0_9k.S1[1,6] ,HR_1_0k.S1[1,6] ,HR_1_2k.S1[1,6] ,HR_1_4k.S1[1,6] ,HR_1_6k.S1[1,6] , HR_1_8k.S1[1,6] ,HR_2_0k.S1[1,6] ,HR_2_3k.S1[1,6] ,HR_2_6k.S1[1,6] ,HR_2_9k.S1[1,6] ,HR_3_0k.S1[1,6] ,HR_3_5k.S1[1,6] , HR_4_0k.S1[1,6] ,HR_4_5k.S1[1,6] ,HR_5_0k.S1[1,6] ,HR_6_0k.S1[1,6] ,HR_7_0k.S1[1,6] ,HR_8_0k.S1[1,6] ,HR_9_0k.S1[1,6] , HR_10_0k.S1[1,6],HR_12_5k.S1[1,6],HR_15_0k.S1[1,6],HR_17_5k.S1[1,6],HR_20_0k.S1[1,6],HR_25_0k.S1[1,6],HR_30_0k.S1[1,6], HR_35_0k.S1[1,6],HR_40_0k.S1[1,6],HR_45_0k.S1[1,6],  HR_50_0k.S1[1,6],  HR_55_0k.S1[1,6],  HR_60_0k.S1[1,6],  HR_65_0k.S1[1,6],  HR_70_0k.S1[1,6],  HR_75_0k.S1[1,6],  HR_80_0k.S1[1,6],  HR_85_0k.S1[1,6],  HR_90_0k.S1[1,6],  HR_95_0k.S1[1,6],  HR_100_0k.S1[1,6],  HR_105_0k.S1[1,6],  HR_110_0k.S1[1,6],  HR_115_0k.S1[1,6],  HR_120_0k.S1[1,6],  HR_125_0k.S1[1,6],  HR_130_0k.S1[1,6],  HR_135_0k.S1[1,6],  HR_140_0k.S1[1,6],  HR_145_0k.S1[1,6],  HR_150_0k.S1[1,6]]
        
            PSV_HR_S1 = [HR_0_1k.S1[3,6], HR_0_2k.S1[3,6],HR_0_3k.S1[3,6] ,HR_0_4k.S1[3,6] ,HR_0_5k.S1[3,6] ,HR_0_6k.S1[3,6] , HR_0_7k.S1[3,6] ,HR_0_8k.S1[3,6] ,HR_0_9k.S1[3,6] ,HR_1_0k.S1[3,6] ,HR_1_2k.S1[3,6] ,HR_1_4k.S1[3,6] ,HR_1_6k.S1[3,6] , HR_1_8k.S1[3,6] ,HR_2_0k.S1[3,6] ,HR_2_3k.S1[3,6] ,HR_2_6k.S1[3,6] ,HR_2_9k.S1[3,6] ,HR_3_0k.S1[3,6] ,HR_3_5k.S1[3,6] , HR_4_0k.S1[3,6] ,HR_4_5k.S1[3,6] ,HR_5_0k.S1[3,6] ,HR_6_0k.S1[3,6] ,HR_7_0k.S1[3,6] ,HR_8_0k.S1[3,6] ,HR_9_0k.S1[3,6] , HR_10_0k.S1[3,6],HR_12_5k.S1[3,6],HR_15_0k.S1[3,6],HR_17_5k.S1[3,6],HR_20_0k.S1[3,6],HR_25_0k.S1[3,6],HR_30_0k.S1[3,6], HR_35_0k.S1[3,6],HR_40_0k.S1[3,6],HR_45_0k.S1[3,6],  HR_50_0k.S1[3,6],  HR_55_0k.S1[3,6],  HR_60_0k.S1[3,6],  HR_65_0k.S1[3,6],  HR_70_0k.S1[3,6],  HR_75_0k.S1[3,6],  HR_80_0k.S1[3,6],  HR_85_0k.S1[3,6],  HR_90_0k.S1[3,6],  HR_95_0k.S1[3,6],  HR_100_0k.S1[3,6],  HR_105_0k.S1[3,6],  HR_110_0k.S1[3,6],  HR_115_0k.S1[3,6],  HR_120_0k.S1[3,6],  HR_125_0k.S1[3,6],  HR_130_0k.S1[3,6],  HR_135_0k.S1[3,6],  HR_140_0k.S1[3,6],  HR_145_0k.S1[3,6],  HR_150_0k.S1[3,6]]
        end

        ## No HR errors for CO PSV PLV S1 ##
        begin
            CO_HR_S1_E = [HR_0_1k.S1_Conf_Int[9,6], HR_0_2k.S1_Conf_Int[9,6],HR_0_3k.S1_Conf_Int[9,6] ,HR_0_4k.S1_Conf_Int[9,6] ,HR_0_5k.S1_Conf_Int[9,6] ,HR_0_6k.S1_Conf_Int[9,6] ,  HR_0_7k.S1_Conf_Int[9,6] ,HR_0_8k.S1_Conf_Int[9,6] ,HR_0_9k.S1_Conf_Int[9,6] ,HR_1_0k.S1_Conf_Int[9,6] ,HR_1_2k.S1_Conf_Int[9,6] ,HR_1_4k.S1_Conf_Int[9,6] ,HR_1_6k.S1_Conf_Int[9,6] ,  HR_1_8k.S1_Conf_Int[9,6] ,HR_2_0k.S1_Conf_Int[9,6] ,HR_2_3k.S1_Conf_Int[9,6] ,HR_2_6k.S1_Conf_Int[9,6] ,HR_2_9k.S1_Conf_Int[9,6] ,HR_3_0k.S1_Conf_Int[9,6] ,HR_3_5k.S1_Conf_Int[9,6] ,  HR_4_0k.S1_Conf_Int[9,6] ,HR_4_5k.S1_Conf_Int[9,6] ,HR_5_0k.S1_Conf_Int[9,6] ,HR_6_0k.S1_Conf_Int[9,6] ,HR_7_0k.S1_Conf_Int[9,6] ,HR_8_0k.S1_Conf_Int[9,6] ,HR_9_0k.S1_Conf_Int[9,6] ,  HR_10_0k.S1_Conf_Int[9,6],HR_12_5k.S1_Conf_Int[9,6],HR_15_0k.S1_Conf_Int[9,6],HR_17_5k.S1_Conf_Int[9,6],HR_20_0k.S1_Conf_Int[9,6],HR_25_0k.S1_Conf_Int[9,6],HR_30_0k.S1_Conf_Int[9,6],  HR_35_0k.S1_Conf_Int[9,6],HR_40_0k.S1_Conf_Int[9,6],HR_45_0k.S1_Conf_Int[9,6],  HR_50_0k.S1_Conf_Int[9,6],  HR_55_0k.S1_Conf_Int[9,6],  HR_60_0k.S1_Conf_Int[9,6],  HR_65_0k.S1_Conf_Int[9,6],  HR_70_0k.S1_Conf_Int[9,6],  HR_75_0k.S1_Conf_Int[9,6],  HR_80_0k.S1_Conf_Int[9,6],  HR_85_0k.S1_Conf_Int[9,6],  HR_90_0k.S1_Conf_Int[9,6],  HR_95_0k.S1_Conf_Int[9,6],  HR_100_0k.S1_Conf_Int[9,6],  HR_105_0k.S1_Conf_Int[9,6],  HR_110_0k.S1_Conf_Int[9,6],  HR_115_0k.S1_Conf_Int[9,6],  HR_120_0k.S1_Conf_Int[9,6],  HR_125_0k.S1_Conf_Int[9,6],  HR_130_0k.S1_Conf_Int[9,6],  HR_135_0k.S1_Conf_Int[9,6],  HR_140_0k.S1_Conf_Int[9,6],  HR_145_0k.S1_Conf_Int[9,6],  HR_150_0k.S1_Conf_Int[9,6]]
        
            PLV_HR_S1_E = [HR_0_1k.S1_Conf_Int[1,6], HR_0_2k.S1_Conf_Int[1,6],HR_0_3k.S1_Conf_Int[1,6] ,HR_0_4k.S1_Conf_Int[1,6] ,HR_0_5k.S1_Conf_Int[1,6] ,HR_0_6k.S1_Conf_Int[1,6] , HR_0_7k.S1_Conf_Int[1,6] ,HR_0_8k.S1_Conf_Int[1,6] ,HR_0_9k.S1_Conf_Int[1,6] ,HR_1_0k.S1_Conf_Int[1,6] ,HR_1_2k.S1_Conf_Int[1,6] ,HR_1_4k.S1_Conf_Int[1,6] ,HR_1_6k.S1_Conf_Int[1,6] , HR_1_8k.S1_Conf_Int[1,6] ,HR_2_0k.S1_Conf_Int[1,6] ,HR_2_3k.S1_Conf_Int[1,6] ,HR_2_6k.S1_Conf_Int[1,6] ,HR_2_9k.S1_Conf_Int[1,6] ,HR_3_0k.S1_Conf_Int[1,6] ,HR_3_5k.S1_Conf_Int[1,6] , HR_4_0k.S1_Conf_Int[1,6] ,HR_4_5k.S1_Conf_Int[1,6] ,HR_5_0k.S1_Conf_Int[1,6] ,HR_6_0k.S1_Conf_Int[1,6] ,HR_7_0k.S1_Conf_Int[1,6] ,HR_8_0k.S1_Conf_Int[1,6] ,HR_9_0k.S1_Conf_Int[1,6] , HR_10_0k.S1_Conf_Int[1,6],HR_12_5k.S1_Conf_Int[1,6],HR_15_0k.S1_Conf_Int[1,6],HR_17_5k.S1_Conf_Int[1,6],HR_20_0k.S1_Conf_Int[1,6],HR_25_0k.S1_Conf_Int[1,6],HR_30_0k.S1_Conf_Int[1,6], HR_35_0k.S1_Conf_Int[1,6],HR_40_0k.S1_Conf_Int[1,6],HR_45_0k.S1_Conf_Int[1,6],  HR_50_0k.S1_Conf_Int[1,6],  HR_55_0k.S1_Conf_Int[1,6],  HR_60_0k.S1_Conf_Int[1,6],  HR_65_0k.S1_Conf_Int[1,6],  HR_70_0k.S1_Conf_Int[1,6],  HR_75_0k.S1_Conf_Int[1,6],  HR_80_0k.S1_Conf_Int[1,6],  HR_85_0k.S1_Conf_Int[1,6],  HR_90_0k.S1_Conf_Int[1,6],  HR_95_0k.S1_Conf_Int[1,6],  HR_100_0k.S1_Conf_Int[1,6],  HR_105_0k.S1_Conf_Int[1,6],  HR_110_0k.S1_Conf_Int[1,6],  HR_115_0k.S1_Conf_Int[1,6],  HR_120_0k.S1_Conf_Int[1,6],  HR_125_0k.S1_Conf_Int[1,6],  HR_130_0k.S1_Conf_Int[1,6],  HR_135_0k.S1_Conf_Int[1,6],  HR_140_0k.S1_Conf_Int[1,6],  HR_145_0k.S1_Conf_Int[1,6],  HR_150_0k.S1_Conf_Int[1,6]]
        
            PSV_HR_S1_E = [HR_0_1k.S1_Conf_Int[3,6], HR_0_2k.S1_Conf_Int[3,6],HR_0_3k.S1_Conf_Int[3,6] ,HR_0_4k.S1_Conf_Int[3,6] ,HR_0_5k.S1_Conf_Int[3,6] ,HR_0_6k.S1_Conf_Int[3,6] , HR_0_7k.S1_Conf_Int[3,6] ,HR_0_8k.S1_Conf_Int[3,6] ,HR_0_9k.S1_Conf_Int[3,6] ,HR_1_0k.S1_Conf_Int[3,6] ,HR_1_2k.S1_Conf_Int[3,6] ,HR_1_4k.S1_Conf_Int[3,6] ,HR_1_6k.S1_Conf_Int[3,6] , HR_1_8k.S1_Conf_Int[3,6] ,HR_2_0k.S1_Conf_Int[3,6] ,HR_2_3k.S1_Conf_Int[3,6] ,HR_2_6k.S1_Conf_Int[3,6] ,HR_2_9k.S1_Conf_Int[3,6] ,HR_3_0k.S1_Conf_Int[3,6] ,HR_3_5k.S1_Conf_Int[3,6] , HR_4_0k.S1_Conf_Int[3,6] ,HR_4_5k.S1_Conf_Int[3,6] ,HR_5_0k.S1_Conf_Int[3,6] ,HR_6_0k.S1_Conf_Int[3,6] ,HR_7_0k.S1_Conf_Int[3,6] ,HR_8_0k.S1_Conf_Int[3,6] ,HR_9_0k.S1_Conf_Int[3,6] , HR_10_0k.S1_Conf_Int[3,6],HR_12_5k.S1_Conf_Int[3,6],HR_15_0k.S1_Conf_Int[3,6],HR_17_5k.S1_Conf_Int[3,6],HR_20_0k.S1_Conf_Int[3,6],HR_25_0k.S1_Conf_Int[3,6],HR_30_0k.S1_Conf_Int[3,6], HR_35_0k.S1_Conf_Int[3,6],HR_40_0k.S1_Conf_Int[3,6],HR_45_0k.S1_Conf_Int[3,6],  HR_50_0k.S1_Conf_Int[3,6],  HR_55_0k.S1_Conf_Int[3,6],  HR_60_0k.S1_Conf_Int[3,6],  HR_65_0k.S1_Conf_Int[3,6],  HR_70_0k.S1_Conf_Int[3,6],  HR_75_0k.S1_Conf_Int[3,6],  HR_80_0k.S1_Conf_Int[3,6],  HR_85_0k.S1_Conf_Int[3,6],  HR_90_0k.S1_Conf_Int[3,6],  HR_95_0k.S1_Conf_Int[3,6],  HR_100_0k.S1_Conf_Int[3,6],  HR_105_0k.S1_Conf_Int[3,6],  HR_110_0k.S1_Conf_Int[3,6],  HR_115_0k.S1_Conf_Int[3,6],  HR_120_0k.S1_Conf_Int[3,6],  HR_125_0k.S1_Conf_Int[3,6],  HR_130_0k.S1_Conf_Int[3,6],  HR_135_0k.S1_Conf_Int[3,6],  HR_140_0k.S1_Conf_Int[3,6],  HR_145_0k.S1_Conf_Int[3,6],  HR_150_0k.S1_Conf_Int[3,6]]
        end

        # High and Low errors No HR S1 #
        # Cardiac Output
        LowE_CO_HR_S1 = CO_HR_S1 .- (1.96 .*CO_HR_S1_E)
        HighE_CO_HR_S1 = CO_HR_S1 .+ (1.96 .*CO_HR_S1_E)
        # Max PLV
        LowE_PLV_HR_S1 = PLV_HR_S1 .- (1.96 .*PLV_HR_S1_E)
        HighE_PLV_HR_S1 = PLV_HR_S1 .+ (1.96 .*PLV_HR_S1_E)
        # Max PSV
        LowE_PSV_HR_S1 = PSV_HR_S1 .- (1.96 .*PSV_HR_S1_E)
        HighE_PSV_HR_S1 = PSV_HR_S1 .+ (1.96 .*PSV_HR_S1_E)
    end
    #CO S1 R
    band!(x[1:end], min.(LowE_CO_HR_S1, HighE_CO_HR_S1), max.(LowE_CO_HR_S1, HighE_CO_HR_S1), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_HR_S1, label = "CO")
    #PLV S1 R
    band!(x[1:end], min.(LowE_PLV_HR_S1, HighE_PLV_HR_S1), max.(LowE_PLV_HR_S1, HighE_PLV_HR_S1), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_HR_S1, label = "PLV")
    #PSV S1 R
    band!(x[1:end], min.(LowE_PSV_HR_S1, HighE_PSV_HR_S1), max.(LowE_PSV_HR_S1, HighE_PSV_HR_S1), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_HR_S1, label = "PSV")
    #hidedecorations!(axp, grid = false)

    axq = Axis(gq[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    Label(gq[1, 1, Top()], L"S_{T}~\text{Fixed}~\text{HR}", valign = :center, font = :bold, padding = (0, 0, 0, 0))
    # Rs ST fixed HR
    begin
        ## load No HR data for CO PSV PLV ST ##
        begin
            CO_HR_ST = [HR_0_1k.ST[9,5], HR_0_2k.ST[9,5],HR_0_3k.ST[9,5] ,HR_0_4k.ST[9,5] ,HR_0_5k.ST[9,5] ,HR_0_6k.ST[9,5] ,  HR_0_7k.ST[9,5] ,HR_0_8k.ST[9,5] ,HR_0_9k.ST[9,5] ,HR_1_0k.ST[9,5] ,HR_1_2k.ST[9,5] ,HR_1_4k.ST[9,5] ,HR_1_6k.ST[9,5] ,  HR_1_8k.ST[9,5] ,HR_2_0k.ST[9,5] ,HR_2_3k.ST[9,5] ,HR_2_6k.ST[9,5] ,HR_2_9k.ST[9,5] ,HR_3_0k.ST[9,5] ,HR_3_5k.ST[9,5] ,  HR_4_0k.ST[9,5] ,HR_4_5k.ST[9,5] ,HR_5_0k.ST[9,5] ,HR_6_0k.ST[9,5] ,HR_7_0k.ST[9,5] ,HR_8_0k.ST[9,5] ,HR_9_0k.ST[9,5] ,  HR_10_0k.ST[9,5],HR_12_5k.ST[9,5],HR_15_0k.ST[9,5],HR_17_5k.ST[9,5],HR_20_0k.ST[9,5],HR_25_0k.ST[9,5],HR_30_0k.ST[9,5],  HR_35_0k.ST[9,5],HR_40_0k.ST[9,5],HR_45_0k.ST[9,5],  HR_50_0k.ST[9,5],  HR_55_0k.ST[9,5],  HR_60_0k.ST[9,5],  HR_65_0k.ST[9,5],  HR_70_0k.ST[9,5],  HR_75_0k.ST[9,5],  HR_80_0k.ST[9,5],  HR_85_0k.ST[9,5],  HR_90_0k.ST[9,5],  HR_95_0k.ST[9,5],  HR_100_0k.ST[9,5],  HR_105_0k.ST[9,5],  HR_110_0k.ST[9,5],  HR_115_0k.ST[9,5],  HR_120_0k.ST[9,5],  HR_125_0k.ST[9,5],  HR_130_0k.ST[9,5],  HR_135_0k.ST[9,5],  HR_140_0k.ST[9,5],  HR_145_0k.ST[9,5],  HR_150_0k.ST[9,5]]
        
            PLV_HR_ST = [HR_0_1k.ST[1,5], HR_0_2k.ST[1,5],HR_0_3k.ST[1,5] ,HR_0_4k.ST[1,5] ,HR_0_5k.ST[1,5] ,HR_0_6k.ST[1,5] , HR_0_7k.ST[1,5] ,HR_0_8k.ST[1,5] ,HR_0_9k.ST[1,5] ,HR_1_0k.ST[1,5] ,HR_1_2k.ST[1,5] ,HR_1_4k.ST[1,5] ,HR_1_6k.ST[1,5] , HR_1_8k.ST[1,5] ,HR_2_0k.ST[1,5] ,HR_2_3k.ST[1,5] ,HR_2_6k.ST[1,5] ,HR_2_9k.ST[1,5] ,HR_3_0k.ST[1,5] ,HR_3_5k.ST[1,5] , HR_4_0k.ST[1,5] ,HR_4_5k.ST[1,5] ,HR_5_0k.ST[1,5] ,HR_6_0k.ST[1,5] ,HR_7_0k.ST[1,5] ,HR_8_0k.ST[1,5] ,HR_9_0k.ST[1,5] , HR_10_0k.ST[1,5],HR_12_5k.ST[1,5],HR_15_0k.ST[1,5],HR_17_5k.ST[1,5],HR_20_0k.ST[1,5],HR_25_0k.ST[1,5],HR_30_0k.ST[1,5], HR_35_0k.ST[1,5],HR_40_0k.ST[1,5],HR_45_0k.ST[1,5],  HR_50_0k.ST[1,5],  HR_55_0k.ST[1,5],  HR_60_0k.ST[1,5],  HR_65_0k.ST[1,5],  HR_70_0k.ST[1,5],  HR_75_0k.ST[1,5],  HR_80_0k.ST[1,5],  HR_85_0k.ST[1,5],  HR_90_0k.ST[1,5],  HR_95_0k.ST[1,5],  HR_100_0k.ST[1,5],  HR_105_0k.ST[1,5],  HR_110_0k.ST[1,5],  HR_115_0k.ST[1,5],  HR_120_0k.ST[1,5],  HR_125_0k.ST[1,5],  HR_130_0k.ST[1,5],  HR_135_0k.ST[1,5],  HR_140_0k.ST[1,5],  HR_145_0k.ST[1,5],  HR_150_0k.ST[1,5]]
        
            PSV_HR_ST = [HR_0_1k.ST[3,5], HR_0_2k.ST[3,5],HR_0_3k.ST[3,5] ,HR_0_4k.ST[3,5] ,HR_0_5k.ST[3,5] ,HR_0_6k.ST[3,5] , HR_0_7k.ST[3,5] ,HR_0_8k.ST[3,5] ,HR_0_9k.ST[3,5] ,HR_1_0k.ST[3,5] ,HR_1_2k.ST[3,5] ,HR_1_4k.ST[3,5] ,HR_1_6k.ST[3,5] , HR_1_8k.ST[3,5] ,HR_2_0k.ST[3,5] ,HR_2_3k.ST[3,5] ,HR_2_6k.ST[3,5] ,HR_2_9k.ST[3,5] ,HR_3_0k.ST[3,5] ,HR_3_5k.ST[3,5] , HR_4_0k.ST[3,5] ,HR_4_5k.ST[3,5] ,HR_5_0k.ST[3,5] ,HR_6_0k.ST[3,5] ,HR_7_0k.ST[3,5] ,HR_8_0k.ST[3,5] ,HR_9_0k.ST[3,5] , HR_10_0k.ST[3,5],HR_12_5k.ST[3,5],HR_15_0k.ST[3,5],HR_17_5k.ST[3,5],HR_20_0k.ST[3,5],HR_25_0k.ST[3,5],HR_30_0k.ST[3,5], HR_35_0k.ST[3,5],HR_40_0k.ST[3,5],HR_45_0k.ST[3,5],  HR_50_0k.ST[3,5],  HR_55_0k.ST[3,5],  HR_60_0k.ST[3,5],  HR_65_0k.ST[3,5],  HR_70_0k.ST[3,5],  HR_75_0k.ST[3,5],  HR_80_0k.ST[3,5],  HR_85_0k.ST[3,5],  HR_90_0k.ST[3,5],  HR_95_0k.ST[3,5],  HR_100_0k.ST[3,5],  HR_105_0k.ST[3,5],  HR_110_0k.ST[3,5],  HR_115_0k.ST[3,5],  HR_120_0k.ST[3,5],  HR_125_0k.ST[3,5],  HR_130_0k.ST[3,5],  HR_135_0k.ST[3,5],  HR_140_0k.ST[3,5],  HR_145_0k.ST[3,5],  HR_150_0k.ST[3,5]]
        end

        ## No HR errors for CO PSV PLV ST ##
        begin
            CO_HR_ST_E = [HR_0_1k.ST_Conf_Int[9,5], HR_0_2k.ST_Conf_Int[9,5],HR_0_3k.ST_Conf_Int[9,5] ,HR_0_4k.ST_Conf_Int[9,5] ,HR_0_5k.ST_Conf_Int[9,5] ,HR_0_6k.ST_Conf_Int[9,5] ,  HR_0_7k.ST_Conf_Int[9,5] ,HR_0_8k.ST_Conf_Int[9,5] ,HR_0_9k.ST_Conf_Int[9,5] ,HR_1_0k.ST_Conf_Int[9,5] ,HR_1_2k.ST_Conf_Int[9,5] ,HR_1_4k.ST_Conf_Int[9,5] ,HR_1_6k.ST_Conf_Int[9,5] ,  HR_1_8k.ST_Conf_Int[9,5] ,HR_2_0k.ST_Conf_Int[9,5] ,HR_2_3k.ST_Conf_Int[9,5] ,HR_2_6k.ST_Conf_Int[9,5] ,HR_2_9k.ST_Conf_Int[9,5] ,HR_3_0k.ST_Conf_Int[9,5] ,HR_3_5k.ST_Conf_Int[9,5] ,  HR_4_0k.ST_Conf_Int[9,5] ,HR_4_5k.ST_Conf_Int[9,5] ,HR_5_0k.ST_Conf_Int[9,5] ,HR_6_0k.ST_Conf_Int[9,5] ,HR_7_0k.ST_Conf_Int[9,5] ,HR_8_0k.ST_Conf_Int[9,5] ,HR_9_0k.ST_Conf_Int[9,5] ,  HR_10_0k.ST_Conf_Int[9,5],HR_12_5k.ST_Conf_Int[9,5],HR_15_0k.ST_Conf_Int[9,5],HR_17_5k.ST_Conf_Int[9,5],HR_20_0k.ST_Conf_Int[9,5],HR_25_0k.ST_Conf_Int[9,5],HR_30_0k.ST_Conf_Int[9,5],  HR_35_0k.ST_Conf_Int[9,5],HR_40_0k.ST_Conf_Int[9,5],HR_45_0k.ST_Conf_Int[9,5],  HR_50_0k.ST_Conf_Int[9,5],  HR_55_0k.ST_Conf_Int[9,5],  HR_60_0k.ST_Conf_Int[9,5],  HR_65_0k.ST_Conf_Int[9,5],  HR_70_0k.ST_Conf_Int[9,5],  HR_75_0k.ST_Conf_Int[9,5],  HR_80_0k.ST_Conf_Int[9,5],  HR_85_0k.ST_Conf_Int[9,5],  HR_90_0k.ST_Conf_Int[9,5],  HR_95_0k.ST_Conf_Int[9,5],  HR_100_0k.ST_Conf_Int[9,5],  HR_105_0k.ST_Conf_Int[9,5],  HR_110_0k.ST_Conf_Int[9,5],  HR_115_0k.ST_Conf_Int[9,5],  HR_120_0k.ST_Conf_Int[9,5],  HR_125_0k.ST_Conf_Int[9,5],  HR_130_0k.ST_Conf_Int[9,5],  HR_135_0k.ST_Conf_Int[9,5],  HR_140_0k.ST_Conf_Int[9,5],  HR_145_0k.ST_Conf_Int[9,5],  HR_150_0k.ST_Conf_Int[9,5]]
        
            PLV_HR_ST_E = [HR_0_1k.ST_Conf_Int[1,5], HR_0_2k.ST_Conf_Int[1,5],HR_0_3k.ST_Conf_Int[1,5] ,HR_0_4k.ST_Conf_Int[1,5] ,HR_0_5k.ST_Conf_Int[1,5] ,HR_0_6k.ST_Conf_Int[1,5] , HR_0_7k.ST_Conf_Int[1,5] ,HR_0_8k.ST_Conf_Int[1,5] ,HR_0_9k.ST_Conf_Int[1,5] ,HR_1_0k.ST_Conf_Int[1,5] ,HR_1_2k.ST_Conf_Int[1,5] ,HR_1_4k.ST_Conf_Int[1,5] ,HR_1_6k.ST_Conf_Int[1,5] , HR_1_8k.ST_Conf_Int[1,5] ,HR_2_0k.ST_Conf_Int[1,5] ,HR_2_3k.ST_Conf_Int[1,5] ,HR_2_6k.ST_Conf_Int[1,5] ,HR_2_9k.ST_Conf_Int[1,5] ,HR_3_0k.ST_Conf_Int[1,5] ,HR_3_5k.ST_Conf_Int[1,5] , HR_4_0k.ST_Conf_Int[1,5] ,HR_4_5k.ST_Conf_Int[1,5] ,HR_5_0k.ST_Conf_Int[1,5] ,HR_6_0k.ST_Conf_Int[1,5] ,HR_7_0k.ST_Conf_Int[1,5] ,HR_8_0k.ST_Conf_Int[1,5] ,HR_9_0k.ST_Conf_Int[1,5] , HR_10_0k.ST_Conf_Int[1,5],HR_12_5k.ST_Conf_Int[1,5],HR_15_0k.ST_Conf_Int[1,5],HR_17_5k.ST_Conf_Int[1,5],HR_20_0k.ST_Conf_Int[1,5],HR_25_0k.ST_Conf_Int[1,5],HR_30_0k.ST_Conf_Int[1,5], HR_35_0k.ST_Conf_Int[1,5],HR_40_0k.ST_Conf_Int[1,5],HR_45_0k.ST_Conf_Int[1,5],  HR_50_0k.ST_Conf_Int[1,5],  HR_55_0k.ST_Conf_Int[1,5],  HR_60_0k.ST_Conf_Int[1,5],  HR_65_0k.ST_Conf_Int[1,5],  HR_70_0k.ST_Conf_Int[1,5],  HR_75_0k.ST_Conf_Int[1,5],  HR_80_0k.ST_Conf_Int[1,5],  HR_85_0k.ST_Conf_Int[1,5],  HR_90_0k.ST_Conf_Int[1,5],  HR_95_0k.ST_Conf_Int[1,5],  HR_100_0k.ST_Conf_Int[1,5],  HR_105_0k.ST_Conf_Int[1,5],  HR_110_0k.ST_Conf_Int[1,5],  HR_115_0k.ST_Conf_Int[1,5],  HR_120_0k.ST_Conf_Int[1,5],  HR_125_0k.ST_Conf_Int[1,5],  HR_130_0k.ST_Conf_Int[1,5],  HR_135_0k.ST_Conf_Int[1,5],  HR_140_0k.ST_Conf_Int[1,5],  HR_145_0k.ST_Conf_Int[1,5],  HR_150_0k.ST_Conf_Int[1,5]]
        
            PSV_HR_ST_E = [HR_0_1k.ST_Conf_Int[3,5], HR_0_2k.ST_Conf_Int[3,5],HR_0_3k.ST_Conf_Int[3,5] ,HR_0_4k.ST_Conf_Int[3,5] ,HR_0_5k.ST_Conf_Int[3,5] ,HR_0_6k.ST_Conf_Int[3,5] , HR_0_7k.ST_Conf_Int[3,5] ,HR_0_8k.ST_Conf_Int[3,5] ,HR_0_9k.ST_Conf_Int[3,5] ,HR_1_0k.ST_Conf_Int[3,5] ,HR_1_2k.ST_Conf_Int[3,5] ,HR_1_4k.ST_Conf_Int[3,5] ,HR_1_6k.ST_Conf_Int[3,5] , HR_1_8k.ST_Conf_Int[3,5] ,HR_2_0k.ST_Conf_Int[3,5] ,HR_2_3k.ST_Conf_Int[3,5] ,HR_2_6k.ST_Conf_Int[3,5] ,HR_2_9k.ST_Conf_Int[3,5] ,HR_3_0k.ST_Conf_Int[3,5] ,HR_3_5k.ST_Conf_Int[3,5] , HR_4_0k.ST_Conf_Int[3,5] ,HR_4_5k.ST_Conf_Int[3,5] ,HR_5_0k.ST_Conf_Int[3,5] ,HR_6_0k.ST_Conf_Int[3,5] ,HR_7_0k.ST_Conf_Int[3,5] ,HR_8_0k.ST_Conf_Int[3,5] ,HR_9_0k.ST_Conf_Int[3,5] , HR_10_0k.ST_Conf_Int[3,5],HR_12_5k.ST_Conf_Int[3,5],HR_15_0k.ST_Conf_Int[3,5],HR_17_5k.ST_Conf_Int[3,5],HR_20_0k.ST_Conf_Int[3,5],HR_25_0k.ST_Conf_Int[3,5],HR_30_0k.ST_Conf_Int[3,5], HR_35_0k.ST_Conf_Int[3,5],HR_40_0k.ST_Conf_Int[3,5],HR_45_0k.ST_Conf_Int[3,5],  HR_50_0k.ST_Conf_Int[3,5],  HR_55_0k.ST_Conf_Int[3,5],  HR_60_0k.ST_Conf_Int[3,5],  HR_65_0k.ST_Conf_Int[3,5],  HR_70_0k.ST_Conf_Int[3,5],  HR_75_0k.ST_Conf_Int[3,5],  HR_80_0k.ST_Conf_Int[3,5],  HR_85_0k.ST_Conf_Int[3,5],  HR_90_0k.ST_Conf_Int[3,5],  HR_95_0k.ST_Conf_Int[3,5],  HR_100_0k.ST_Conf_Int[3,5],  HR_105_0k.ST_Conf_Int[3,5],  HR_110_0k.ST_Conf_Int[3,5],  HR_115_0k.ST_Conf_Int[3,5],  HR_120_0k.ST_Conf_Int[3,5],  HR_125_0k.ST_Conf_Int[3,5],  HR_130_0k.ST_Conf_Int[3,5],  HR_135_0k.ST_Conf_Int[3,5],  HR_140_0k.ST_Conf_Int[3,5],  HR_145_0k.ST_Conf_Int[3,5],  HR_150_0k.ST_Conf_Int[3,5]]
        end

        # High and Low errors No HR ST #
        # Cardiac Output
        LowE_CO_HR_ST = CO_HR_ST .- (1.96 .*CO_HR_ST_E)
        HighE_CO_HR_ST = CO_HR_ST .+ (1.96 .*CO_HR_ST_E)
        # Max PLV
        LowE_PLV_HR_ST = PLV_HR_ST .- (1.96 .*PLV_HR_ST_E)
        HighE_PLV_HR_ST = PLV_HR_ST .+ (1.96 .*PLV_HR_ST_E)
        # Max PSV
        LowE_PSV_HR_ST = PSV_HR_ST .- (1.96 .*PSV_HR_ST_E)
        HighE_PSV_HR_ST = PSV_HR_ST .+ (1.96 .*PSV_HR_ST_E)
    end
    #CO ST R
    band!(x[1:end], min.(LowE_CO_HR_ST, HighE_CO_HR_ST), max.(LowE_CO_HR_ST, HighE_CO_HR_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_HR_ST, label = "CO")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_HR_ST, HighE_PLV_HR_ST), max.(LowE_PLV_HR_ST, HighE_PLV_HR_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_HR_ST, label = "PLV")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_HR_ST, HighE_PSV_HR_ST), max.(LowE_PSV_HR_ST, HighE_PSV_HR_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_HR_ST, label = "PSV")
    hidexdecorations!(axq, grid = false)

    axr = Axis(gr[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    # Emax ST fixed HR
    begin
        ## load No HR data for CO PSV PLV ST ##
        begin
            CO_HR_ST = [HR_0_1k.ST[9,8], HR_0_2k.ST[9,8],HR_0_3k.ST[9,8] ,HR_0_4k.ST[9,8] ,HR_0_5k.ST[9,8] ,HR_0_6k.ST[9,8] ,  HR_0_7k.ST[9,8] ,HR_0_8k.ST[9,8] ,HR_0_9k.ST[9,8] ,HR_1_0k.ST[9,8] ,HR_1_2k.ST[9,8] ,HR_1_4k.ST[9,8] ,HR_1_6k.ST[9,8] ,  HR_1_8k.ST[9,8] ,HR_2_0k.ST[9,8] ,HR_2_3k.ST[9,8] ,HR_2_6k.ST[9,8] ,HR_2_9k.ST[9,8] ,HR_3_0k.ST[9,8] ,HR_3_5k.ST[9,8] ,  HR_4_0k.ST[9,8] ,HR_4_5k.ST[9,8] ,HR_5_0k.ST[9,8] ,HR_6_0k.ST[9,8] ,HR_7_0k.ST[9,8] ,HR_8_0k.ST[9,8] ,HR_9_0k.ST[9,8] ,  HR_10_0k.ST[9,8],HR_12_5k.ST[9,8],HR_15_0k.ST[9,8],HR_17_5k.ST[9,8],HR_20_0k.ST[9,8],HR_25_0k.ST[9,8],HR_30_0k.ST[9,8],  HR_35_0k.ST[9,8],HR_40_0k.ST[9,8],HR_45_0k.ST[9,8],  HR_50_0k.ST[9,8],  HR_55_0k.ST[9,8],  HR_60_0k.ST[9,8],  HR_65_0k.ST[9,8],  HR_70_0k.ST[9,8],  HR_75_0k.ST[9,8],  HR_80_0k.ST[9,8],  HR_85_0k.ST[9,8],  HR_90_0k.ST[9,8],  HR_95_0k.ST[9,8],  HR_100_0k.ST[9,8],  HR_105_0k.ST[9,8],  HR_110_0k.ST[9,8],  HR_115_0k.ST[9,8],  HR_120_0k.ST[9,8],  HR_125_0k.ST[9,8],  HR_130_0k.ST[9,8],  HR_135_0k.ST[9,8],  HR_140_0k.ST[9,8],  HR_145_0k.ST[9,8],  HR_150_0k.ST[9,8]]
        
            PLV_HR_ST = [HR_0_1k.ST[1,8], HR_0_2k.ST[1,8],HR_0_3k.ST[1,8] ,HR_0_4k.ST[1,8] ,HR_0_5k.ST[1,8] ,HR_0_6k.ST[1,8] , HR_0_7k.ST[1,8] ,HR_0_8k.ST[1,8] ,HR_0_9k.ST[1,8] ,HR_1_0k.ST[1,8] ,HR_1_2k.ST[1,8] ,HR_1_4k.ST[1,8] ,HR_1_6k.ST[1,8] , HR_1_8k.ST[1,8] ,HR_2_0k.ST[1,8] ,HR_2_3k.ST[1,8] ,HR_2_6k.ST[1,8] ,HR_2_9k.ST[1,8] ,HR_3_0k.ST[1,8] ,HR_3_5k.ST[1,8] , HR_4_0k.ST[1,8] ,HR_4_5k.ST[1,8] ,HR_5_0k.ST[1,8] ,HR_6_0k.ST[1,8] ,HR_7_0k.ST[1,8] ,HR_8_0k.ST[1,8] ,HR_9_0k.ST[1,8] , HR_10_0k.ST[1,8],HR_12_5k.ST[1,8],HR_15_0k.ST[1,8],HR_17_5k.ST[1,8],HR_20_0k.ST[1,8],HR_25_0k.ST[1,8],HR_30_0k.ST[1,8], HR_35_0k.ST[1,8],HR_40_0k.ST[1,8],HR_45_0k.ST[1,8],  HR_50_0k.ST[1,8],  HR_55_0k.ST[1,8],  HR_60_0k.ST[1,8],  HR_65_0k.ST[1,8],  HR_70_0k.ST[1,8],  HR_75_0k.ST[1,8],  HR_80_0k.ST[1,8],  HR_85_0k.ST[1,8],  HR_90_0k.ST[1,8],  HR_95_0k.ST[1,8],  HR_100_0k.ST[1,8],  HR_105_0k.ST[1,8],  HR_110_0k.ST[1,8],  HR_115_0k.ST[1,8],  HR_120_0k.ST[1,8],  HR_125_0k.ST[1,8],  HR_130_0k.ST[1,8],  HR_135_0k.ST[1,8],  HR_140_0k.ST[1,8],  HR_145_0k.ST[1,8],  HR_150_0k.ST[1,8]]
        
            PSV_HR_ST = [HR_0_1k.ST[3,8], HR_0_2k.ST[3,8],HR_0_3k.ST[3,8] ,HR_0_4k.ST[3,8] ,HR_0_5k.ST[3,8] ,HR_0_6k.ST[3,8] , HR_0_7k.ST[3,8] ,HR_0_8k.ST[3,8] ,HR_0_9k.ST[3,8] ,HR_1_0k.ST[3,8] ,HR_1_2k.ST[3,8] ,HR_1_4k.ST[3,8] ,HR_1_6k.ST[3,8] , HR_1_8k.ST[3,8] ,HR_2_0k.ST[3,8] ,HR_2_3k.ST[3,8] ,HR_2_6k.ST[3,8] ,HR_2_9k.ST[3,8] ,HR_3_0k.ST[3,8] ,HR_3_5k.ST[3,8] , HR_4_0k.ST[3,8] ,HR_4_5k.ST[3,8] ,HR_5_0k.ST[3,8] ,HR_6_0k.ST[3,8] ,HR_7_0k.ST[3,8] ,HR_8_0k.ST[3,8] ,HR_9_0k.ST[3,8] , HR_10_0k.ST[3,8],HR_12_5k.ST[3,8],HR_15_0k.ST[3,8],HR_17_5k.ST[3,8],HR_20_0k.ST[3,8],HR_25_0k.ST[3,8],HR_30_0k.ST[3,8], HR_35_0k.ST[3,8],HR_40_0k.ST[3,8],HR_45_0k.ST[3,8],  HR_50_0k.ST[3,8],  HR_55_0k.ST[3,8],  HR_60_0k.ST[3,8],  HR_65_0k.ST[3,8],  HR_70_0k.ST[3,8],  HR_75_0k.ST[3,8],  HR_80_0k.ST[3,8],  HR_85_0k.ST[3,8],  HR_90_0k.ST[3,8],  HR_95_0k.ST[3,8],  HR_100_0k.ST[3,8],  HR_105_0k.ST[3,8],  HR_110_0k.ST[3,8],  HR_115_0k.ST[3,8],  HR_120_0k.ST[3,8],  HR_125_0k.ST[3,8],  HR_130_0k.ST[3,8],  HR_135_0k.ST[3,8],  HR_140_0k.ST[3,8],  HR_145_0k.ST[3,8],  HR_150_0k.ST[3,8]]
        end
    
        ## No HR errors for CO PSV PLV ST ##
        begin
            CO_HR_ST_E = [HR_0_1k.ST_Conf_Int[9,8], HR_0_2k.ST_Conf_Int[9,8],HR_0_3k.ST_Conf_Int[9,8] ,HR_0_4k.ST_Conf_Int[9,8] ,HR_0_5k.ST_Conf_Int[9,8] ,HR_0_6k.ST_Conf_Int[9,8] ,  HR_0_7k.ST_Conf_Int[9,8] ,HR_0_8k.ST_Conf_Int[9,8] ,HR_0_9k.ST_Conf_Int[9,8] ,HR_1_0k.ST_Conf_Int[9,8] ,HR_1_2k.ST_Conf_Int[9,8] ,HR_1_4k.ST_Conf_Int[9,8] ,HR_1_6k.ST_Conf_Int[9,8] ,  HR_1_8k.ST_Conf_Int[9,8] ,HR_2_0k.ST_Conf_Int[9,8] ,HR_2_3k.ST_Conf_Int[9,8] ,HR_2_6k.ST_Conf_Int[9,8] ,HR_2_9k.ST_Conf_Int[9,8] ,HR_3_0k.ST_Conf_Int[9,8] ,HR_3_5k.ST_Conf_Int[9,8] ,  HR_4_0k.ST_Conf_Int[9,8] ,HR_4_5k.ST_Conf_Int[9,8] ,HR_5_0k.ST_Conf_Int[9,8] ,HR_6_0k.ST_Conf_Int[9,8] ,HR_7_0k.ST_Conf_Int[9,8] ,HR_8_0k.ST_Conf_Int[9,8] ,HR_9_0k.ST_Conf_Int[9,8] ,  HR_10_0k.ST_Conf_Int[9,8],HR_12_5k.ST_Conf_Int[9,8],HR_15_0k.ST_Conf_Int[9,8],HR_17_5k.ST_Conf_Int[9,8],HR_20_0k.ST_Conf_Int[9,8],HR_25_0k.ST_Conf_Int[9,8],HR_30_0k.ST_Conf_Int[9,8],  HR_35_0k.ST_Conf_Int[9,8],HR_40_0k.ST_Conf_Int[9,8],HR_45_0k.ST_Conf_Int[9,8],  HR_50_0k.ST_Conf_Int[9,8],  HR_55_0k.ST_Conf_Int[9,8],  HR_60_0k.ST_Conf_Int[9,8],  HR_65_0k.ST_Conf_Int[9,8],  HR_70_0k.ST_Conf_Int[9,8],  HR_75_0k.ST_Conf_Int[9,8],  HR_80_0k.ST_Conf_Int[9,8],  HR_85_0k.ST_Conf_Int[9,8],  HR_90_0k.ST_Conf_Int[9,8],  HR_95_0k.ST_Conf_Int[9,8],  HR_100_0k.ST_Conf_Int[9,8],  HR_105_0k.ST_Conf_Int[9,8],  HR_110_0k.ST_Conf_Int[9,8],  HR_115_0k.ST_Conf_Int[9,8],  HR_120_0k.ST_Conf_Int[9,8],  HR_125_0k.ST_Conf_Int[9,8],  HR_130_0k.ST_Conf_Int[9,8],  HR_135_0k.ST_Conf_Int[9,8],  HR_140_0k.ST_Conf_Int[9,8],  HR_145_0k.ST_Conf_Int[9,8],  HR_150_0k.ST_Conf_Int[9,8]]
        
            PLV_HR_ST_E = [HR_0_1k.ST_Conf_Int[1,8], HR_0_2k.ST_Conf_Int[1,8],HR_0_3k.ST_Conf_Int[1,8] ,HR_0_4k.ST_Conf_Int[1,8] ,HR_0_5k.ST_Conf_Int[1,8] ,HR_0_6k.ST_Conf_Int[1,8] , HR_0_7k.ST_Conf_Int[1,8] ,HR_0_8k.ST_Conf_Int[1,8] ,HR_0_9k.ST_Conf_Int[1,8] ,HR_1_0k.ST_Conf_Int[1,8] ,HR_1_2k.ST_Conf_Int[1,8] ,HR_1_4k.ST_Conf_Int[1,8] ,HR_1_6k.ST_Conf_Int[1,8] , HR_1_8k.ST_Conf_Int[1,8] ,HR_2_0k.ST_Conf_Int[1,8] ,HR_2_3k.ST_Conf_Int[1,8] ,HR_2_6k.ST_Conf_Int[1,8] ,HR_2_9k.ST_Conf_Int[1,8] ,HR_3_0k.ST_Conf_Int[1,8] ,HR_3_5k.ST_Conf_Int[1,8] , HR_4_0k.ST_Conf_Int[1,8] ,HR_4_5k.ST_Conf_Int[1,8] ,HR_5_0k.ST_Conf_Int[1,8] ,HR_6_0k.ST_Conf_Int[1,8] ,HR_7_0k.ST_Conf_Int[1,8] ,HR_8_0k.ST_Conf_Int[1,8] ,HR_9_0k.ST_Conf_Int[1,8] , HR_10_0k.ST_Conf_Int[1,8],HR_12_5k.ST_Conf_Int[1,8],HR_15_0k.ST_Conf_Int[1,8],HR_17_5k.ST_Conf_Int[1,8],HR_20_0k.ST_Conf_Int[1,8],HR_25_0k.ST_Conf_Int[1,8],HR_30_0k.ST_Conf_Int[1,8], HR_35_0k.ST_Conf_Int[1,8],HR_40_0k.ST_Conf_Int[1,8],HR_45_0k.ST_Conf_Int[1,8],  HR_50_0k.ST_Conf_Int[1,8],  HR_55_0k.ST_Conf_Int[1,8],  HR_60_0k.ST_Conf_Int[1,8],  HR_65_0k.ST_Conf_Int[1,8],  HR_70_0k.ST_Conf_Int[1,8],  HR_75_0k.ST_Conf_Int[1,8],  HR_80_0k.ST_Conf_Int[1,8],  HR_85_0k.ST_Conf_Int[1,8],  HR_90_0k.ST_Conf_Int[1,8],  HR_95_0k.ST_Conf_Int[1,8],  HR_100_0k.ST_Conf_Int[1,8],  HR_105_0k.ST_Conf_Int[1,8],  HR_110_0k.ST_Conf_Int[1,8],  HR_115_0k.ST_Conf_Int[1,8],  HR_120_0k.ST_Conf_Int[1,8],  HR_125_0k.ST_Conf_Int[1,8],  HR_130_0k.ST_Conf_Int[1,8],  HR_135_0k.ST_Conf_Int[1,8],  HR_140_0k.ST_Conf_Int[1,8],  HR_145_0k.ST_Conf_Int[1,8],  HR_150_0k.ST_Conf_Int[1,8]]
        
            PSV_HR_ST_E = [HR_0_1k.ST_Conf_Int[3,8], HR_0_2k.ST_Conf_Int[3,8],HR_0_3k.ST_Conf_Int[3,8] ,HR_0_4k.ST_Conf_Int[3,8] ,HR_0_5k.ST_Conf_Int[3,8] ,HR_0_6k.ST_Conf_Int[3,8] , HR_0_7k.ST_Conf_Int[3,8] ,HR_0_8k.ST_Conf_Int[3,8] ,HR_0_9k.ST_Conf_Int[3,8] ,HR_1_0k.ST_Conf_Int[3,8] ,HR_1_2k.ST_Conf_Int[3,8] ,HR_1_4k.ST_Conf_Int[3,8] ,HR_1_6k.ST_Conf_Int[3,8] , HR_1_8k.ST_Conf_Int[3,8] ,HR_2_0k.ST_Conf_Int[3,8] ,HR_2_3k.ST_Conf_Int[3,8] ,HR_2_6k.ST_Conf_Int[3,8] ,HR_2_9k.ST_Conf_Int[3,8] ,HR_3_0k.ST_Conf_Int[3,8] ,HR_3_5k.ST_Conf_Int[3,8] , HR_4_0k.ST_Conf_Int[3,8] ,HR_4_5k.ST_Conf_Int[3,8] ,HR_5_0k.ST_Conf_Int[3,8] ,HR_6_0k.ST_Conf_Int[3,8] ,HR_7_0k.ST_Conf_Int[3,8] ,HR_8_0k.ST_Conf_Int[3,8] ,HR_9_0k.ST_Conf_Int[3,8] , HR_10_0k.ST_Conf_Int[3,8],HR_12_5k.ST_Conf_Int[3,8],HR_15_0k.ST_Conf_Int[3,8],HR_17_5k.ST_Conf_Int[3,8],HR_20_0k.ST_Conf_Int[3,8],HR_25_0k.ST_Conf_Int[3,8],HR_30_0k.ST_Conf_Int[3,8], HR_35_0k.ST_Conf_Int[3,8],HR_40_0k.ST_Conf_Int[3,8],HR_45_0k.ST_Conf_Int[3,8],  HR_50_0k.ST_Conf_Int[3,8],  HR_55_0k.ST_Conf_Int[3,8],  HR_60_0k.ST_Conf_Int[3,8],  HR_65_0k.ST_Conf_Int[3,8],  HR_70_0k.ST_Conf_Int[3,8],  HR_75_0k.ST_Conf_Int[3,8],  HR_80_0k.ST_Conf_Int[3,8],  HR_85_0k.ST_Conf_Int[3,8],  HR_90_0k.ST_Conf_Int[3,8],  HR_95_0k.ST_Conf_Int[3,8],  HR_100_0k.ST_Conf_Int[3,8],  HR_105_0k.ST_Conf_Int[3,8],  HR_110_0k.ST_Conf_Int[3,8],  HR_115_0k.ST_Conf_Int[3,8],  HR_120_0k.ST_Conf_Int[3,8],  HR_125_0k.ST_Conf_Int[3,8],  HR_130_0k.ST_Conf_Int[3,8],  HR_135_0k.ST_Conf_Int[3,8],  HR_140_0k.ST_Conf_Int[3,8],  HR_145_0k.ST_Conf_Int[3,8],  HR_150_0k.ST_Conf_Int[3,8]]
        end
    
        # High and Low errors No HR ST #
        # Cardiac Output
        LowE_CO_HR_ST = CO_HR_ST .- (1.96 .*CO_HR_ST_E)
        HighE_CO_HR_ST = CO_HR_ST .+ (1.96 .*CO_HR_ST_E)
        # Max PLV
        LowE_PLV_HR_ST = PLV_HR_ST .- (1.96 .*PLV_HR_ST_E)
        HighE_PLV_HR_ST = PLV_HR_ST .+ (1.96 .*PLV_HR_ST_E)
        # Max PSV
        LowE_PSV_HR_ST = PSV_HR_ST .- (1.96 .*PSV_HR_ST_E)
        HighE_PSV_HR_ST = PSV_HR_ST .+ (1.96 .*PSV_HR_ST_E)
    end
    #CO ST R
    band!(x[1:end], min.(LowE_CO_HR_ST, HighE_CO_HR_ST), max.(LowE_CO_HR_ST, HighE_CO_HR_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_HR_ST, label = "CO")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_HR_ST, HighE_PLV_HR_ST), max.(LowE_PLV_HR_ST, HighE_PLV_HR_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_HR_ST, label = "PLV")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_HR_ST, HighE_PSV_HR_ST), max.(LowE_PSV_HR_ST, HighE_PSV_HR_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_HR_ST, label = "PSV")
    hidexdecorations!(axr, grid = false)

    axs = Axis(gs[1,1], xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    # Emin ST fixed HR
    begin
        ## load No HR data for CO PSV PLV ST ##
        begin
            CO_HR_ST = [HR_0_1k.ST[9,9], HR_0_2k.ST[9,9],HR_0_3k.ST[9,9] ,HR_0_4k.ST[9,9] ,HR_0_5k.ST[9,9] ,HR_0_6k.ST[9,9] ,  HR_0_7k.ST[9,9] ,HR_0_8k.ST[9,9] ,HR_0_9k.ST[9,9] ,HR_1_0k.ST[9,9] ,HR_1_2k.ST[9,9] ,HR_1_4k.ST[9,9] ,HR_1_6k.ST[9,9] ,  HR_1_8k.ST[9,9] ,HR_2_0k.ST[9,9] ,HR_2_3k.ST[9,9] ,HR_2_6k.ST[9,9] ,HR_2_9k.ST[9,9] ,HR_3_0k.ST[9,9] ,HR_3_5k.ST[9,9] ,  HR_4_0k.ST[9,9] ,HR_4_5k.ST[9,9] ,HR_5_0k.ST[9,9] ,HR_6_0k.ST[9,9] ,HR_7_0k.ST[9,9] ,HR_8_0k.ST[9,9] ,HR_9_0k.ST[9,9] ,  HR_10_0k.ST[9,9],HR_12_5k.ST[9,9],HR_15_0k.ST[9,9],HR_17_5k.ST[9,9],HR_20_0k.ST[9,9],HR_25_0k.ST[9,9],HR_30_0k.ST[9,9],  HR_35_0k.ST[9,9],HR_40_0k.ST[9,9],HR_45_0k.ST[9,9],  HR_50_0k.ST[9,9],  HR_55_0k.ST[9,9],  HR_60_0k.ST[9,9],  HR_65_0k.ST[9,9],  HR_70_0k.ST[9,9],  HR_75_0k.ST[9,9],  HR_80_0k.ST[9,9],  HR_85_0k.ST[9,9],  HR_90_0k.ST[9,9],  HR_95_0k.ST[9,9],  HR_100_0k.ST[9,9],  HR_105_0k.ST[9,9],  HR_110_0k.ST[9,9],  HR_115_0k.ST[9,9],  HR_120_0k.ST[9,9],  HR_125_0k.ST[9,9],  HR_130_0k.ST[9,9],  HR_135_0k.ST[9,9],  HR_140_0k.ST[9,9],  HR_145_0k.ST[9,9],  HR_150_0k.ST[9,9]]
        
            PLV_HR_ST = [HR_0_1k.ST[1,9], HR_0_2k.ST[1,9],HR_0_3k.ST[1,9] ,HR_0_4k.ST[1,9] ,HR_0_5k.ST[1,9] ,HR_0_6k.ST[1,9] , HR_0_7k.ST[1,9] ,HR_0_8k.ST[1,9] ,HR_0_9k.ST[1,9] ,HR_1_0k.ST[1,9] ,HR_1_2k.ST[1,9] ,HR_1_4k.ST[1,9] ,HR_1_6k.ST[1,9] , HR_1_8k.ST[1,9] ,HR_2_0k.ST[1,9] ,HR_2_3k.ST[1,9] ,HR_2_6k.ST[1,9] ,HR_2_9k.ST[1,9] ,HR_3_0k.ST[1,9] ,HR_3_5k.ST[1,9] , HR_4_0k.ST[1,9] ,HR_4_5k.ST[1,9] ,HR_5_0k.ST[1,9] ,HR_6_0k.ST[1,9] ,HR_7_0k.ST[1,9] ,HR_8_0k.ST[1,9] ,HR_9_0k.ST[1,9] , HR_10_0k.ST[1,9],HR_12_5k.ST[1,9],HR_15_0k.ST[1,9],HR_17_5k.ST[1,9],HR_20_0k.ST[1,9],HR_25_0k.ST[1,9],HR_30_0k.ST[1,9], HR_35_0k.ST[1,9],HR_40_0k.ST[1,9],HR_45_0k.ST[1,9],  HR_50_0k.ST[1,9],  HR_55_0k.ST[1,9],  HR_60_0k.ST[1,9],  HR_65_0k.ST[1,9],  HR_70_0k.ST[1,9],  HR_75_0k.ST[1,9],  HR_80_0k.ST[1,9],  HR_85_0k.ST[1,9],  HR_90_0k.ST[1,9],  HR_95_0k.ST[1,9],  HR_100_0k.ST[1,9],  HR_105_0k.ST[1,9],  HR_110_0k.ST[1,9],  HR_115_0k.ST[1,9],  HR_120_0k.ST[1,9],  HR_125_0k.ST[1,9],  HR_130_0k.ST[1,9],  HR_135_0k.ST[1,9],  HR_140_0k.ST[1,9],  HR_145_0k.ST[1,9],  HR_150_0k.ST[1,9]]
        
            PSV_HR_ST = [HR_0_1k.ST[3,9], HR_0_2k.ST[3,9],HR_0_3k.ST[3,9] ,HR_0_4k.ST[3,9] ,HR_0_5k.ST[3,9] ,HR_0_6k.ST[3,9] , HR_0_7k.ST[3,9] ,HR_0_8k.ST[3,9] ,HR_0_9k.ST[3,9] ,HR_1_0k.ST[3,9] ,HR_1_2k.ST[3,9] ,HR_1_4k.ST[3,9] ,HR_1_6k.ST[3,9] , HR_1_8k.ST[3,9] ,HR_2_0k.ST[3,9] ,HR_2_3k.ST[3,9] ,HR_2_6k.ST[3,9] ,HR_2_9k.ST[3,9] ,HR_3_0k.ST[3,9] ,HR_3_5k.ST[3,9] , HR_4_0k.ST[3,9] ,HR_4_5k.ST[3,9] ,HR_5_0k.ST[3,9] ,HR_6_0k.ST[3,9] ,HR_7_0k.ST[3,9] ,HR_8_0k.ST[3,9] ,HR_9_0k.ST[3,9] , HR_10_0k.ST[3,9],HR_12_5k.ST[3,9],HR_15_0k.ST[3,9],HR_17_5k.ST[3,9],HR_20_0k.ST[3,9],HR_25_0k.ST[3,9],HR_30_0k.ST[3,9], HR_35_0k.ST[3,9],HR_40_0k.ST[3,9],HR_45_0k.ST[3,9],  HR_50_0k.ST[3,9],  HR_55_0k.ST[3,9],  HR_60_0k.ST[3,9],  HR_65_0k.ST[3,9],  HR_70_0k.ST[3,9],  HR_75_0k.ST[3,9],  HR_80_0k.ST[3,9],  HR_85_0k.ST[3,9],  HR_90_0k.ST[3,9],  HR_95_0k.ST[3,9],  HR_100_0k.ST[3,9],  HR_105_0k.ST[3,9],  HR_110_0k.ST[3,9],  HR_115_0k.ST[3,9],  HR_120_0k.ST[3,9],  HR_125_0k.ST[3,9],  HR_130_0k.ST[3,9],  HR_135_0k.ST[3,9],  HR_140_0k.ST[3,9],  HR_145_0k.ST[3,9],  HR_150_0k.ST[3,9]]
        end
    
        ## No HR errors for CO PSV PLV ST ##
        begin
            CO_HR_ST_E = [HR_0_1k.ST_Conf_Int[9,9], HR_0_2k.ST_Conf_Int[9,9],HR_0_3k.ST_Conf_Int[9,9] ,HR_0_4k.ST_Conf_Int[9,9] ,HR_0_5k.ST_Conf_Int[9,9] ,HR_0_6k.ST_Conf_Int[9,9] ,  HR_0_7k.ST_Conf_Int[9,9] ,HR_0_8k.ST_Conf_Int[9,9] ,HR_0_9k.ST_Conf_Int[9,9] ,HR_1_0k.ST_Conf_Int[9,9] ,HR_1_2k.ST_Conf_Int[9,9] ,HR_1_4k.ST_Conf_Int[9,9] ,HR_1_6k.ST_Conf_Int[9,9] ,  HR_1_8k.ST_Conf_Int[9,9] ,HR_2_0k.ST_Conf_Int[9,9] ,HR_2_3k.ST_Conf_Int[9,9] ,HR_2_6k.ST_Conf_Int[9,9] ,HR_2_9k.ST_Conf_Int[9,9] ,HR_3_0k.ST_Conf_Int[9,9] ,HR_3_5k.ST_Conf_Int[9,9] ,  HR_4_0k.ST_Conf_Int[9,9] ,HR_4_5k.ST_Conf_Int[9,9] ,HR_5_0k.ST_Conf_Int[9,9] ,HR_6_0k.ST_Conf_Int[9,9] ,HR_7_0k.ST_Conf_Int[9,9] ,HR_8_0k.ST_Conf_Int[9,9] ,HR_9_0k.ST_Conf_Int[9,9] ,  HR_10_0k.ST_Conf_Int[9,9],HR_12_5k.ST_Conf_Int[9,9],HR_15_0k.ST_Conf_Int[9,9],HR_17_5k.ST_Conf_Int[9,9],HR_20_0k.ST_Conf_Int[9,9],HR_25_0k.ST_Conf_Int[9,9],HR_30_0k.ST_Conf_Int[9,9],  HR_35_0k.ST_Conf_Int[9,9],HR_40_0k.ST_Conf_Int[9,9],HR_45_0k.ST_Conf_Int[9,9],  HR_50_0k.ST_Conf_Int[9,9],  HR_55_0k.ST_Conf_Int[9,9],  HR_60_0k.ST_Conf_Int[9,9],  HR_65_0k.ST_Conf_Int[9,9],  HR_70_0k.ST_Conf_Int[9,9],  HR_75_0k.ST_Conf_Int[9,9],  HR_80_0k.ST_Conf_Int[9,9],  HR_85_0k.ST_Conf_Int[9,9],  HR_90_0k.ST_Conf_Int[9,9],  HR_95_0k.ST_Conf_Int[9,9],  HR_100_0k.ST_Conf_Int[9,9],  HR_105_0k.ST_Conf_Int[9,9],  HR_110_0k.ST_Conf_Int[9,9],  HR_115_0k.ST_Conf_Int[9,9],  HR_120_0k.ST_Conf_Int[9,9],  HR_125_0k.ST_Conf_Int[9,9],  HR_130_0k.ST_Conf_Int[9,9],  HR_135_0k.ST_Conf_Int[9,9],  HR_140_0k.ST_Conf_Int[9,9],  HR_145_0k.ST_Conf_Int[9,9],  HR_150_0k.ST_Conf_Int[9,9]]
        
            PLV_HR_ST_E = [HR_0_1k.ST_Conf_Int[1,9], HR_0_2k.ST_Conf_Int[1,9],HR_0_3k.ST_Conf_Int[1,9] ,HR_0_4k.ST_Conf_Int[1,9] ,HR_0_5k.ST_Conf_Int[1,9] ,HR_0_6k.ST_Conf_Int[1,9] , HR_0_7k.ST_Conf_Int[1,9] ,HR_0_8k.ST_Conf_Int[1,9] ,HR_0_9k.ST_Conf_Int[1,9] ,HR_1_0k.ST_Conf_Int[1,9] ,HR_1_2k.ST_Conf_Int[1,9] ,HR_1_4k.ST_Conf_Int[1,9] ,HR_1_6k.ST_Conf_Int[1,9] , HR_1_8k.ST_Conf_Int[1,9] ,HR_2_0k.ST_Conf_Int[1,9] ,HR_2_3k.ST_Conf_Int[1,9] ,HR_2_6k.ST_Conf_Int[1,9] ,HR_2_9k.ST_Conf_Int[1,9] ,HR_3_0k.ST_Conf_Int[1,9] ,HR_3_5k.ST_Conf_Int[1,9] , HR_4_0k.ST_Conf_Int[1,9] ,HR_4_5k.ST_Conf_Int[1,9] ,HR_5_0k.ST_Conf_Int[1,9] ,HR_6_0k.ST_Conf_Int[1,9] ,HR_7_0k.ST_Conf_Int[1,9] ,HR_8_0k.ST_Conf_Int[1,9] ,HR_9_0k.ST_Conf_Int[1,9] , HR_10_0k.ST_Conf_Int[1,9],HR_12_5k.ST_Conf_Int[1,9],HR_15_0k.ST_Conf_Int[1,9],HR_17_5k.ST_Conf_Int[1,9],HR_20_0k.ST_Conf_Int[1,9],HR_25_0k.ST_Conf_Int[1,9],HR_30_0k.ST_Conf_Int[1,9], HR_35_0k.ST_Conf_Int[1,9],HR_40_0k.ST_Conf_Int[1,9],HR_45_0k.ST_Conf_Int[1,9],  HR_50_0k.ST_Conf_Int[1,9],  HR_55_0k.ST_Conf_Int[1,9],  HR_60_0k.ST_Conf_Int[1,9],  HR_65_0k.ST_Conf_Int[1,9],  HR_70_0k.ST_Conf_Int[1,9],  HR_75_0k.ST_Conf_Int[1,9],  HR_80_0k.ST_Conf_Int[1,9],  HR_85_0k.ST_Conf_Int[1,9],  HR_90_0k.ST_Conf_Int[1,9],  HR_95_0k.ST_Conf_Int[1,9],  HR_100_0k.ST_Conf_Int[1,9],  HR_105_0k.ST_Conf_Int[1,9],  HR_110_0k.ST_Conf_Int[1,9],  HR_115_0k.ST_Conf_Int[1,9],  HR_120_0k.ST_Conf_Int[1,9],  HR_125_0k.ST_Conf_Int[1,9],  HR_130_0k.ST_Conf_Int[1,9],  HR_135_0k.ST_Conf_Int[1,9],  HR_140_0k.ST_Conf_Int[1,9],  HR_145_0k.ST_Conf_Int[1,9],  HR_150_0k.ST_Conf_Int[1,9]]
        
            PSV_HR_ST_E = [HR_0_1k.ST_Conf_Int[3,9], HR_0_2k.ST_Conf_Int[3,9],HR_0_3k.ST_Conf_Int[3,9] ,HR_0_4k.ST_Conf_Int[3,9] ,HR_0_5k.ST_Conf_Int[3,9] ,HR_0_6k.ST_Conf_Int[3,9] , HR_0_7k.ST_Conf_Int[3,9] ,HR_0_8k.ST_Conf_Int[3,9] ,HR_0_9k.ST_Conf_Int[3,9] ,HR_1_0k.ST_Conf_Int[3,9] ,HR_1_2k.ST_Conf_Int[3,9] ,HR_1_4k.ST_Conf_Int[3,9] ,HR_1_6k.ST_Conf_Int[3,9] , HR_1_8k.ST_Conf_Int[3,9] ,HR_2_0k.ST_Conf_Int[3,9] ,HR_2_3k.ST_Conf_Int[3,9] ,HR_2_6k.ST_Conf_Int[3,9] ,HR_2_9k.ST_Conf_Int[3,9] ,HR_3_0k.ST_Conf_Int[3,9] ,HR_3_5k.ST_Conf_Int[3,9] , HR_4_0k.ST_Conf_Int[3,9] ,HR_4_5k.ST_Conf_Int[3,9] ,HR_5_0k.ST_Conf_Int[3,9] ,HR_6_0k.ST_Conf_Int[3,9] ,HR_7_0k.ST_Conf_Int[3,9] ,HR_8_0k.ST_Conf_Int[3,9] ,HR_9_0k.ST_Conf_Int[3,9] , HR_10_0k.ST_Conf_Int[3,9],HR_12_5k.ST_Conf_Int[3,9],HR_15_0k.ST_Conf_Int[3,9],HR_17_5k.ST_Conf_Int[3,9],HR_20_0k.ST_Conf_Int[3,9],HR_25_0k.ST_Conf_Int[3,9],HR_30_0k.ST_Conf_Int[3,9], HR_35_0k.ST_Conf_Int[3,9],HR_40_0k.ST_Conf_Int[3,9],HR_45_0k.ST_Conf_Int[3,9],  HR_50_0k.ST_Conf_Int[3,9],  HR_55_0k.ST_Conf_Int[3,9],  HR_60_0k.ST_Conf_Int[3,9],  HR_65_0k.ST_Conf_Int[3,9],  HR_70_0k.ST_Conf_Int[3,9],  HR_75_0k.ST_Conf_Int[3,9],  HR_80_0k.ST_Conf_Int[3,9],  HR_85_0k.ST_Conf_Int[3,9],  HR_90_0k.ST_Conf_Int[3,9],  HR_95_0k.ST_Conf_Int[3,9],  HR_100_0k.ST_Conf_Int[3,9],  HR_105_0k.ST_Conf_Int[3,9],  HR_110_0k.ST_Conf_Int[3,9],  HR_115_0k.ST_Conf_Int[3,9],  HR_120_0k.ST_Conf_Int[3,9],  HR_125_0k.ST_Conf_Int[3,9],  HR_130_0k.ST_Conf_Int[3,9],  HR_135_0k.ST_Conf_Int[3,9],  HR_140_0k.ST_Conf_Int[3,9],  HR_145_0k.ST_Conf_Int[3,9],  HR_150_0k.ST_Conf_Int[3,9]]
        end
    
        # High and Low errors No HR ST #
        # Cardiac Output
        LowE_CO_HR_ST = CO_HR_ST .- (1.96 .*CO_HR_ST_E)
        HighE_CO_HR_ST = CO_HR_ST .+ (1.96 .*CO_HR_ST_E)
        # Max PLV
        LowE_PLV_HR_ST = PLV_HR_ST .- (1.96 .*PLV_HR_ST_E)
        HighE_PLV_HR_ST = PLV_HR_ST .+ (1.96 .*PLV_HR_ST_E)
        # Max PSV
        LowE_PSV_HR_ST = PSV_HR_ST .- (1.96 .*PSV_HR_ST_E)
        HighE_PSV_HR_ST = PSV_HR_ST .+ (1.96 .*PSV_HR_ST_E)
    end
    #CO ST R
    band!(x[1:end], min.(LowE_CO_HR_ST, HighE_CO_HR_ST), max.(LowE_CO_HR_ST, HighE_CO_HR_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_HR_ST, label = "CO")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_HR_ST, HighE_PLV_HR_ST), max.(LowE_PLV_HR_ST, HighE_PLV_HR_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_HR_ST, label = "PLV")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_HR_ST, HighE_PSV_HR_ST), max.(LowE_PSV_HR_ST, HighE_PSV_HR_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_HR_ST, label = "PSV")
    hidexdecorations!(axs, grid = false)

    axt = Axis(gt[1,1], xlabel = L"\text{Sample~Size}", xgridstyle = :dash, ygridstyle = :dash,xticksize = 0.5,   yticksize = 5)
    # Csa S1 fixed HR
    begin
        ## load No HR data for CO PSV PLV ST ##
        begin
            CO_HR_ST = [HR_0_1k.ST[9,6], HR_0_2k.ST[9,6],HR_0_3k.ST[9,6] ,HR_0_4k.ST[9,6] ,HR_0_5k.ST[9,6] ,HR_0_6k.ST[9,6] ,  HR_0_7k.ST[9,6] ,HR_0_8k.ST[9,6] ,HR_0_9k.ST[9,6] ,HR_1_0k.ST[9,6] ,HR_1_2k.ST[9,6] ,HR_1_4k.ST[9,6] ,HR_1_6k.ST[9,6] ,  HR_1_8k.ST[9,6] ,HR_2_0k.ST[9,6] ,HR_2_3k.ST[9,6] ,HR_2_6k.ST[9,6] ,HR_2_9k.ST[9,6] ,HR_3_0k.ST[9,6] ,HR_3_5k.ST[9,6] ,  HR_4_0k.ST[9,6] ,HR_4_5k.ST[9,6] ,HR_5_0k.ST[9,6] ,HR_6_0k.ST[9,6] ,HR_7_0k.ST[9,6] ,HR_8_0k.ST[9,6] ,HR_9_0k.ST[9,6] ,  HR_10_0k.ST[9,6],HR_12_5k.ST[9,6],HR_15_0k.ST[9,6],HR_17_5k.ST[9,6],HR_20_0k.ST[9,6],HR_25_0k.ST[9,6],HR_30_0k.ST[9,6],  HR_35_0k.ST[9,6],HR_40_0k.ST[9,6],HR_45_0k.ST[9,6],  HR_50_0k.ST[9,6],  HR_55_0k.ST[9,6],  HR_60_0k.ST[9,6],  HR_65_0k.ST[9,6],  HR_70_0k.ST[9,6],  HR_75_0k.ST[9,6],  HR_80_0k.ST[9,6],  HR_85_0k.ST[9,6],  HR_90_0k.ST[9,6],  HR_95_0k.ST[9,6],  HR_100_0k.ST[9,6],  HR_105_0k.ST[9,6],  HR_110_0k.ST[9,6],  HR_115_0k.ST[9,6],  HR_120_0k.ST[9,6],  HR_125_0k.ST[9,6],  HR_130_0k.ST[9,6],  HR_135_0k.ST[9,6],  HR_140_0k.ST[9,6],  HR_145_0k.ST[9,6],  HR_150_0k.ST[9,6]]
        
            PLV_HR_ST = [HR_0_1k.ST[1,6], HR_0_2k.ST[1,6],HR_0_3k.ST[1,6] ,HR_0_4k.ST[1,6] ,HR_0_5k.ST[1,6] ,HR_0_6k.ST[1,6] , HR_0_7k.ST[1,6] ,HR_0_8k.ST[1,6] ,HR_0_9k.ST[1,6] ,HR_1_0k.ST[1,6] ,HR_1_2k.ST[1,6] ,HR_1_4k.ST[1,6] ,HR_1_6k.ST[1,6] , HR_1_8k.ST[1,6] ,HR_2_0k.ST[1,6] ,HR_2_3k.ST[1,6] ,HR_2_6k.ST[1,6] ,HR_2_9k.ST[1,6] ,HR_3_0k.ST[1,6] ,HR_3_5k.ST[1,6] , HR_4_0k.ST[1,6] ,HR_4_5k.ST[1,6] ,HR_5_0k.ST[1,6] ,HR_6_0k.ST[1,6] ,HR_7_0k.ST[1,6] ,HR_8_0k.ST[1,6] ,HR_9_0k.ST[1,6] , HR_10_0k.ST[1,6],HR_12_5k.ST[1,6],HR_15_0k.ST[1,6],HR_17_5k.ST[1,6],HR_20_0k.ST[1,6],HR_25_0k.ST[1,6],HR_30_0k.ST[1,6], HR_35_0k.ST[1,6],HR_40_0k.ST[1,6],HR_45_0k.ST[1,6],  HR_50_0k.ST[1,6],  HR_55_0k.ST[1,6],  HR_60_0k.ST[1,6],  HR_65_0k.ST[1,6],  HR_70_0k.ST[1,6],  HR_75_0k.ST[1,6],  HR_80_0k.ST[1,6],  HR_85_0k.ST[1,6],  HR_90_0k.ST[1,6],  HR_95_0k.ST[1,6],  HR_100_0k.ST[1,6],  HR_105_0k.ST[1,6],  HR_110_0k.ST[1,6],  HR_115_0k.ST[1,6],  HR_120_0k.ST[1,6],  HR_125_0k.ST[1,6],  HR_130_0k.ST[1,6],  HR_135_0k.ST[1,6],  HR_140_0k.ST[1,6],  HR_145_0k.ST[1,6],  HR_150_0k.ST[1,6]]
        
            PSV_HR_ST = [HR_0_1k.ST[3,6], HR_0_2k.ST[3,6],HR_0_3k.ST[3,6] ,HR_0_4k.ST[3,6] ,HR_0_5k.ST[3,6] ,HR_0_6k.ST[3,6] , HR_0_7k.ST[3,6] ,HR_0_8k.ST[3,6] ,HR_0_9k.ST[3,6] ,HR_1_0k.ST[3,6] ,HR_1_2k.ST[3,6] ,HR_1_4k.ST[3,6] ,HR_1_6k.ST[3,6] , HR_1_8k.ST[3,6] ,HR_2_0k.ST[3,6] ,HR_2_3k.ST[3,6] ,HR_2_6k.ST[3,6] ,HR_2_9k.ST[3,6] ,HR_3_0k.ST[3,6] ,HR_3_5k.ST[3,6] , HR_4_0k.ST[3,6] ,HR_4_5k.ST[3,6] ,HR_5_0k.ST[3,6] ,HR_6_0k.ST[3,6] ,HR_7_0k.ST[3,6] ,HR_8_0k.ST[3,6] ,HR_9_0k.ST[3,6] , HR_10_0k.ST[3,6],HR_12_5k.ST[3,6],HR_15_0k.ST[3,6],HR_17_5k.ST[3,6],HR_20_0k.ST[3,6],HR_25_0k.ST[3,6],HR_30_0k.ST[3,6], HR_35_0k.ST[3,6],HR_40_0k.ST[3,6],HR_45_0k.ST[3,6],  HR_50_0k.ST[3,6],  HR_55_0k.ST[3,6],  HR_60_0k.ST[3,6],  HR_65_0k.ST[3,6],  HR_70_0k.ST[3,6],  HR_75_0k.ST[3,6],  HR_80_0k.ST[3,6],  HR_85_0k.ST[3,6],  HR_90_0k.ST[3,6],  HR_95_0k.ST[3,6],  HR_100_0k.ST[3,6],  HR_105_0k.ST[3,6],  HR_110_0k.ST[3,6],  HR_115_0k.ST[3,6],  HR_120_0k.ST[3,6],  HR_125_0k.ST[3,6],  HR_130_0k.ST[3,6],  HR_135_0k.ST[3,6],  HR_140_0k.ST[3,6],  HR_145_0k.ST[3,6],  HR_150_0k.ST[3,6]]
        end

        ## No HR errors for CO PSV PLV ST ##
        begin
            CO_HR_ST_E = [HR_0_1k.ST_Conf_Int[9,6], HR_0_2k.ST_Conf_Int[9,6],HR_0_3k.ST_Conf_Int[9,6] ,HR_0_4k.ST_Conf_Int[9,6] ,HR_0_5k.ST_Conf_Int[9,6] ,HR_0_6k.ST_Conf_Int[9,6] ,  HR_0_7k.ST_Conf_Int[9,6] ,HR_0_8k.ST_Conf_Int[9,6] ,HR_0_9k.ST_Conf_Int[9,6] ,HR_1_0k.ST_Conf_Int[9,6] ,HR_1_2k.ST_Conf_Int[9,6] ,HR_1_4k.ST_Conf_Int[9,6] ,HR_1_6k.ST_Conf_Int[9,6] ,  HR_1_8k.ST_Conf_Int[9,6] ,HR_2_0k.ST_Conf_Int[9,6] ,HR_2_3k.ST_Conf_Int[9,6] ,HR_2_6k.ST_Conf_Int[9,6] ,HR_2_9k.ST_Conf_Int[9,6] ,HR_3_0k.ST_Conf_Int[9,6] ,HR_3_5k.ST_Conf_Int[9,6] ,  HR_4_0k.ST_Conf_Int[9,6] ,HR_4_5k.ST_Conf_Int[9,6] ,HR_5_0k.ST_Conf_Int[9,6] ,HR_6_0k.ST_Conf_Int[9,6] ,HR_7_0k.ST_Conf_Int[9,6] ,HR_8_0k.ST_Conf_Int[9,6] ,HR_9_0k.ST_Conf_Int[9,6] ,  HR_10_0k.ST_Conf_Int[9,6],HR_12_5k.ST_Conf_Int[9,6],HR_15_0k.ST_Conf_Int[9,6],HR_17_5k.ST_Conf_Int[9,6],HR_20_0k.ST_Conf_Int[9,6],HR_25_0k.ST_Conf_Int[9,6],HR_30_0k.ST_Conf_Int[9,6],  HR_35_0k.ST_Conf_Int[9,6],HR_40_0k.ST_Conf_Int[9,6],HR_45_0k.ST_Conf_Int[9,6],  HR_50_0k.ST_Conf_Int[9,6],  HR_55_0k.ST_Conf_Int[9,6],  HR_60_0k.ST_Conf_Int[9,6],  HR_65_0k.ST_Conf_Int[9,6],  HR_70_0k.ST_Conf_Int[9,6],  HR_75_0k.ST_Conf_Int[9,6],  HR_80_0k.ST_Conf_Int[9,6],  HR_85_0k.ST_Conf_Int[9,6],  HR_90_0k.ST_Conf_Int[9,6],  HR_95_0k.ST_Conf_Int[9,6],  HR_100_0k.ST_Conf_Int[9,6],  HR_105_0k.ST_Conf_Int[9,6],  HR_110_0k.ST_Conf_Int[9,6],  HR_115_0k.ST_Conf_Int[9,6],  HR_120_0k.ST_Conf_Int[9,6],  HR_125_0k.ST_Conf_Int[9,6],  HR_130_0k.ST_Conf_Int[9,6],  HR_135_0k.ST_Conf_Int[9,6],  HR_140_0k.ST_Conf_Int[9,6],  HR_145_0k.ST_Conf_Int[9,6],  HR_150_0k.ST_Conf_Int[9,6]]
        
            PLV_HR_ST_E = [HR_0_1k.ST_Conf_Int[1,6], HR_0_2k.ST_Conf_Int[1,6],HR_0_3k.ST_Conf_Int[1,6] ,HR_0_4k.ST_Conf_Int[1,6] ,HR_0_5k.ST_Conf_Int[1,6] ,HR_0_6k.ST_Conf_Int[1,6] , HR_0_7k.ST_Conf_Int[1,6] ,HR_0_8k.ST_Conf_Int[1,6] ,HR_0_9k.ST_Conf_Int[1,6] ,HR_1_0k.ST_Conf_Int[1,6] ,HR_1_2k.ST_Conf_Int[1,6] ,HR_1_4k.ST_Conf_Int[1,6] ,HR_1_6k.ST_Conf_Int[1,6] , HR_1_8k.ST_Conf_Int[1,6] ,HR_2_0k.ST_Conf_Int[1,6] ,HR_2_3k.ST_Conf_Int[1,6] ,HR_2_6k.ST_Conf_Int[1,6] ,HR_2_9k.ST_Conf_Int[1,6] ,HR_3_0k.ST_Conf_Int[1,6] ,HR_3_5k.ST_Conf_Int[1,6] , HR_4_0k.ST_Conf_Int[1,6] ,HR_4_5k.ST_Conf_Int[1,6] ,HR_5_0k.ST_Conf_Int[1,6] ,HR_6_0k.ST_Conf_Int[1,6] ,HR_7_0k.ST_Conf_Int[1,6] ,HR_8_0k.ST_Conf_Int[1,6] ,HR_9_0k.ST_Conf_Int[1,6] , HR_10_0k.ST_Conf_Int[1,6],HR_12_5k.ST_Conf_Int[1,6],HR_15_0k.ST_Conf_Int[1,6],HR_17_5k.ST_Conf_Int[1,6],HR_20_0k.ST_Conf_Int[1,6],HR_25_0k.ST_Conf_Int[1,6],HR_30_0k.ST_Conf_Int[1,6], HR_35_0k.ST_Conf_Int[1,6],HR_40_0k.ST_Conf_Int[1,6],HR_45_0k.ST_Conf_Int[1,6],  HR_50_0k.ST_Conf_Int[1,6],  HR_55_0k.ST_Conf_Int[1,6],  HR_60_0k.ST_Conf_Int[1,6],  HR_65_0k.ST_Conf_Int[1,6],  HR_70_0k.ST_Conf_Int[1,6],  HR_75_0k.ST_Conf_Int[1,6],  HR_80_0k.ST_Conf_Int[1,6],  HR_85_0k.ST_Conf_Int[1,6],  HR_90_0k.ST_Conf_Int[1,6],  HR_95_0k.ST_Conf_Int[1,6],  HR_100_0k.ST_Conf_Int[1,6],  HR_105_0k.ST_Conf_Int[1,6],  HR_110_0k.ST_Conf_Int[1,6],  HR_115_0k.ST_Conf_Int[1,6],  HR_120_0k.ST_Conf_Int[1,6],  HR_125_0k.ST_Conf_Int[1,6],  HR_130_0k.ST_Conf_Int[1,6],  HR_135_0k.ST_Conf_Int[1,6],  HR_140_0k.ST_Conf_Int[1,6],  HR_145_0k.ST_Conf_Int[1,6],  HR_150_0k.ST_Conf_Int[1,6]]
        
            PSV_HR_ST_E = [HR_0_1k.ST_Conf_Int[3,6], HR_0_2k.ST_Conf_Int[3,6],HR_0_3k.ST_Conf_Int[3,6] ,HR_0_4k.ST_Conf_Int[3,6] ,HR_0_5k.ST_Conf_Int[3,6] ,HR_0_6k.ST_Conf_Int[3,6] , HR_0_7k.ST_Conf_Int[3,6] ,HR_0_8k.ST_Conf_Int[3,6] ,HR_0_9k.ST_Conf_Int[3,6] ,HR_1_0k.ST_Conf_Int[3,6] ,HR_1_2k.ST_Conf_Int[3,6] ,HR_1_4k.ST_Conf_Int[3,6] ,HR_1_6k.ST_Conf_Int[3,6] , HR_1_8k.ST_Conf_Int[3,6] ,HR_2_0k.ST_Conf_Int[3,6] ,HR_2_3k.ST_Conf_Int[3,6] ,HR_2_6k.ST_Conf_Int[3,6] ,HR_2_9k.ST_Conf_Int[3,6] ,HR_3_0k.ST_Conf_Int[3,6] ,HR_3_5k.ST_Conf_Int[3,6] , HR_4_0k.ST_Conf_Int[3,6] ,HR_4_5k.ST_Conf_Int[3,6] ,HR_5_0k.ST_Conf_Int[3,6] ,HR_6_0k.ST_Conf_Int[3,6] ,HR_7_0k.ST_Conf_Int[3,6] ,HR_8_0k.ST_Conf_Int[3,6] ,HR_9_0k.ST_Conf_Int[3,6] , HR_10_0k.ST_Conf_Int[3,6],HR_12_5k.ST_Conf_Int[3,6],HR_15_0k.ST_Conf_Int[3,6],HR_17_5k.ST_Conf_Int[3,6],HR_20_0k.ST_Conf_Int[3,6],HR_25_0k.ST_Conf_Int[3,6],HR_30_0k.ST_Conf_Int[3,6], HR_35_0k.ST_Conf_Int[3,6],HR_40_0k.ST_Conf_Int[3,6],HR_45_0k.ST_Conf_Int[3,6],  HR_50_0k.ST_Conf_Int[3,6],  HR_55_0k.ST_Conf_Int[3,6],  HR_60_0k.ST_Conf_Int[3,6],  HR_65_0k.ST_Conf_Int[3,6],  HR_70_0k.ST_Conf_Int[3,6],  HR_75_0k.ST_Conf_Int[3,6],  HR_80_0k.ST_Conf_Int[3,6],  HR_85_0k.ST_Conf_Int[3,6],  HR_90_0k.ST_Conf_Int[3,6],  HR_95_0k.ST_Conf_Int[3,6],  HR_100_0k.ST_Conf_Int[3,6],  HR_105_0k.ST_Conf_Int[3,6],  HR_110_0k.ST_Conf_Int[3,6],  HR_115_0k.ST_Conf_Int[3,6],  HR_120_0k.ST_Conf_Int[3,6],  HR_125_0k.ST_Conf_Int[3,6],  HR_130_0k.ST_Conf_Int[3,6],  HR_135_0k.ST_Conf_Int[3,6],  HR_140_0k.ST_Conf_Int[3,6],  HR_145_0k.ST_Conf_Int[3,6],  HR_150_0k.ST_Conf_Int[3,6]]
        end

        # High and Low errors No HR ST #
        # Cardiac Output
        LowE_CO_HR_ST = CO_HR_ST .- (1.96 .*CO_HR_ST_E)
        HighE_CO_HR_ST = CO_HR_ST .+ (1.96 .*CO_HR_ST_E)
        # Max PLV
        LowE_PLV_HR_ST = PLV_HR_ST .- (1.96 .*PLV_HR_ST_E)
        HighE_PLV_HR_ST = PLV_HR_ST .+ (1.96 .*PLV_HR_ST_E)
        # Max PSV
        LowE_PSV_HR_ST = PSV_HR_ST .- (1.96 .*PSV_HR_ST_E)
        HighE_PSV_HR_ST = PSV_HR_ST .+ (1.96 .*PSV_HR_ST_E)
    end
    #CO ST R
    band!(x[1:end], min.(LowE_CO_HR_ST, HighE_CO_HR_ST), max.(LowE_CO_HR_ST, HighE_CO_HR_ST), color=(:blue, 0.5),  transparency=true)
    lines!(x[1:end], CO_HR_ST, label = L"\text{Cardiac~Output}")
    #PLV ST R
    band!(x[1:end], min.(LowE_PLV_HR_ST, HighE_PLV_HR_ST), max.(LowE_PLV_HR_ST, HighE_PLV_HR_ST), color=(:red, 0.5),  transparency=true)
    lines!(x[1:end], PLV_HR_ST, label = L"\text{Max}(P_{lv})")
    #PSV ST R
    band!(x[1:end], min.(LowE_PSV_HR_ST, HighE_PSV_HR_ST), max.(LowE_PSV_HR_ST, HighE_PSV_HR_ST), color=(:green, 0.5),  transparency=true)
    lines!(x[1:end], PSV_HR_ST, label = L"\text{Max}(P_{sv})")
    #hidedecorations!(axt, grid = false)

    f[7, 1:4] = Legend(f, axt, orientation = :horizontal)

    #linkaxes!(axa,axb,axc,axd,axe,axf,axg,axh,axi,axj,axk,axl,axm,axn,axo,axp,axq,axr,axs,axt)
    for (label, layout) in zip(["A", "B", "C", "D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T"], [ga, gb, gc, gd,ge,gf,gg,gh,gi,gj,gk,gl,gm,gn,go,gp,gq,gr,gs,gt])
        Label(layout[1, 1, TopRight()], label,fontsize = 18,font = :bold,halign = :right)
    end

    resize_to_layout!(f)

    f
end

