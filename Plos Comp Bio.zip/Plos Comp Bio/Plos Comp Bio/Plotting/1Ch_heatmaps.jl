using  JLD, GlobalSensitivity,CairoMakie

Reg_S1 = load("150k.jld")["data"].S1
Reg_ST = load("150k.jld")["data"].ST

HR_150_0k = load("150k_HR.jld")["data"]

HR_150_0k.S1 = HR_150_0k.S1[:,[5,6,7,4,3,1,2,8,9]]
HR_150_0k.ST = HR_150_0k.ST[:,[5,6,7,4,3,1,2,8,9]]

R_M = [L"\text{Max}(P_{lv})", L"\text{Min}(P_{lv})", L"\text{Max}(P_{sa})", L"\text{Min}(P_{sa})", L"\text{Max}(P_{sv})", L"\text{Min}(P_{sv})", L"\text{Max}(V_{lv})", L"\text{Min}(V_{lv})", L"R_{\tau}", L"\text{CO}"]
HR_M = [L"\text{Max}(P_{lv})", L"\text{Min}(P_{lv})", L"\text{Max}(P_{sa})", L"\text{Min}(P_{sa})", L"\text{Max}(P_{sv})", L"\text{Min}(P_{sv})", L"\text{Max}(V_{lv})", L"\text{Min}(V_{lv})",L"\text{CO}"]

HR_P = [L"R_{s}", L"C_{sa}", L"C_{sv}", L"R_{av}",L"R_{mv}", L"τ_{es}", L"τ_{ep}",    L"E_{max}", L"E_{min}"]
R_P =  [L"R_{s}", L"C_{sa}", L"C_{sv}", L"R_{av}",L"R_{mv}", L"\tau",L"\tau_{es}",L"\tau_{ep}",L"E_{max}",L"E_{min}",L"P_{n}",L"K_{a}",L"F_{min}",L"F_{max}",L"\tau_{z}",L"\tau_p",L"Fes_{\infty}",L"Fes_{0}",L"Fes_{min}",L"K_{es}",L"Fev_{0}",L"Fev_{\infty}",L"Fcs_{0}",L"K_{ev}",L"G_{E}",L"\tau_{E}",L"D_{E}",L"G_{R}",L"\tau_{R}",L"D_{R}",L"G_{\tau_{s}}",L"\tau_{\tau_{s}}",L"D_{\tau_{s}}",L"G_{\tau_{v}}",L"\tau_{\tau_{v}}",L"D_{\tau_{v}}"]
                                                                                                                                                                                                                                                                               



#(1:10, [L"\tau_{es}", L"\tau_{ep}", L"R_{mv}", L"Z_{ao}", L"R_{s}", L"C_{sa}", L"C_{sv}", L"E_{max}", L"E_{min}"])
a = begin
    f = Figure(size = (1100,1100), backgroundcolor = RGBf(0.98, 0.98, 0.98))

    joint_limits = (0.0,1.0)
    ax1 = Axis(f[1,1], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:10, R_M), yticks = (1:36, R_P))
    Label(f[1, 1, TopLeft()], "A",fontsize = 18,font = :bold,halign = :right)
    Label(f[1, 1, Top()], "First Order",fontsize = 18,font = :bold,halign = :center)
    Label(f[1, 1, Left()], "Regulated Model",fontsize = 18,font = :bold,halign = :right, rotation = π/2, padding = (0,45,0,0))

    hm1 = CairoMakie.heatmap!(ax1,Reg_S1, colorrange = joint_limits, colormap=:gnuplot2)

    ax2 = Axis(f[2,1], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:9, HR_M), yticks = (1:9, HR_P))
    Label(f[2, 1, Left()], "Fixed HR",fontsize = 18,font = :bold,halign = :right, rotation = π/2, padding = (0,40,0,0))
    Label(f[2, 1, TopLeft()], "B",fontsize = 18,font = :bold,halign = :right)
    hm2 = CairoMakie.heatmap!(ax2,HR_150_0k.S1, colorrange = joint_limits, colormap=:gnuplot2)

    ax3 = Axis(f[1,2], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:10, R_M), yticks = (1:36, R_P))
    Label(f[1, 2, TopLeft()], "C",fontsize = 18,font = :bold,halign = :right)
    Label(f[1, 2, Top()], "Total Order",fontsize = 18,font = :bold,halign = :center)
    hm3 = CairoMakie.heatmap!(ax3, Reg_ST, colorrange = joint_limits, colormap=:gnuplot2)

    ax4 = Axis(f[2,2], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:9, HR_M), yticks = (1:9, HR_P))
    Label(f[2, 2, TopLeft()], "D",fontsize = 18,font = :bold,halign = :right)
    hm4 = CairoMakie.heatmap!(ax4,HR_150_0k.ST, colorrange = joint_limits, colormap=:gnuplot2)
   
    ax5 = Axis(f[1,3], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:10, R_M), yticks = (1:36, R_P))
    Label(f[1, 3, TopLeft()], "E",fontsize = 18,font = :bold,halign = :right)
    Label(f[1, 3, Top()], "Higher Order",fontsize = 18,font = :bold,halign = :center)
    hm5 = CairoMakie.heatmap!(ax5,(Reg_ST - Reg_S1), colorrange = joint_limits, colormap=:gnuplot2)


    ax6 = Axis(f[2,3], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:9, HR_M), yticks = (1:9, HR_P))
    Label(f[2, 3, TopLeft()], "F",fontsize = 18,font = :bold,halign = :right)
    hm6 = CairoMakie.heatmap!(ax6,(HR_150_0k.ST - HR_150_0k.S1), colorrange = joint_limits, colormap=:gnuplot2)

    Colorbar(f[:, end+1], hm1, colorrange = joint_limits, ticks = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])    

    f
end 
save("1_Cham.pdf",a)
