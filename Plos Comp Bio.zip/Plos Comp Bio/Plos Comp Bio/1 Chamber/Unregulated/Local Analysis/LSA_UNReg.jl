@time "Setup modules" using DifferentialEquations, Statistics, QuasiMonteCarlo, JLD, GlobalSensitivity, LinearAlgebra

function Valve(R, deltaP, open)
    dq = 0.0
    if (-open) < 0.0 
        dq =  deltaP/R
    else
        dq = 0.0
    end
    return dq

end

function ShiElastance(t, Eₘᵢₙ, Eₘₐₓ, τ, τₑₛ, τₑₚ, Eshift)
    τₑₛ = τₑₛ*τ
    τₑₚ = τₑₚ*τ
    #τ = 4/3(τₑₛ+τₑₚ)
    tᵢ = rem(t + (1 - Eshift) * τ, τ)

    Eₚ = (tᵢ <= τₑₛ) * (1 - cos(tᵢ / τₑₛ * pi)) / 2 +
         (tᵢ > τₑₛ) * (tᵢ <= τₑₚ) * (1 + cos((tᵢ - τₑₛ) / (τₑₚ - τₑₛ) * pi)) / 2 +
         (tᵢ <= τₑₚ) * 0

    E = Eₘᵢₙ + (Eₘₐₓ - Eₘᵢₙ) * Eₚ

    return E
end

function DShiElastance(t, Eₘᵢₙ, Eₘₐₓ, τ, τₑₛ, τₑₚ, Eshift)

    τₑₛ = τₑₛ*τ
    τₑₚ = τₑₚ*τ
    #τ = 4/3(τₑₛ+τₑₚ)
    tᵢ = rem(t + (1 - Eshift) * τ, τ)

    DEₚ = (tᵢ <= τₑₛ) * pi / τₑₛ * sin(tᵢ / τₑₛ * pi) / 2 +
          (tᵢ > τₑₛ) * (tᵢ <= τₑₚ) * pi / (τₑₚ - τₑₛ) * sin((τₑₛ - tᵢ) / (τₑₚ - τₑₛ) * pi) / 2
    (tᵢ <= τₑₚ) * 0
    DE = (Eₘₐₓ - Eₘᵢₙ) * DEₚ

    return DE
end

#Shi timing parameters
Eshift = 0.0
Eₘᵢₙ = 0.03
τₑₛ = 0.3
τₑₚ = 0.45 
Eₘₐₓ = 1.5
Rmv = 0.006
τ = 0.906
 
function NIK!(du, u, p, t)
    pLV, psa, psv, Vlv, Qav, Qmv, Qs = u 
    τₑₛ, τₑₚ, Rmv, Zao, Rs, Csa, Csv, Eₘₐₓ, Eₘᵢₙ = p
    # pressures (more readable names)
# the differential equations
    du[1] = (Qmv - Qav) * ShiElastance(t, Eₘᵢₙ, Eₘₐₓ, τ, τₑₛ, τₑₚ, Eshift) + pLV / ShiElastance(t, Eₘᵢₙ, Eₘₐₓ, τ, τₑₛ, τₑₚ, Eshift) * DShiElastance(t, Eₘᵢₙ, Eₘₐₓ, τ, τₑₛ, τₑₚ, Eshift)
    # 1 Left Ventricle
    du[2] = (Qav - Qs ) / Csa #Systemic arteries     
    du[3] = (Qs - Qmv) / Csv # Venous
    du[4] = Qmv - Qav # volume
    du[5]    = Valve(Zao, (du[1] - du[2]), u[1] - u[2])  # AV 
    du[6]   = Valve(Rmv, (du[3] - du[1]), u[3] - u[1])  # MV
    du[7]     = (du[2] - du[3]) / Rs # Systemic flow
end
##

u0 = [5.2, 5.2, 5.2, 160.0, 0.0, 0.0, 0.0]

p = [0.3, 0.45, 0.06, 0.033, 2.386, 1.13, 11.0, 2.48, 0.03]

tspan = (0, 20)

prob = ODEProblem(NIK!, u0, tspan, p)

x = LinRange(16,19,200)
@btime sol = solve(prob, Vern7(),  reltol = 1e-5, abstol = 1e-5, saveat = x)


function circ_local(p)
    _prob = ODEProblem(NIK!, [5.2, 5.2, 5.2, 160.0, 0.0, 0.0, 0.0], (0.0,20.0), p)
    newsol = solve(_prob, Vern7(),  reltol = 1e-12, abstol = 1e-12, saveat = x)
    [maximum(newsol[1,:]), #max lvp
    minimum(newsol[1,:]), #min lvp
    maximum(newsol[2,:]), #max SAp
    minimum(newsol[2,:]), #min SAp
    maximum(newsol[3,:]), #max SV P
    minimum(newsol[3,:]), #min SV P
    maximum(newsol[4,:]), #Max LVV
    minimum(newsol[4,:]), #Min LVV
    (maximum(newsol[4,:]) - minimum(newsol[4,:]))*(0.906)] #CO]
end
# SV LV, PP LV, PP SA, Mean systemic flow 

## Absoloute sensititivty
using FiniteDiff
s = FiniteDiff.finite_difference_jacobian(circ_local, [0.3, 0.45, 0.06, 0.033, 2.386, 1.13, 11.0, 2.48, 0.03])
## Make relative by scaling by p/y 
@time sol = solve(prob, Vern7(),  reltol = 1e-12, abstol = 1e-12, saveat = x)
measurements =     [maximum(sol[1,:]), #max lvp
minimum(sol[1,:]), #min lvp
maximum(sol[2,:]), #max SAp
minimum(sol[2,:]), #min SAp
maximum(sol[3,:]), #max SV P
minimum(sol[3,:]), #min SV P
maximum(sol[4,:]), #Max LVV
minimum(sol[4,:]), #Min LVV
(maximum(sol[4,:]) - minimum(sol[4,:]))*(0.906)] #CO]

S = Matrix{Float64}(undef,9,9)
for i in 1:9
    for j in 1:9
        S[i,j] = (prob.p[j]/measurements[i]) * s[i,j]
    end 
end

# Relative normalised sensititivty matrix 
S = abs.(S)/maximum(S)

S = S[:,[5,6,7,4,3,1,2,8,9]]

save("S1UR.jld", "data", S)

using CairoMakie
HR_M = [L"\text{Max}(P_{LV})", L"\text{Min}(P_{LV})", L"\text{Max}(P_{A})", L"\text{Min}(P_{A})", L"\text{Max}(P_{V})", L"\text{Min}(P_{V})", L"\text{Max}(V_{LV})", L"\text{Min}(V_{LV})",L"\text{CO}"]
HR_P = [L"R_{sys}", L"C_{art}", L"C_{ven}", L"r_{av}",L"r_{mv}", L"τ_{S1}", L"τ_{S2}",    L"E_{LVmax}", L"E_{LVmin}"]
#CairoMakie.activate!(type = "svg")
## Relative Sensitivity Matrix 
f = Figure();
# to add axis we specify a position in the figures layout as first argument f[1,1] to fill the whole plot 
ax = Axis(f[1,1], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:9, HR_M), yticks = (1:9, HR_P))
Label(f[1, 1, Left()], "Fixed HR",fontsize = 18,font = :bold,halign = :right, rotation = π/2, padding = (0,40,0,0))
Label(f[1, 1, TopLeft()], "B",fontsize = 18,font = :bold,halign = :right)
hm = CairoMakie.heatmap!(ax,S,  colormap=:gnuplot2)
for i in 1:9, j in 1:9
    txtcolor = S[i, j] < -1000.0 ? :white : :black
    text!(ax, "$(round(S[i,j], digits = 2))", position = (i, j),
        color = txtcolor, align = (:center, :center), fontsize = 12)
end
Colorbar(f[1,2],hm)
f
