#%% Libraries
using DifferentialEquations
using Plots


#%% Turn on/off baroreflex (resistance control only)
REGswitch       = 1;                                 # 0 - off;  1 - on

#%% Time and initial pressure data
dt              = 0.1;                                 # time step
T_init          = 0;                                 # initial time
T_max           = 200;                               # duration of simulation
tRange          = T_init : dt : T_max;               # time range
tspan           = (T_init, T_max);

R0              = 1.663;                                 # Kamoi
C_art           = 1.13;                                  # Bjordalsbakke
C_ven           = 11.0;                                  # Bjordalsbakke

#%% Heart data
HT0             = 0.580;                             # heart period: inital value (Ursino, table 2)
rav             = 0.033;                             # aortic valve resistance (Bjordalsbakke)
rmv             = 0.06;                              # mitral valve resistance (Bjordalsbakke)
tauinitLV       = 0.00;                              # initialise the cycle (Bjordalsbakke)
tauS1LV         = 0.30;                              # systolic tau (Bjordalsbakke)
tauS2LV         = 0.45;                              # diastolic tau (Korakianitis)
ELVmax          = 2.00;                              # maximum elastance for LV (Simaan)
ELVmin          = 0.06;                              # minimum elastance for LV (Simaan)
mcfp            = 10.0;                              # mean circulatory filling pressure
init_VLV        = 160.0;                             # initial left ventricular volume
initPressure     = [mcfp, mcfp, mcfp, 100.0, 0.0, 0.0, 0.0, 0.0, init_VLV, HT0, ELVmax, HT0, 0.0]                                        

# Regulation parameters (all from Ursino) according to Table 3
# Afferent pathway
Pn              = 92.0;                            # mmHg, setpoint pressure (value of intrasinus pressure at the central point of sigmoid)
ka              = 11.758;                        # mmHg, parameter related to a slope
fmin            = 2.52;                          # spikes/sec, minimum frequency, sigmoid limiter
fmax            = 47.78;                         # spikes/sec, maximum frequency, sigmoid limiter
tau_z           = 6.37;                          # sec, time constant for the real zero in a linear dynamic block
tau_p           = 2.076;                         # sec, time constant for the real pole in a linear dynamic block

# Sympathetic efferent pathway
fes_inf         = 2.10;                          # spikes/sec, frequency for infinity
fes_0           = 16.11;                         # spikes/sec, frequency for the absence of innervation
fes_min         = 2.66;                          # spikes/sec, minimum frequency for sympathetic efferent path
kes             = 0.0675;                        # sec, parameter for exponential function

# Vagal efferent pathway
fev_0           = 3.2;                           # spikes/sec
fev_inf         = 6.3;                           # spikes/sec
fcs_0           = 25.0;                            # spikes/sec
kev             = 7.06;                          # spikes/sec

# Effectors
gain_ELV        = 0.475;                         # maximum left ventricular elastance control
tau_ELV         = 8.0;
delay_ELV       = 2.0;
ELVmax_0        = 2.392;

gain_Rsp        = 0.695;                         # splanchnic systemic resistance control
tau_Rsp         = 6.0;
delay_Rsp       = 2.0;
Rsp_0           = 2.490;

gain_HTs        =-0.13;                          # heart period sympathetic control
tau_HTs         = 2.0;
delay_HTs       = 2.0;
HTs_0           = 0.580;

gain_HTv        = 0.09;                          # heart period vagal control
tau_HTv         = 1.5;
delay_HTv       = 0.2;

delay           = [delay_HTs, delay_Rsp, delay_ELV, delay_HTv]

# initial sigma vector (see derivation in Ursino)
par = [R0, C_art, C_ven, rav, rmv, HT0, tauS1LV, tauS2LV, ELVmax, ELVmin, Pn, ka, fmin, fmax, tau_z, tau_p, fes_inf, fes_0, fes_min, kes, fev_0, fev_inf, fcs_0, kev, gain_ELV, tau_ELV, delay_ELV, gain_Rsp, tau_Rsp, delay_Rsp, gain_HTs, tau_HTs, delay_HTs, gain_HTv, tau_HTv, delay_HTv]

#%% Functions
# Heaviside function
heaviside(x) = ifelse(x < 0.0, zero(x), ifelse(x > 0.0, one(x), oftype(x,0.5)))

# Valve function
function heartValve(pressureDifference, valveResistance)
    q           = (pressureDifference./valveResistance)     .* (pressureDifference >  0.0) +
    (pressureDifference/1000.0/valveResistance)  .* (pressureDifference <= 0.0);
    return q
end

# Elastance function
function ShiCosineElastance(t, tauinit, tauESvalue, tauSSvalue, ELVmaxValue, ELVminValue, heartRate)
    tauValue    = t * heartRate / 60.0;
    e           = 0.0* (tauValue >= 0.0)*(tauValue < tauinit)   +   (1.0-cos((pi*(tauValue-tauinit))/(tauESvalue-tauinit)))*(tauValue >= tauinit)*(tauValue <= tauESvalue)  +  (1.0+cos(pi*(tauValue-tauESvalue)/(tauSSvalue-tauESvalue)))*(tauValue > tauESvalue)*(tauValue <= tauSSvalue) +   0.0*(tauValue > tauSSvalue);
    e1          = 0.5 * (ELVmaxValue - ELVminValue) * e + ELVminValue;
    
    dedtau      = 0.0 * (tauValue >= 0.0)*(tauValue < tauinit)  +   sin(pi*(tauValue-tauinit)/(tauESvalue-tauinit)) * pi/(tauESvalue-tauinit)*(tauValue >= tauinit)*(tauValue <= tauESvalue)    +   sin(pi*(tauESvalue-tauValue)/(tauESvalue-tauSSvalue))*pi/(tauESvalue-tauSSvalue)*(tauValue > tauESvalue)*(tauValue <= tauSSvalue)    +   0.0*(tauValue > tauSSvalue);
    dedt1       = 0.5 * (ELVmaxValue - ELVminValue) * dedtau * heartRate / 60.0 / 1.0;

    return e1, dedt1
end

# Model function
function model(dPdt:: Vector, P:: Vector, h, p, t)
    R0, C_art, C_ven, rav, rmv, HT0, tauS1LV, tauS2LV, ELVmax, ELVmin, Pn, ka, fmin, fmax, tau_z, tau_p, fes_inf, fes_0, fes_min, kes, fev_0, fev_inf, fcs_0, kev, gain_ELV, tau_ELV, delay_ELV, gain_Rsp, tau_Rsp, delay_Rsp, gain_HTs, tau_HTs, delay_HTs, gain_HTv, tau_HTv, delay_HTv = p;
   
    RspSET      = R0    + P[6]*REGswitch;
    offsetHT    = P[10] - HT0
    offsetELV   = P[11] - ELVmax

    if (t-P[12]) >0                                                    
        P[13]             = t;
        P[12]      = P[12] + P[10];        
    end

    histHTs     = h(p, t-2.0)[4]
    histRsp     = h(p, t-2.0)[4]
    histELV     = h(p, t-2.0)[4]
    histHTv     = h(p, t-0.2)[4]


    ElocalLV, dEdtlocalLV    = ShiCosineElastance(t-P[13], tauinitLV, tauS1LV, tauS2LV, P[11], ELVmin, 60.0/P[10])         # elastance calculations - LV

    # new variables for pressures in the system, to make the set of ODE more clear
    iAV                      = heartValve(P[1]-P[2]  ,rav);                                                                         # flow through aortic valve
    iMV                      = heartValve(P[3]-P[1]  ,rmv);                                                                         # flow through mitral valve

    fcsSymHT        = (fmin + fmax * exp((histHTs-Pn)/ka)) / (1+exp((histHTs-Pn)/ka));
    fcsSymRsp       = (fmin + fmax * exp((histRsp-Pn)/ka)) / (1+exp((histRsp-Pn)/ka));
    fcsSymELV       = (fmin + fmax * exp((histELV-Pn)/ka)) / (1+exp((histELV-Pn)/ka));
    fcsVagHT        = (fmin + fmax * exp((histHTv-Pn)/ka)) / (1+exp((histHTv-Pn)/ka));
      # Ursino: efferent sympathetic frequency calculation
    fesSymHT        = fes_inf   + (fes_0 - fes_inf) .*  exp(-kes*fcsSymHT);
    fesSymRsp       = fes_inf   + (fes_0 - fes_inf) .*  exp(-kes*fcsSymRsp);
    fesSymELV       = fes_inf   + (fes_0 - fes_inf) .*  exp(-kes*fcsSymELV);
    
        # Ursino: efferent parasympathetic (vagal) frequency calculation
    fevPsymHT       = (fev_0 + fev_inf .* exp((fcsVagHT-fcs_0)/kev))./(1+exp((fcsVagHT-fcs_0)/kev));
  
      # Effector control inputs                                                        
    sigma1          = gain_HTs    *   log(fesSymHT - fes_min + 1.0)      *   heaviside(fesSymHT - fes_min);
    sigma2          = gain_Rsp    *   log(fesSymRsp  - fes_min + 1.0)    *   heaviside(fesSymRsp - fes_min);
    sigma3          = gain_ELV    *   log(fesSymELV  - fes_min + 1.0)    *   heaviside(fesSymELV - fes_min);
    sigma4          = gain_HTv    *   fevPsymHT; 
    

    # ODEs
    dPdt[1]        = ElocalLV * (iMV - iAV)   + dEdtlocalLV * P[1] / ElocalLV
    dPdt[2]        =-1.0/(C_art*RspSET)*P[2] + 1.0/(C_art*RspSET)*P[3] + 1.0/C_art*iAV;
    dPdt[3]        = 1.0/(C_ven*RspSET)*P[2] - 1.0/(C_ven*RspSET)*P[3] - 1.0/C_ven*iMV;

    dPdt[4]        = (-P[4] + P[2] + tau_z*dPdt[2])/tau_p;     
    dPdt[5]        = (-P[5] + sigma1)/tau_HTs;                                      
    dPdt[6]        = (-P[6] + sigma2)/tau_Rsp;                                      
    dPdt[7]        = (-P[7] + sigma3)/tau_ELV;                                      
    dPdt[8]        = (-P[8] + sigma4)/tau_HTv;
    dPdt[9]        = (iMV-iAV)
    σ = 0.0001
    dPdt[10]       = exp(-((t-P[13])^(2))/(2.0*σ^2))*(P[5] + P[8] - offsetHT)*sqrt(1.0/(2.0*π))*1.0/σ 
    dPdt[11]       = exp(-((t-P[13])^(2))/(2.0*σ^2))*(P[7]        - offsetELV)*sqrt(1.0/(2.0*π))*1.0/σ 
    #dPdt            = dPdt';
    #return P,t
end



#%% Solution
h(p, t) = ones(4)*100.0
p       = par*1.0
prob    = DDEProblem(model, initPressure,h, tspan, p; constant_lags = delay)
x = LinRange(175,178,500)
@time sol1=solve(prob, MethodOfSteps(Tsit5()), reltol = 1e-12, abstol = 1e-12,saveat = x)


function circ_local(p)
    _prob = DDEProblem(model, [10.0, 10.0, 10.0, 100.0, 0.0, 0.0, 0.0, 0.0, 160.0, p[6], p[9], p[6], 0.0],h, (0.0,200.0), p; constant_lags = delay)
    newsol = solve(_prob, MethodOfSteps(Tsit5()),  reltol = 1e-12, abstol = 1e-12, saveat = x)
        [maximum(newsol[1,:]), #max lvp
    minimum(newsol[1,:]), #min lvp
    maximum(newsol[2,:]), #max SAp
    minimum(newsol[2,:]), #min SAp
    maximum(newsol[3,:]), #max SV P
    minimum(newsol[3,:]), #min SV P
    maximum(newsol[9,:]), #Max LVV
    minimum(newsol[9,:]), #Min LVV
    (p[6] + mean(newsol[5,:]) + mean(newsol[8,:])),
     ((maximum(newsol[9,:]) - minimum(newsol[9,:]))*(p[6] + mean(newsol[5,:]) + mean(newsol[8,:])))]
end
# SV LV, PP LV, PP SA, Mean systemic flow 

## Absoloute sensititivty
using  Statistics, ForwardDiff
s = ForwardDiff.jacobian(circ_local, par*1.0)
## Make relative by scaling by p/y 
@time sol = solve(prob, MethodOfSteps(Tsit5()),  reltol = 1e-12, abstol = 1e-12, saveat = x)
measurements =     [maximum(sol[1,:]), #max lvp
minimum(sol[1,:]), #min lvp
maximum(sol[2,:]), #max SAp
minimum(sol[2,:]), #min SAp
maximum(sol[3,:]), #max SV P
minimum(sol[3,:]), #min SV P
maximum(sol[9,:]), #Max LVV
minimum(sol[9,:]), #Min LVV
(p[6] + mean(sol[5,:]) + mean(sol[8,:])),
 ((maximum(sol[9,:]) - minimum(sol[9,:]))*(p[6] + mean(sol[5,:]) + mean(sol[8,:])))]

S = Matrix{Float64}(undef,10,36)
for i in 1:10
    for j in 1:36
        S[i,j] = (prob.p[j]/measurements[i]) * s[i,j]
    end 
end

# Relative normalised sensitivity matrix 
S = abs.(S)/maximum(S)

save("S1R.jld", "data", S)

using CairoMakie
R_M = [L"\text{Max}(P_{lv})", L"\text{Min}(P_{lv})", L"\text{Max}(P_{A})", L"\text{Min}(P_{A})", L"\text{Max}(P_{V})", L"\text{Min}(P_{V})", L"\text{Max}(V_{LV})", L"\text{Min}(V_{LV})", L"\tau_{HR}", L"\text{CO}"]
R_P =  [L"R_{sys}", L"C_{art}", L"C_{ven}", L"r_{av}",L"r_{mv}", L"\tau_{HR}",L"\tau_{S1}",L"\tau_{S2}",L"E_{LVmax}",L"E_{LVmin}",L"P_{n}",L"k_{a}",L"f_{min}",L"f_{max}",L"\tau_{z}",L"\tau_p",L"f_{es,\infty}",L"f_{es,0}",L"f_{es,min}",L"k_{es}",L"f_{ev,0}",L"f_{ev,\infty}",L"f_{cs,0}",L"k_{ev}",L"G_{ELV}",L"\tau_{ELV}",L"D_{ELV}",L"G_{R}",L"\tau_{R}",L"D_{R}",L"G_{\tau_{s}}",L"\tau_{\tau_{s}}",L"D_{\tau_{s}}",L"G_{\tau_{v}}",L"\tau_{\tau_{v}}",L"D_{\tau_{v}}"]
#CairoMakie.activate!(type = "svg")

## Relative Sensitivity Matrix 
f = Figure();
# to add axis we specify a position in the figures layout as first argument f[1,1] to fill the whole plot 
ax = Axis(f[1,1], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:10, R_M), yticks = (1:36, R_P))
Label(f[1, 1, Left()], "Regulated",fontsize = 18,font = :bold,halign = :right, rotation = π/2, padding = (0,40,0,0))
Label(f[1, 1, TopLeft()], "B",fontsize = 18,font = :bold,halign = :right)
hm = CairoMakie.heatmap!(ax,S,  colormap=:gnuplot2)
for i in 1:10, j in 1:36
    txtcolor = S[i, j] < -1000.0 ? :white : :black
    text!(ax, "$(round(S[i,j], digits = 2))", position = (i, j),
        color = txtcolor, align = (:center, :center), fontsize = 12)
end
Colorbar(f[1,2],hm)
f
