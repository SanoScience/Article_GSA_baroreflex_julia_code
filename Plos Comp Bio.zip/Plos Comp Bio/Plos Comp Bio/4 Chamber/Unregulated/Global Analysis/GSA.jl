using Pkg

Pkg.add("ModelingToolkit")
Pkg.add("DifferentialEquations")
Pkg.add("Statistics")
Pkg.add("CirculatorySystemModels")
Pkg.add("JLD")

using ModelingToolkit, DifferentialEquations, Statistics, CirculatorySystemModels, JLD


println("Running on ", Threads.nthreads(), " threads.")

## Components ##
@component function Compliance_(; name, C=1.0)
    @named in = Pin()
    @named out = Pin()

    sts = @variables begin
            V(t) = 0.0
            p(t) = 0.0
    end

    ps = @parameters begin
            C = C
    end

    # Add the thoracic pressure variant

    D = Differential(t)
    V₀ = 0.0
    eqs = [
            0 ~ in.p - out.p
            p ~ in.p
            V ~ (p - 0.0) * C + V₀
            D(p) ~ (in.q + out.q) * 1 / C
    ]

    compose(ODESystem(eqs, t, sts, ps; name=name), in, out)
end

### Ventricles ##

function ShiElastance_V(t, Eₘᵢₙ, Eₘₐₓ)

    τ = 0.908
    τₑₛ = 0.30
    τₑₚ = 0.45
    tᵢ = rem(t + (1.0) * τ, τ)
    Eₚ = (tᵢ <= τₑₛ) * (1 - cos(tᵢ / τₑₛ * pi)) / 2 +
         (tᵢ > τₑₛ) * (tᵢ <= τₑₚ) * (1 + cos((tᵢ - τₑₛ) / (τₑₚ - τₑₛ) * pi)) / 2 +
         (tᵢ <= τₑₚ) * 0

    E = Eₘᵢₙ + (Eₘₐₓ - Eₘᵢₙ) * Eₚ

    return E
end

function DShiElastance_V(t, Eₘᵢₙ, Eₘₐₓ)

    τ = 0.908
    τₑₛ = 0.30
    τₑₚ = 0.45
    tᵢ = rem(t + (1.0) * τ, τ)
    DEₚ = (tᵢ <= τₑₛ) * pi / τₑₛ * sin(tᵢ / τₑₛ * pi) / 2 +
          (tᵢ > τₑₛ) * (tᵢ <= τₑₚ) * pi / (τₑₚ - τₑₛ) * sin((τₑₛ - tᵢ) / (τₑₚ - τₑₛ) * pi) / 2
    (tᵢ <= τₑₚ) * 0
    DE = (Eₘₐₓ - Eₘᵢₙ) * DEₚ

    return DE
end


@component function ShiChamber_V(; name, Eₘᵢₙ, Eₘₐₓ)
    @named in = Pin()
    @named out = Pin()
    sts = @variables V(t) = 0.0 p(t) = 0.0
    ps = @parameters Eₘᵢₙ = Eₘᵢₙ Eₘₐₓ = Eₘₐₓ

    D = Differential(t)
    E = ShiElastance_V(t, Eₘᵢₙ, Eₘₐₓ)
    DE = DShiElastance_V(t, Eₘᵢₙ, Eₘₐₓ)

    p_rel = 0.0
    V₀ = 0.0
    τ = 0.908

    eqs = [
            0 ~ in.p - out.p
            p ~ in.p
            V ~ (p - p_rel) / E + V₀
            D(p) ~ (in.q + out.q) * E + (p - p_rel) / E * DE
        ]

    compose(ODESystem(eqs, t, sts, ps; name=name), in, out)
end

## Atria ##

function ShiElastance_A(t, ELVmaxValue, ELVminValue)

    τ = 0.908
    heartRate = 60/τ
    tauinit = 0.92
    tauESvalue = 0.96
    tauSSvalue = 1.00
    t           = rem(t,60 / heartRate);
    tauValue    = t * heartRate / 60.0;

    e           = 0.0* (tauValue >= 0.0)*(tauValue < tauinit)   +   (1.0-cos((pi*(tauValue-tauinit))/(tauESvalue-tauinit)))*(tauValue >= tauinit)*(tauValue <= tauESvalue)  +  (1.0+cos(pi*(tauValue-tauESvalue)/(tauSSvalue-tauESvalue)))*(tauValue > tauESvalue)*(tauValue <= tauSSvalue) +   0.0*(tauValue > tauSSvalue);
    e1          = 0.5 * (ELVmaxValue - ELVminValue) * e + ELVminValue;  
    return e1
end

function DShiElastance_A(t, ELVmaxValue, ELVminValue)

    τ = 0.908
    heartRate = 60/τ
    tauinit = 0.92
    tauESvalue = 0.96
    tauSSvalue = 1.00
    t           = rem(t,60 / heartRate);
    tauValue    = t * heartRate / 60.0;

    dedtau      = 0.0 * (tauValue >= 0.0)*(tauValue < tauinit)  +   sin(pi*(tauValue-tauinit)/(tauESvalue-tauinit)) * pi/(tauESvalue-tauinit)*(tauValue >= tauinit)*(tauValue <= tauESvalue)    +   sin(pi*(tauESvalue-tauValue)/(tauESvalue-tauSSvalue))*pi/(tauESvalue-tauSSvalue)*(tauValue > tauESvalue)*(tauValue <= tauSSvalue)    +   0.0*(tauValue > tauSSvalue);
    dedt1       = 0.5 * (ELVmaxValue - ELVminValue) * dedtau * heartRate / 60.0 / 1.0;

    return dedt1
end


@component function ShiChamber_A(; name, Eₘᵢₙ, Eₘₐₓ)
    @named in = Pin()
    @named out = Pin()
    sts = @variables V(t) = 0.0 p(t) = 0.0
    ps = @parameters Eₘᵢₙ = Eₘᵢₙ Eₘₐₓ = Eₘₐₓ 

    D = Differential(t)
    E = ShiElastance_A(t, Eₘᵢₙ, Eₘₐₓ)
    DE = DShiElastance_A(t, Eₘᵢₙ, Eₘₐₓ)

    p_rel = 0.0
    V₀ = 0.0
    τ = 0.908

    eqs = [
            0 ~ in.p - out.p
            p ~ in.p
            V ~ (p - p_rel) / E + V₀
            D(p) ~ (in.q + out.q) * E + (p - p_rel) / E * DE
        ]

    compose(ODESystem(eqs, t, sts, ps; name=name), in, out)
end


begin 
    τ = 0.908
    ## Valve parameters ##
    Rav = 0.0025
    Rmv = 0.0025
    Rpv = 0.0025
    Rtv = 0.0025

    ## Systemic Circulation Parameters ##
    Csa = 1.13
    Rs = 2.367
    Csv = 20.5

    ## Pulmonary Circulation Parameters ##
    Cpa = 3.8
    Rp = 0.3
    Cpv = 20.5

    ## Left Ventricle parameters ##
    Emax_lv = 2.484
    Emin_lv = 0.1
    τes_lv = 0.30
    τep_lv = 0.45

    ## Right Ventricle parameters ##
    Emax_rv = 2.038
    Emin_rv = 0.1
    τes_rv = 0.30
    τep_rv = 0.45

    ## Left atrium parameters ##
    Emax_la = 0.25
    Emin_la = 0.15
    τes_la = 0.96
    τep_la = 1.00
    τ_initla     = 0.92;
    ## Right atrium parameters ##
    Emax_ra = 0.25
    Emin_ra = 0.15
    τes_ra = 0.96
    τep_ra = 1.00
    τ_initra     = 0.92;
end

@parameters t
@named LV = ShiChamber_V(Eₘᵢₙ=Emin_lv, Eₘₐₓ=Emax_lv)
@named LA = ShiChamber_A(Eₘᵢₙ=Emin_la, Eₘₐₓ=Emax_la)
@named RV = ShiChamber_V(Eₘᵢₙ=Emin_rv, Eₘₐₓ=Emax_rv)
@named RA = ShiChamber_A(Eₘᵢₙ=Emin_ra, Eₘₐₓ=Emax_ra)

@named AV = ResistorDiode(R = Rav)
@named MV = ResistorDiode(R = Rmv)
@named PV_ = ResistorDiode(R = Rav)
@named TV = ResistorDiode(R = Rmv)

@named SA = Compliance_(C = Csa)
@named SR = Resistor(R = Rs)
@named SV = Compliance_(C = Csv)

@named PA = Compliance_(C = Cpa)
@named PR = Resistor(R = Rp)
@named PV = Compliance_(C = Cpv)

circ_eqs = [
    connect(LV.out, AV.in)
    connect(AV.out, SA.in)
    connect(SA.out, SR.in)
    connect(SR.out, SV.in)
    connect(SV.out, RA.in)
    connect(RA.out, TV.in)
    connect(TV.out, RV.in)
    connect(RV.out, PV_.in)
    connect(PV_.out, PA.in)
    connect(PA.out, PR.in)
    connect(PR.out, PV.in)
    connect(PV.out, LA.in)
    connect(LA.out, MV.in)
    connect(MV.out, LV.in)
]

# Compose the whole ODAE system
@named _circ_model = ODESystem(circ_eqs, t)


@named circ_model = compose(_circ_model, [LV, LA, RV, RA, SA, SR, SV, PA, PR, PV, AV, MV, PV_, TV])

## And simplify it
@time "Simplify model"  circ_sys = structural_simplify(circ_model)

u0 =  [9.0, 9.0, 9.0, 9.0, 9.0, 9.0, 0.0, 0.0]
@time "Define problem" prob = ODEProblem(circ_sys, u0, (0.0, 20.0))

x = LinRange(18*τ, 20*τ, 150)
@time sol = solve(prob, Rodas5P(autodiff = false), reltol=1e-5, abstol=1e-5, saveat = x)


using GlobalSensitivity, QuasiMonteCarlo, JLD

## 
circ_time_post = function (p)
    out_global
end

###### Global Sensitiivty analysis on continous outputs ####
circ_time_idxs_chunked = function (p)

    global parameterset = p

    Np::Int64 = size(p,2)

    println("Running ", Np, " cases.")

    chunksize::Int64 = Np/chunks

    println("Using ", chunks, " chunk(s) of size ", chunksize, ".")


    out = zeros(15,Np)

    for k in 1:chunks
        offset = Int((k - 1) * Np/chunks)
        startindx = Int(offset + 1)
        endindx = Int(k * Np/chunks)

        println("Starting chunk ", k, ", from ", startindx, " to ", endindx, " with offset ", offset, ".")

        pchunk = p[:,startindx:endindx]
        
        prob_func(prob,i,repeat) = remake(prob; p=pchunk[:,i])

        ensemble_prob = EnsembleProblem(prob,prob_func=prob_func)


        @time "    ODE Ensemble solved in " sol = solve(ensemble_prob, Rodas5P(autodiff = false), reltol=1e-5, abstol=1e-5, saveat = x, EnsembleThreads(); trajectories=chunksize)
        @time "    Results processed in" Threads.@threads for i in 1:chunksize
          # println(i+offset)
          out[1,i+offset] = maximum(sol[i][1,:]) #max lvp
          out[2,i+offset] = minimum(sol[i][1,:]) #min lvp

          out[3,i+offset] = maximum(sol[i][3,:]) #max SAp
          out[4,i+offset] = minimum(sol[i][3,:]) #min SAp
##
          out[5,i+offset] = maximum(sol[i][4,:]) #max SV P
          out[6,i+offset] = minimum(sol[i][4,:]) #min SV P
##
          out[7,i+offset] = maximum(sol[i][LV.V]) #Max LVV
          out[8,i+offset] = minimum(sol[i][LV.V]) #Min LVV

           out[9,i+offset] = maximum(sol[i][2,:]) #max rvp
          out[10,i+offset] = minimum(sol[i][2,:]) #min rvp
#
          out[11,i+offset] = maximum(sol[i][5,:]) #max PAp
          out[12,i+offset] = minimum(sol[i][5,:]) #min PAp
###
          out[13,i+offset] = maximum(sol[i][6,:]) #max PV P
          out[14,i+offset] = minimum(sol[i][6,:]) #min PV P
          
          out[15,i+offset] = ((maximum(sol[i][LV.V]) - minimum(sol[i][LV.V]))*(0.908))
        end
    end
    global out_global = out
    out
end

chunks::Int64 = 250
samples = 100000
lb = [0.09, 2.2356, 0.135, 0.225, 0.09, 1.8342, 0.135, 0.225, 1.017, 2.1303, 18.45, 3.42, 0.27, 18.45, 0.00225, 0.00225, 0.00225, 0.00225]
ub = [0.11, 2.7324, 0.165, 0.275, 0.11, 2.2418, 0.165, 0.275, 1.243, 2.6037, 22.55, 4.18, 0.33, 22.55, 0.00275, 0.00275, 0.00275, 0.00275]
sampler = SobolSample()
A,B = QuasiMonteCarlo.generate_design_matrices(samples,lb,ub,sampler)
@time res = gsa(circ_time_idxs_chunked,Sobol(nboot = 1000),A,B,batch = true)

save("GSA_100k.jld","data",res)

