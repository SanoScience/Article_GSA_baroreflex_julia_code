using ModelingToolkit, DifferentialEquations, Statistics, CirculatorySystemModels, JLD


println("Running on ", Threads.nthreads(), " threads.")

## Components ##
@component function Compliance_(; name, C=1.0)
    @named in = Pin()
    @named out = Pin()

    sts = @variables begin
            V(t) = 0.0
            p(t) = 0.0
    end

    ps = @parameters begin
            C = C
    end

    # Add the thoracic pressure variant

    D = Differential(t)
    V₀ = 0.0
    eqs = [
            0 ~ in.p - out.p
            p ~ in.p
            V ~ (p - 0.0) * C + V₀
            D(p) ~ (in.q + out.q) * 1 / C
    ]

    compose(ODESystem(eqs, t, sts, ps; name=name), in, out)
end

### Ventricles ##

function ShiElastance_V(t, Eₘᵢₙ, Eₘₐₓ)

    τ = 0.908
    τₑₛ = 0.30
    τₑₚ = 0.45
    tᵢ = rem(t + (1.0) * τ, τ)
    Eₚ = (tᵢ <= τₑₛ) * (1 - cos(tᵢ / τₑₛ * pi)) / 2 +
         (tᵢ > τₑₛ) * (tᵢ <= τₑₚ) * (1 + cos((tᵢ - τₑₛ) / (τₑₚ - τₑₛ) * pi)) / 2 +
         (tᵢ <= τₑₚ) * 0

    E = Eₘᵢₙ + (Eₘₐₓ - Eₘᵢₙ) * Eₚ

    return E
end

function DShiElastance_V(t, Eₘᵢₙ, Eₘₐₓ)

    τ = 0.908
    τₑₛ = 0.30
    τₑₚ = 0.45
    tᵢ = rem(t + (1.0) * τ, τ)
    DEₚ = (tᵢ <= τₑₛ) * pi / τₑₛ * sin(tᵢ / τₑₛ * pi) / 2 +
          (tᵢ > τₑₛ) * (tᵢ <= τₑₚ) * pi / (τₑₚ - τₑₛ) * sin((τₑₛ - tᵢ) / (τₑₚ - τₑₛ) * pi) / 2
    (tᵢ <= τₑₚ) * 0
    DE = (Eₘₐₓ - Eₘᵢₙ) * DEₚ

    return DE
end


@component function ShiChamber_V(; name, Eₘᵢₙ, Eₘₐₓ)
    @named in = Pin()
    @named out = Pin()
    sts = @variables V(t) = 0.0 p(t) = 0.0
    ps = @parameters Eₘᵢₙ = Eₘᵢₙ Eₘₐₓ = Eₘₐₓ

    D = Differential(t)
    E = ShiElastance_V(t, Eₘᵢₙ, Eₘₐₓ)
    DE = DShiElastance_V(t, Eₘᵢₙ, Eₘₐₓ)

    p_rel = 0.0
    V₀ = 0.0
    τ = 0.908

    eqs = [
            0 ~ in.p - out.p
            p ~ in.p
            V ~ (p - p_rel) / E + V₀
            D(p) ~ (in.q + out.q) * E + (p - p_rel) / E * DE
        ]

    compose(ODESystem(eqs, t, sts, ps; name=name), in, out)
end

## Atria ##

function ShiElastance_A(t, ELVmaxValue, ELVminValue)

    τ = 0.908
    heartRate = 60/τ
    tauinit = 0.92
    tauESvalue = 0.96
    tauSSvalue = 1.00
    t           = rem(t,60 / heartRate);
    tauValue    = t * heartRate / 60.0;

    e           = 0.0* (tauValue >= 0.0)*(tauValue < tauinit)   +   (1.0-cos((pi*(tauValue-tauinit))/(tauESvalue-tauinit)))*(tauValue >= tauinit)*(tauValue <= tauESvalue)  +  (1.0+cos(pi*(tauValue-tauESvalue)/(tauSSvalue-tauESvalue)))*(tauValue > tauESvalue)*(tauValue <= tauSSvalue) +   0.0*(tauValue > tauSSvalue);
    e1          = 0.5 * (ELVmaxValue - ELVminValue) * e + ELVminValue;  
    return e1
end

function DShiElastance_A(t, ELVmaxValue, ELVminValue)

    τ = 0.908
    heartRate = 60/τ
    tauinit = 0.92
    tauESvalue = 0.96
    tauSSvalue = 1.00
    t           = rem(t,60 / heartRate);
    tauValue    = t * heartRate / 60.0;

    dedtau      = 0.0 * (tauValue >= 0.0)*(tauValue < tauinit)  +   sin(pi*(tauValue-tauinit)/(tauESvalue-tauinit)) * pi/(tauESvalue-tauinit)*(tauValue >= tauinit)*(tauValue <= tauESvalue)    +   sin(pi*(tauESvalue-tauValue)/(tauESvalue-tauSSvalue))*pi/(tauESvalue-tauSSvalue)*(tauValue > tauESvalue)*(tauValue <= tauSSvalue)    +   0.0*(tauValue > tauSSvalue);
    dedt1       = 0.5 * (ELVmaxValue - ELVminValue) * dedtau * heartRate / 60.0 / 1.0;

    return dedt1
end


@component function ShiChamber_A(; name, Eₘᵢₙ, Eₘₐₓ)
    @named in = Pin()
    @named out = Pin()
    sts = @variables V(t) = 0.0 p(t) = 0.0
    ps = @parameters Eₘᵢₙ = Eₘᵢₙ Eₘₐₓ = Eₘₐₓ 

    D = Differential(t)
    E = ShiElastance_A(t, Eₘᵢₙ, Eₘₐₓ)
    DE = DShiElastance_A(t, Eₘᵢₙ, Eₘₐₓ)

    p_rel = 0.0
    V₀ = 0.0
    τ = 0.908

    eqs = [
            0 ~ in.p - out.p
            p ~ in.p
            V ~ (p - p_rel) / E + V₀
            D(p) ~ (in.q + out.q) * E + (p - p_rel) / E * DE
        ]

    compose(ODESystem(eqs, t, sts, ps; name=name), in, out)
end


begin 
    τ = 0.908
    ## Valve parameters ##
    Rav = 0.0025
    Rmv = 0.0025
    Rpv = 0.0025
    Rtv = 0.0025

    ## Systemic Circulation Parameters ##
    Csa = 1.13
    Rs = 2.367
    Csv = 20.5

    ## Pulmonary Circulation Parameters ##
    Cpa = 3.8
    Rp = 0.3
    Cpv = 20.5

    ## Left Ventricle parameters ##
    Emax_lv = 2.484
    Emin_lv = 0.1
    τes_lv = 0.30
    τep_lv = 0.45

    ## Right Ventricle parameters ##
    Emax_rv = 2.038
    Emin_rv = 0.1
    τes_rv = 0.30
    τep_rv = 0.45

    ## Left atrium parameters ##
    Emax_la = 0.25
    Emin_la = 0.15
    τes_la = 0.96
    τep_la = 1.00
    τ_initla     = 0.92;
    ## Right atrium parameters ##
    Emax_ra = 0.25
    Emin_ra = 0.15
    τes_ra = 0.96
    τep_ra = 1.00
    τ_initra     = 0.92;
end

@parameters t
@named LV = ShiChamber_V(Eₘᵢₙ=Emin_lv, Eₘₐₓ=Emax_lv)
@named LA = ShiChamber_A(Eₘᵢₙ=Emin_la, Eₘₐₓ=Emax_la)
@named RV = ShiChamber_V(Eₘᵢₙ=Emin_rv, Eₘₐₓ=Emax_rv)
@named RA = ShiChamber_A(Eₘᵢₙ=Emin_ra, Eₘₐₓ=Emax_ra)

@named AV = ResistorDiode(R = Rav)
@named MV = ResistorDiode(R = Rmv)
@named PV_ = ResistorDiode(R = Rav)
@named TV = ResistorDiode(R = Rmv)

@named SA = Compliance_(C = Csa)
@named SR = Resistor(R = Rs)
@named SV = Compliance_(C = Csv)

@named PA = Compliance_(C = Cpa)
@named PR = Resistor(R = Rp)
@named PV = Compliance_(C = Cpv)

circ_eqs = [
    connect(LV.out, AV.in)
    connect(AV.out, SA.in)
    connect(SA.out, SR.in)
    connect(SR.out, SV.in)
    connect(SV.out, RA.in)
    connect(RA.out, TV.in)
    connect(TV.out, RV.in)
    connect(RV.out, PV_.in)
    connect(PV_.out, PA.in)
    connect(PA.out, PR.in)
    connect(PR.out, PV.in)
    connect(PV.out, LA.in)
    connect(LA.out, MV.in)
    connect(MV.out, LV.in)
]

# Compose the whole ODAE system
@named _circ_model = ODESystem(circ_eqs, t)


@named circ_model = compose(_circ_model, [LV, LA, RV, RA, SA, SR, SV, PA, PR, PV, AV, MV, PV_, TV])

## And simplify it
@time "Simplify model"  circ_sys = structural_simplify(circ_model)

u0 =  [9.0, 9.0, 9.0, 9.0, 9.0, 9.0, 0.0, 0.0]
@time "Define problem" prob = ODEProblem(circ_sys, u0, (0.0, 20.0))

x = LinRange(18*τ, 20*τ, 500)
@time sol = solve(prob, Rodas5P(autodiff = false), reltol=1e-12, abstol=1e-12, saveat = x)

function circ_local(p)
    _prob = ODEProblem(circ_sys, [9.0, 9.0, 9.0, 9.0, 9.0, 9.0, 0.0, 0.0], (0.0,20.0), p)
    newsol = solve(_prob, Rodas5P(autodiff = false),  reltol = 1e-12, abstol = 1e-12, saveat = x)
    [maximum(newsol[1,:]), #max lvp
    minimum(newsol[1,:]), #min lvp
    maximum(newsol[3,:]), #max SAp
    minimum(newsol[3,:]), #min SAp
    maximum(newsol[4,:]), #max SV P
    minimum(newsol[4,:]), #min SV P
    maximum(newsol[LV.V]), #Max LVV
    minimum(newsol[LV.V]), #Min LVV
     maximum(newsol[2,:]), #max rvp
     minimum(newsol[2,:]), #min rvp
     maximum(newsol[5,:]), #max PAp
     minimum(newsol[5,:]), #min PAp
     maximum(newsol[6,:]), #max PV P
     minimum(newsol[6,:]), #min PV P
     ((maximum(newsol[LV.V]) - minimum(newsol[LV.V]))*(0.908))]
end
# SV LV, PP LV, PP SA, Mean systemic flow 

## Absoloute sensititivty
using ForwardDiff
s = ForwardDiff.jacobian(circ_local, [0.1, 2.484, 0.15, 0.25, 0.1, 2.038, 0.15, 0.25, 1.13, 2.367, 20.5, 3.8, 0.3, 20.5, 0.0025, 0.0025, 0.0025, 0.0025])
## Make relative by scaling by p/y 
@time sol = solve(prob, Rodas5P(autodiff = false),  reltol = 1e-12, abstol = 1e-12, saveat = x)
measurements =        [maximum(sol[1,:]), #max lvp
minimum(sol[1,:]), #min lvp
maximum(sol[3,:]), #max SAp
minimum(sol[3,:]), #min SAp
maximum(sol[4,:]), #max SV P
minimum(sol[4,:]), #min SV P
maximum(sol[LV.V]), #Max LVV
minimum(sol[LV.V]), #Min LVV
 maximum(sol[2,:]), #max rvp
 minimum(sol[2,:]), #min rvp
 maximum(sol[5,:]), #max PAp
 minimum(sol[5,:]), #min PAp
 maximum(sol[6,:]), #max PV P
 minimum(sol[6,:]), #min PV P
 ((maximum(sol[LV.V]) - minimum(sol[LV.V]))*(0.908))]

S = Matrix{Float64}(undef,15,18)
for i in 1:15
    for j in 1:18
        S[i,j] = (prob.p[j]/measurements[i]) * s[i,j]
    end 
end

# Relative normalised sensititivty matrix 
S = abs.(S)/maximum(S)

S = S[:,[10, 9, 11, 13, 12, 14, 15, 16, 18, 17, 2, 1, 6, 5, 4, 3, 8, 7]]

save("S4UR.jld", "data", S)

using CairoMakie
HR_M = [L"\text{Max}(P_{LV})", L"\text{Min}(P_{LV})", L"\text{Max}(P_{A})", L"\text{Min}(P_{A})", L"\text{Max}(P_{V})", L"\text{Min}(P_{V})", L"\text{Max}(V_{LV})", L"\text{Min}(V_{LV})", L"\text{Max}(P_{RV})", L"\text{Min}(P_{RV})", L"\text{Max}(P_{pulA})", L"\text{Min}(P_{pulA})", L"\text{Max}(P_{pulV})", L"\text{Min}(P_{pulV})", L"\text{CO}"]
HR_P = [L"R_{sys}", L"C_{art}", L"C_{ven}", L"R_{pul}", L"C_{pulA}", L"C_{pulV}", L"r_{av}", L"r_{mv}", L"r_{tv}", L"r_{pv}", L"E_{LVmax}", L"E_{LVmin}", L"E_{RVmax}", L"E_{RVmin}", L"E_{LAmax}", L"E_{LAmin}", L"E_{RAmax}", L"E_{RAmin}"]
#CairoMakie.activate!(type = "svg")
## Relative Sensitivity Matrix 
f = Figure();
# to add axis we specify a position in the figures layout as first argument f[1,1] to fill the whole plot 
ax = Axis(f[1,1], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:15, HR_M), yticks = (1:18, HR_P))
Label(f[1, 1, Left()], "Unreg 4 cham",fontsize = 18,font = :bold,halign = :right, rotation = π/2, padding = (0,40,0,0))
Label(f[1, 1, TopLeft()], "B",fontsize = 18,font = :bold,halign = :right)
hm = CairoMakie.heatmap!(ax,S,  colormap=:gnuplot2)
for i in 1:15, j in 1:18
    txtcolor = S[i, j] < -1000.0 ? :white : :black
    text!(ax, "$(round(S[i,j], digits = 2))", position = (i, j),
        color = txtcolor, align = (:center, :center), fontsize = 12)
end
Colorbar(f[1,2],hm)
f
