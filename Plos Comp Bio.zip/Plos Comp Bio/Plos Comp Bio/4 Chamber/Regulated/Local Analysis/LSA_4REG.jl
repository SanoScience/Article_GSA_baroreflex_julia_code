#%% One chamber model with regulation
#%% Libraries
using DifferentialEquations
using Statistics

#%% Turn on/off baroreflex
REGswitch       = 1;                                 # 0 - off;  1 - on

#%% Time and initial pressure data
dt              = 0.1;                               # time step
T_init          = 0.0;                                 # initial time
T_max           = 200.0;                                # duration of simulation
tRange          = T_init : dt : T_max;               # time range
tspan           = (T_init, T_max);

params          = [1.13,   1.663,  20.5, 4.5,  0.30, 20.5]  #[Bjordalsbakke, Kamoi, -, Shi, Shi]
CsysA           = params[1];
Rsys            = params[2];
CsysV           = params[3];
CpulA           = params[4];
Rpul            = params[5];
CpulV           = params[6];

#%% Heart data
HT0             = 0.580;                             # heart period: inital value (Ursino, table 2)
t11             = 0.000;   
rav             = 0.0025;                            # copied from rmv
rmv             = 0.0025;                            # Ursino
rtv             = 0.0025;                            # Ursino
rpv             = 0.0025;                            # copied from rtv

# Left ventricle
const tauinitLV       = 0.00;                              # initialise the cycle (-)
const tauS1LV         = 0.30;                              # systolic tau (Bjordalsbakke)
const tauS2LV         = 0.45;                              # diastolic tau (Korakianitis)
ELVmax          = 2.00;                                    # maximum elastance for LV (Simaan)
ELVmin          = 0.06;                                    # minimum elastance for LV (Simaan)

# Right ventricle
const tauinitRV     = 0.00;                          # same as tauinitLV
const tauS1RV       = 0.30;                          # same as tauS1LV
const tauS2RV       = 0.45;                          # same as tauS2RV
ERVmax        = 1.75;                                # maximum elastance for RV (Ursino)
ERVmin        = 0.15;                                # minimum elastance for RV (-)

# Left atrium
const tauinitLA     = 0.92;                          # initial time of atrial systole (Korakianitis)
const tauS1LA       = 0.96;                          # time of systolic phrase peak (Korakianitis)
const tauS2LA       = 1.00;                          # time of systolic phrase end (Korakianitis)
ELAmax        = 0.25;                                # maximum elastance for LA (Korakianitis)
ELAmin        = 0.15;                                # minimum elastance for LA (Korakianitis)

# Right atrium
const tauinitRA     = 0.92;                          # same as tauinitLA
const tauS1RA       = 0.96;                          # same as tauS1LA
const tauS2RA       = 1.00;                          # same as tauS2LA
ERAmax        = 0.25;                                # maximum elastance for RA (Korakianitis)
ERAmin        = 0.15;                                # minimum elastance for RA (Korakianitis)

# pressure and volume ICs
const mcfp          = 6.0                            # mean circulatory filling pressure
const init_VLV      = 160.0                          # Initial volume of LV
init_VsysV    = mcfp * CsysV                         # Initial STRESSED volume of systemic veins 
const init_V_tot_un = 5400.0   
#                1     2     3     4     5     6     7     8     9     10  11  12  13  14  15        16  17          18             19
initPressure    = [mcfp, mcfp, mcfp, mcfp, mcfp, mcfp, mcfp, mcfp, 100., 0., 0., 0., 0., 0., init_VLV, 0., mcfp * CsysV, init_V_tot_un, HT0, ELVmax, ERVmax, HT0, t11]

# Regulation parameters (all from Ursino) according to Table 3
# Afferent pathway
Pn              = 92.0;                            # mmHg, setpoint pressure (value of intrasinus pressure at the central point of sigmoid)
ka              = 11.758;                        # mmHg, parameter related to a slope
fmin            = 2.52;                          # spikes/sec, minimum frequency, sigmoid limiter
fmax            = 47.78;                         # spikes/sec, maximum frequency, sigmoid limiter
tau_z           = 6.37;                          # sec, time constant for the real zero in a linear dynamic block
tau_p           = 2.076;                         # sec, time constant for the real pole in a linear dynamic block

# Sympathetic efferent pathway
fes_inf         = 2.10;                          # spikes/sec, frequency for infinity
fes_0           = 16.11;                         # spikes/sec, frequency for the absence of innervation
fes_min         = 2.66;                          # spikes/sec, minimum frequency for sympathetic efferent path
kes             = 0.0675;                        # sec, parameter for exponential function

# Vagal efferent pathway
fev_0           = 3.2;                           # spikes/sec
fev_inf         = 6.3;                           # spikes/sec
fcs_0           = 25.0;                            # spikes/sec
kev             = 7.06;                          # spikes/sec

# Effectors
gain_ELV        = 0.475;                         # maximum left ventricular elastance control
tau_ELV         = 8.0;
delay_ELV       = 2.0;

gain_ERV        = 0.282;                         # maximum left ventricular elastance control
tau_ERV         = 8.0;
delay_ERV       = 2.0;

gain_Rsp        = 0.695;                         # splanchnic systemic resistance control
tau_Rsp         = 6.0;
delay_Rsp       = 2.0;

gain_HTs        =-0.13;                          # heart period sympathetic control
tau_HTs         = 2.0;
delay_HTs       = 2.0;

gain_HTv        = 0.09;                          # heart period vagal control
tau_HTv         = 1.5;
delay_HTv       = 0.2;

gain_Cv         = -199.0;                           # venous unstressed volume  
tau_Cv          = 20.0;
delay_Cv        = 5.0; 

# DDE delay parameters vector 
delay           = [delay_HTs, delay_Rsp, delay_ELV, delay_ERV, delay_HTv,delay_Cv]

# initial values for controlled parameters
RspSET          = Rsys;                          # sys resistance
CsysVSET        = CsysV;                         # venous compliance 
ELVmaxSET       = ELVmax;                        # maximum left ventricular elastance
ERVmaxSET       = ERVmax;                        # maximum left ventricular elastance
heartperiodSET  = HT0;                           # heart period
SwitchTime      = HT0;                           # first time of the beat end


heaviside(x) = ifelse(x < 0.0, zero(x), ifelse(x > 0.0, one(x), oftype(x,0.5)))

#%% Functions
# Valve function
function heartValve(pressureDifference, valveResistance)
    q           = (pressureDifference./valveResistance)     .* (pressureDifference >  0.0) +
    (pressureDifference/1000.0/valveResistance)  .* (pressureDifference <= 0.0);
    return q
end

# Elastance function
function ShiCosineElastance(t, tauinit, tauESvalue, tauSSvalue, ELVmaxValue, ELVminValue, heartRate)

    tauValue    = t * heartRate / 60.0;
    tauESvalue = tauESvalue * 60.0/heartRate;
    tauSSvalue = tauSSvalue * 60.0/heartRate;
    tauinit = tauinit * 60.0/heartRate;

    e           = 0.0* (tauValue >= 0.0)*(tauValue < tauinit)   +   (1.0-cos((pi*(tauValue-tauinit))/(tauESvalue-tauinit)))*(tauValue >= tauinit)*(tauValue <= tauESvalue)  +  (1.0+cos(pi*(tauValue-tauESvalue)/(tauSSvalue-tauESvalue)))*(tauValue > tauESvalue)*(tauValue <= tauSSvalue) +   0.0*(tauValue > tauSSvalue);
    e1          = 0.5 * (ELVmaxValue - ELVminValue) * e + ELVminValue;   
    dedtau      = 0.0 * (tauValue >= 0.0)*(tauValue < tauinit)  +   sin(pi*(tauValue-tauinit)/(tauESvalue-tauinit)) * pi/(tauESvalue-tauinit)*(tauValue >= tauinit)*(tauValue <= tauESvalue)    +   sin(pi*(tauESvalue-tauValue)/(tauESvalue-tauSSvalue))*pi/(tauESvalue-tauSSvalue)*(tauValue > tauESvalue)*(tauValue <= tauSSvalue)    +   0.0*(tauValue > tauSSvalue);
    dedt1       = 0.5 * (ELVmaxValue - ELVminValue) * dedtau * heartRate / 60.0 / 1.0;
    return e1, dedt1
end

par    = [Rsys, CsysA, CsysV, Rpul, CpulA, CpulV, rav, rmv, rtv, rpv, HT0, ELVmax, ELVmin, ERVmax, ERVmin, ELAmax, ELAmin, ERAmax, ERAmin, Pn, ka, fmin, fmax, tau_z, tau_p, fes_inf, fes_0, fes_min, kes, fev_0, fev_inf, fcs_0, kev, gain_ELV, tau_ELV, delay_ELV, gain_ERV, tau_ERV, delay_ERV, gain_Rsp, tau_Rsp, delay_Rsp, gain_HTs, tau_HTs, delay_HTs, gain_HTv, tau_HTv, delay_HTv, gain_Cv, tau_Cv, delay_Cv]

# Model function
function model(dPdt:: Vector, P:: Vector, h, p, t)
    # unpack parameter vector 
    Rsys, CsysA, CsysV, Rpul, CpulA, CpulV, rav, rmv, rtv, rpv, HT0, ELVmax, ELVmin, ERVmax, ERVmin, ELAmax, ELAmin, ERAmax, ERAmin, Pn, ka, fmin, fmax, tau_z, tau_p, fes_inf, fes_0, fes_min, kes, fev_0, fev_inf, fcs_0, kev, gain_ELV, tau_ELV, delay_ELV, gain_ERV, tau_ERV, delay_ERV, gain_Rsp, tau_Rsp, delay_Rsp, gain_HTs, tau_HTs, delay_HTs, gain_HTv, tau_HTv, delay_HTv, gain_Cv, tau_Cv, delay_Cv =p
    # initialise / update regulation 
    # Venous regulation applied in the dynamics
    # Venous capacitance assumed constant and unregulated volume is adjusted through regulation
    RspSET          = Rsys   + P[11]*REGswitch;
    offsetHT = P[19]-HT0
    offsetELV = P[20]-ELVmax
    offsetERV = P[21] - ERVmax
    if (t-P[22]) > 0.0                                                      # if simulation reaches the end of the beat, change the value of heart period, elastance, systemic resistance
        P[23]             = t;
        P[22]      = P[22] + P[19]                                           # ... and change the time of next end of the beat because of the heart period adjustment
    end

    # delays taken from Ursino 1998 :: hard coded 
    histHTs=h(p, t-2.0)[9]
    histRsp=h(p, t-2.0)[9]
    histCv =h(p, t-5.0)[9]
    histELV=h(p, t-2.0)[9]
    histERV=h(p, t-2.0)[9]
    histHTv=h(p, t-0.2)[9]
    
    ElocalLV, dEdtlocalLV    = ShiCosineElastance(t-P[23], tauinitLV, tauS1LV, tauS2LV, P[20], ELVmin, 60/P[19])         # elastance calculations - LV
    ElocalRV, dEdtlocalRV    = ShiCosineElastance(t-P[23], tauinitRV, tauS1RV, tauS2RV, P[21], ERVmin, 60/P[19])         # elastance calculations - LV
    ElocalRA, dEdtlocalRA    = ShiCosineElastance(t-P[23], tauinitRA, tauS1RA, tauS2RA, ERAmax,    ERAmin, 60/P[19])         # elastance calculations - LV
    ElocalLA, dEdtlocalLA    = ShiCosineElastance(t-P[23], tauinitLA, tauS1LA, tauS2LA, ELAmax,    ELAmin, 60/P[19])         # elastance calculations - LV
    
    # new variables for pressures in the system, to make the set of ODE more clear
    iAV                      = heartValve(P[1]-P[2]  ,rav);                                                                         # flow through aortic valve
    iMV                      = heartValve(P[8]-P[1]  ,rmv);                                                                         # flow through mitral valve
    iTV                      = heartValve(P[4]-P[5]  ,rtv);
    iPV                      = heartValve(P[5]-P[6]  ,rpv);

    # Ursino : afferent spiking 
    fcsSymHT        = (fmin + fmax * exp((histHTs-Pn)/ka)) / (1.0 + exp((histHTs-Pn)/ka));
    fcsSymRsp       = (fmin + fmax * exp((histRsp-Pn)/ka)) / (1.0 + exp((histRsp-Pn)/ka));
    fcsSymCv        = (fmin + fmax * exp((histCv -Pn)/ka)) / (1.0 + exp((histCv -Pn)/ka));
    fcsSymELV       = (fmin + fmax * exp((histELV-Pn)/ka)) / (1.0 + exp((histELV-Pn)/ka));
    fcsSymERV       = (fmin + fmax * exp((histERV-Pn)/ka)) / (1.0 + exp((histERV-Pn)/ka));
    fcsVagHT        = (fmin + fmax * exp((histHTv-Pn)/ka)) / (1.0 + exp((histHTv-Pn)/ka));
    # Ursino: efferent sympathetic frequency calculation
    fesSymHT        = fes_inf   + (fes_0 - fes_inf) .*  exp(-kes*fcsSymHT );
    fesSymRsp       = fes_inf   + (fes_0 - fes_inf) .*  exp(-kes*fcsSymRsp);
    fesSymCv        = fes_inf   + (fes_0 - fes_inf) .*  exp(-kes*fcsSymCv );
    fesSymELV       = fes_inf   + (fes_0 - fes_inf) .*  exp(-kes*fcsSymELV);
    fesSymERV       = fes_inf   + (fes_0 - fes_inf) .*  exp(-kes*fcsSymERV);
    # Ursino: efferent parasympathetic (vagal) frequency calculation
    fevPsymHT       = (fev_0 + fev_inf .* exp((fcsVagHT-fcs_0)/kev))./(1.0+exp((fcsVagHT-fcs_0)/kev));
  
    # Effector control inputs                                                        
    sigma1          = gain_HTs    *   log(fesSymHT   - fes_min + 1.0)    *   heaviside(fesSymHT  - fes_min);
    sigma2          = gain_Rsp    *   log(fesSymRsp  - fes_min + 1.0)    *   heaviside(fesSymRsp - fes_min);
    sigma3          = gain_ELV    *   log(fesSymELV  - fes_min + 1.0)    *   heaviside(fesSymELV - fes_min);
    sigma4          = gain_ERV    *   log(fesSymERV  - fes_min + 1.0)    *   heaviside(fesSymERV - fes_min);
    sigma5          = gain_HTv    *   fevPsymHT; 
    sigma6          = gain_Cv     *   log(fesSymCv   - fes_min + 1.0)    *   heaviside(fesSymCv  - fes_min);
        
    Q1              = iAV;
    Q2              = 1.0/RspSET * P[2] - 1.0/RspSET * P[3] - Q1;
    Q4              = iTV;
    Q5              = iPV;
    Q6              = 1.0/Rpul    * P[6] - 1.0/Rpul  * P[7] - Q5;
    Q8              = iMV;
    #print(hpdifference)
    #print(" ")

    # Mechanical 
    dPdt[1]        = ElocalLV * (Q8 - Q1) + dEdtlocalLV * P[1] / ElocalLV;
    dPdt[2]        = -1.0/CsysA/RspSET * P[2] + 1.0/CsysA/RspSET * P[3] + 1.0/CsysA * Q1;
    dPdt[16]       = (-P[16] + sigma6)/tau_Cv;                          # unstressed volume PERTURBATION  
    dPdt[4]        = - ElocalRA/(1.0 + CsysV*ElocalRA) * dPdt[16] + dEdtlocalRA * P[4] / (ElocalRA * (1.0 + CsysV*ElocalRA)) + ElocalRA / (1.0 + CsysV*ElocalRA) * (Q1 + Q2 - Q4)
    dPdt[3]        = dPdt[4];
    dPdt[5]        = ElocalRV * (Q4 - Q5) + dEdtlocalRV * P[5] / ElocalRV;
    dPdt[6]        = -1.0/CpulA/Rpul * P[6] + 1.0/CpulA/Rpul * P[7] + 1.0/CpulA * Q5;
    dPdt[8]        = dEdtlocalLA * P[8] / (ElocalLA * (1.0 + CpulV*ElocalLA)) + ElocalLA / (1.0 + CpulV*ElocalLA) * (Q5 + Q6 - Q8);
    dPdt[7]        = dPdt[8];
    # Regulation 
    dPdt[9]        = (-P[9] + P[2] + tau_z*dPdt[2])/tau_p;     
    dPdt[10]       = (-P[10] + sigma1)/tau_HTs;                                      
    dPdt[11]       = (-P[11] + sigma2)/tau_Rsp;                                      
    dPdt[12]       = (-P[12] + sigma3)/tau_ELV;           
    dPdt[13]       = (-P[13] + sigma4)/tau_ERV;                             
    dPdt[14]       = (-P[14] + sigma5)/tau_HTv;
    dPdt[15]       = iMV-iAV;                                           # LV volume 
    dPdt[17]       = Q1 + Q2 - Q4 - dPdt[16];                           # stressed volume of systemic veins
    dPdt[18]       = dPdt[16];                                          # unstressed volume of whole system 
    σ = 0.001#0.0005#10^(-2)
    dPdt[19]       = exp(-((t-P[23])^(2))/(2*σ^2))*(P[14]+P[10]- offsetHT)*sqrt(1.0/(2.0*π))*1.0/σ 
    dPdt[20]       = exp(-((t-P[23])^(2))/(2*σ^2))*(P[12]- offsetELV)*sqrt(1.0/(2.0*π))*1.0/σ 
    dPdt[21]       = exp(-((t-P[23])^(2))/(2*σ^2))*(P[13]- offsetERV)*sqrt(1.0/(2.0*π))*1.0/σ 
end

#%% Solution
h(p, t)   = ones(9)*100.0                                                  # Constant history of P(9) 
p         = par
prob      = DDEProblem(model, initPressure, h, tspan, p; constant_lags = delay)
x = LinRange(175,178,200)
@time sol1= solve(prob, MethodOfSteps(Tsit5()), reltol = 1e-12, abstol = 1e-12, saveat=x)

function circ_local(p)
    _prob = DDEProblem(model, [6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 6.0, 100., 0., 0., 0., 0., 0., 160., 0., 6.0 * p[3], 5400., p[11], p[12], p[14], p[11], 0.0],h, (0.0,50.0), p; constant_lags = delay)
    newsol = solve(_prob, MethodOfSteps(Tsit5()),  reltol = 1e-12, abstol = 1e-12, saveat = x)
    [maximum(newsol[1, :]), minimum(newsol[1, :]), maximum(newsol[2, :]), minimum(newsol[2, :]), maximum(newsol[3, :]), minimum(newsol[3, :]), maximum(newsol[9, :]), minimum(newsol[9, :]), maximum(newsol[5, :]), minimum(newsol[5, :]), maximum(newsol[6, :]), minimum(newsol[6, :]), maximum(newsol[8, :]), minimum(newsol[8, :]), (p[11] + mean(newsol[5,:]) + mean(newsol[8,:])),((maximum(newsol[9,:]) - minimum(newsol[9,:]))*(p[11] + mean(newsol[10,:]) + mean(newsol[14,:])))]   
end
# SV LV, PP LV, PP SA, Mean systemic flow 

## Absoloute sensititivty
using Statistics, ForwardDiff
s = ForwardDiff.jacobian(circ_local, par)
## Make relative by scaling by p/y 
@time sol = solve(prob, MethodOfSteps(Tsit5()),  reltol = 1e-12, abstol = 1e-12, saveat = x)
measurements =     [maximum(sol[1, :]), minimum(sol[1, :]), maximum(sol[2, :]), minimum(sol[2, :]), maximum(sol[3, :]), minimum(sol[3, :]), maximum(sol[9, :]), minimum(sol[9, :]), maximum(sol[5, :]), minimum(sol[5, :]), maximum(sol[6, :]), minimum(sol[6, :]), maximum(sol[8, :]), minimum(sol[8, :]), (p[11] + mean(sol[5,:]) + mean(sol[8,:])),((maximum(sol[9,:]) - minimum(sol[9,:]))*(p[11] + mean(sol[10,:]) + mean(sol[14,:])))]   


S = Matrix{Float64}(undef,16,51)
for i in 1:16
    for j in 1:51
        S[i,j] = (prob.p[j]/measurements[i]) * s[i,j]
    end 
end

# Relative normalised sensititivty matrix 
S = abs.(S)/maximum(S)

save("S4R.jld", "data", S)


using CairoMakie
R_M = [L"\text{Max}(P_{LV})", L"\text{Min}(P_{LV})", L"\text{Max}(P_{A})", L"\text{Min}(P_{A})", L"\text{Max}(P_{V})", L"\text{Min}(P_{V})", L"\text{Max}(V_{LV})", L"\text{Min}(V_{LV})", L"\text{Max}(P_{RV})", L"\text{Min}(P_{RV})", L"\text{Max}(P_{pulA})", L"\text{Min}(P_{pulA})", L"\text{Max}(P_{pulV})", L"\text{Min}(P_{pulV})", L"\tau_{HR}", L"\text{CO}"]
R_P =   [L"R_{sys}", L"C_{art}", L"C_{ven}", L"R_{pul}", L"C_{pulA}", L"C_{pulV}", L"r_{av}", L"r_{mv}", L"r_{tv}", L"r_{pv}", L"\tau_{HR,0}", L"E_{LVmax}", L"E_{LVmin}", L"E_{RVmax}", L"E_{RVmin}", L"E_{LAmax}", L"E_{LAmin}", L"E_{RAmax}", L"E_{RAmin}", L"P_{n}",L"k_{a}",L"f_{min}",L"f_{max}", L"\tau_{z}",L"\tau_{p}",L"f_{es,\infty}",L"f_{es,0}", L"f_{es,min}",L"k_{es}",L"f_{ev,0}", L"f_{ev,\infty}",L"f_{cs,0}",L"k_{ev}", L"G_{Emax,LV}",L"\tau_{Emax,LV}",L"D_{Emax,LV}", L"G_{Emax,RV}",L"\tau_{Emax,RV}",L"D_{Emax,RV}", L"G_{Rsys}",L"\tau_{Rsys}",L"D_{Rsys}", L"G_{\tau,s}",L"\tau_{\tau,s}",L"D_{\tau,s}",L"G_{\tau,v}",L"\tau_{\tau,v}",L"D_{\tau,v}", L"G_{VunV}",L"\tau_{VunV}",L"D_{VunV}"]
#CairoMakie.activate!(type = "svg")
## Relative Sensitivity Matrix 
f = Figure();
# to add axis we specify a position in the figures layout as first argument f[1,1] to fill the whole plot 
ax = Axis(f[1,1], xticklabelrotation = π / 3, xticklabelalign = (:right, :center), xticks = (1:16, R_M), yticks = (1:51, R_P))
Label(f[1, 1, Left()], "Regulated",fontsize = 18,font = :bold,halign = :right, rotation = π/2, padding = (0,40,0,0))
Label(f[1, 1, TopLeft()], "B",fontsize = 18,font = :bold,halign = :right)
hm = CairoMakie.heatmap!(ax,S,  colormap=:gnuplot2)
for i in 1:16, j in 1:51
    txtcolor = S[i, j] < -1000.0 ? :white : :black
    text!(ax, "$(round(S[i,j], digits = 2))", position = (i, j),
        color = txtcolor, align = (:center, :center), fontsize = 12)
end
Colorbar(f[1,2],hm)
f
